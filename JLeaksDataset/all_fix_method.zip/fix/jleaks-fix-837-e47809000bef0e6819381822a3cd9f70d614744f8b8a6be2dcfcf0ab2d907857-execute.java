public Result execute( Result previousResult, int nr ) 
{
    if (databaseMeta != null) {
        try (Database db = new Database(this, databaseMeta)) {
            String theSql = sqlFromFile ? buildSqlFromFile() : sql;
            if (Utils.isEmpty(theSql)) {
                return result;
            }
            db.shareVariablesWith(this);
            db.connect(parentJob.getTransactionId(), null);
            // let it run
            if (useVariableSubstitution) {
                theSql = environmentSubstitute(theSql);
            }
            if (isDetailed()) {
                logDetailed(BaseMessages.getString(PKG, "JobSQL.Log.SQlStatement", theSql));
            }
            if (sendOneStatement) {
                db.execStatement(theSql);
            } else {
                db.execStatements(theSql);
            }
        } catch (KettleDatabaseException je) {
            result.setNrErrors(1);
            logError(BaseMessages.getString(PKG, "JobSQL.ErrorRunJobEntry", je.getMessage()));
        }
    } else {
        result.setNrErrors(1);
        logError(BaseMessages.getString(PKG, "JobSQL.NoDatabaseConnection"));
    }
    result.setResult(result.getNrErrors() == 0);
    return result;
}