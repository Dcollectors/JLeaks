public static void saveObject(
		Object obj, 
		File file
		) throws JRException
	{
		try (
			ObjectOutputStream oos = 
				new ObjectOutputStream(
					new BufferedOutputStream(
						new FileOutputStream(file)
						)
					)
			)
		{
			oos.writeObject(obj);
		}
		catch (IOException e)
		{
            throw 
				new JRException(
					EXCEPTION_MESSAGE_KEY_FILE_SAVE_ERROR,
					new Object[]{file},
					e);
		}
	}