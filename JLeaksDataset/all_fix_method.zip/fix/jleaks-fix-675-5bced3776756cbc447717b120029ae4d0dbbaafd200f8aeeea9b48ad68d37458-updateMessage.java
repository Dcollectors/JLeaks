protected MBMessage updateMessage(
    ActionRequest actionRequest, ActionResponse actionResponse)
throws Exception {
    ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
    long messageId = ParamUtil.getLong(actionRequest, "messageId");
    long groupId = themeDisplay.getScopeGroupId();
    long categoryId = ParamUtil.getLong(actionRequest, "mbCategoryId");
    long threadId = ParamUtil.getLong(actionRequest, "threadId");
    long parentMessageId = ParamUtil.getLong(actionRequest, "parentMessageId");
    String subject = ParamUtil.getString(actionRequest, "subject");
    String body = ParamUtil.getString(actionRequest, "body");
    MBGroupServiceSettings mbGroupServiceSettings = MBGroupServiceSettings.getInstance(groupId);
    List<ObjectValuePair<String, InputStream>> inputStreamOVPs = new ArrayList<>(5);
    try {
        UploadPortletRequest uploadPortletRequest = _portal.getUploadPortletRequest(actionRequest);
        for (int i = 1; i <= 5; i++) {
            String fileName = uploadPortletRequest.getFileName("msgFile" + i);
            InputStream inputStream = uploadPortletRequest.getFileAsStream("msgFile" + i);
            if ((inputStream == null) || Validator.isNull(fileName)) {
                continue;
            }
            ObjectValuePair<String, InputStream> inputStreamOVP = new ObjectValuePair<>(fileName, inputStream);
            inputStreamOVPs.add(inputStreamOVP);
        }
        boolean question = ParamUtil.getBoolean(actionRequest, "question");
        if (categoryId != MBCategoryConstants.DEFAULT_PARENT_CATEGORY_ID) {
            MBCategory category = _mbCategoryService.getCategory(categoryId);
            String displayStyle = category.getDisplayStyle();
            if (displayStyle.equals("question")) {
                question = true;
            }
        }
        boolean anonymous = ParamUtil.getBoolean(actionRequest, "anonymous");
        double priority = ParamUtil.getDouble(actionRequest, "priority");
        boolean allowPingbacks = ParamUtil.getBoolean(actionRequest, "allowPingbacks");
        ServiceContext serviceContext = ServiceContextFactory.getInstance(MBMessage.class.getName(), actionRequest);
        boolean preview = ParamUtil.getBoolean(actionRequest, "preview");
        serviceContext.setAttribute("preview", preview);
        MBMessage message = null;
        CaptchaConfiguration captchaConfiguration = getCaptchaConfiguration();
        if (messageId <= 0) {
            if (captchaConfiguration.messageBoardsEditMessageCaptchaEnabled()) {
                CaptchaUtil.check(actionRequest);
            }
            if (threadId <= 0) {
                // Post new thread
                message = _mbMessageService.addMessage(groupId, categoryId, subject, body, mbGroupServiceSettings.getMessageFormat(), inputStreamOVPs, anonymous, priority, allowPingbacks, serviceContext);
                if (question) {
                    _mbThreadLocalService.updateQuestion(message.getThreadId(), true);
                }
            } else {
                // Post reply
                message = _mbMessageService.addMessage(parentMessageId, subject, body, mbGroupServiceSettings.getMessageFormat(), inputStreamOVPs, anonymous, priority, allowPingbacks, serviceContext);
            }
            MBMessageFormatUploadHandler formatHandler = _formatHandlerProvider.provide(message.getFormat());
            if (formatHandler != null) {
                body = _addBodyAttachmentTempFiles(themeDisplay, message.getBody(), message, new ArrayList<String>(), formatHandler);
                message.setBody(body);
                _mbMessageLocalService.updateMBMessage(message);
            }
        } else {
            List<String> existingFiles = new ArrayList<>();
            for (int i = 1; i <= 5; i++) {
                String path = ParamUtil.getString(actionRequest, "existingPath" + i);
                if (Validator.isNotNull(path)) {
                    existingFiles.add(path);
                }
            }
            message = _mbMessageService.getMessage(messageId);
            MBMessageFormatUploadHandler formatHandler = _formatHandlerProvider.provide(message.getFormat());
            if (formatHandler != null) {
                body = _addBodyAttachmentTempFiles(themeDisplay, body, message, existingFiles, formatHandler);
            }
            // Update message
            message = _mbMessageService.updateMessage(messageId, subject, body, inputStreamOVPs, existingFiles, priority, allowPingbacks, serviceContext);
            if (message.isRoot()) {
                _mbThreadLocalService.updateQuestion(message.getThreadId(), question);
            }
        }
        PermissionChecker permissionChecker = themeDisplay.getPermissionChecker();
        boolean subscribe = ParamUtil.getBoolean(actionRequest, "subscribe");
        if (!preview && subscribe && MBMessagePermission.contains(permissionChecker, message, ActionKeys.SUBSCRIBE)) {
            _mbMessageService.subscribeMessage(message.getMessageId());
        }
        return message;
    } finally {
        for (ObjectValuePair<String, InputStream> inputStreamOVP : inputStreamOVPs) {
            try (InputStream inputStream = inputStreamOVP.getValue()) {
            } catch (IOException ioe) {
                if (_log.isWarnEnabled()) {
                    _log.warn(ioe, ioe);
                }
            }
        }
    }
}