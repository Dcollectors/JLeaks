public DruidStatement prepare(final PlannerFactory plannerFactory, final String query, final long maxRowCount){
    try (final DruidPlanner planner = plannerFactory.createPlanner(queryContext)) {
        synchronized (lock) {
            ensure(State.NEW);
            this.plannerResult = planner.plan(query);
            this.maxRowCount = maxRowCount;
            this.query = query;
            this.signature = Meta.Signature.create(createColumnMetaData(plannerResult.rowType()), query, new ArrayList<>(), Meta.CursorFactory.ARRAY, // We only support SELECT
            Meta.StatementType.SELECT);
            this.state = State.PREPARED;
        }
    } catch (Throwable t) {
        try {
            close();
        } catch (Throwable t1) {
            t.addSuppressed(t1);
        }
        throw Throwables.propagate(t);
    }
    return this;
}