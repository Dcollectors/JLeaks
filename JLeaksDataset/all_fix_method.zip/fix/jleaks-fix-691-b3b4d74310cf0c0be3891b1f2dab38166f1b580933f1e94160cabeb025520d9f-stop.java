private static boolean stop(
    Server server, CommandExecutor executor, DefaultMirroringService mirroringService,
    ProjectManager pm, ExecutorService repositoryWorker) {
    boolean success = true;
    try {
        if (pm != null) {
            logger.info("Stopping the project manager ..");
            pm.close(ShuttingDownException::new);
            logger.info("Stopped the project manager");
        }
    } catch (Throwable t) {
        success = false;
        logger.warn("Failed to stop the project manager:", t);
    }
    try {
        if (executor != null) {
            logger.info("Stopping the command executor ..");
            executor.stop();
            logger.info("Stopped the command executor");
        }
    } catch (Throwable t) {
        success = false;
        logger.warn("Failed to stop the command executor:", t);
    }
    try {
        // Stop the mirroring service if the command executor did not stop it.
        if (mirroringService != null && mirroringService.isStarted()) {
            logger.info("Stopping the mirroring service not terminated by the command executor ..");
            mirroringService.stop();
            logger.info("Stopped the mirroring service");
        }
    } catch (Throwable t) {
        success = false;
        logger.warn("Failed to stop the mirroring service:", t);
    }
    try {
        if (repositoryWorker != null && !repositoryWorker.isTerminated()) {
            logger.info("Stopping the repository worker ..");
            boolean interruptLater = false;
            while (!repositoryWorker.isTerminated()) {
                repositoryWorker.shutdownNow();
                try {
                    repositoryWorker.awaitTermination(1, TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    // Interrupt later.
                    interruptLater = true;
                }
            }
            logger.info("Stopped the repository worker");
            if (interruptLater) {
                Thread.currentThread().interrupt();
            }
        }
    } catch (Throwable t) {
        success = false;
        logger.warn("Failed to stop the repository worker:", t);
    }
    try {
        if (server != null) {
            logger.info("Stopping the RPC server ..");
            server.stop().join();
            logger.info("Stopped the RPC server");
        }
    } catch (Throwable t) {
        success = false;
        logger.warn("Failed to stop the RPC server:", t);
    }
    return success;
}