public static BufferedImage getTokenThumbnail(File file) throws Exception 
{
    BufferedImage thumb;
    try (PackedFile pakFile = new PackedFile(file)) {
        // Jamz: Lets use the Large thumbnail if needed
        String thumbFileName = getThumbFilename(pakFile);
        thumb = null;
        if (pakFile.hasFile(thumbFileName)) {
            InputStream is = null;
            try {
                is = pakFile.getFileAsInputStream(thumbFileName);
                thumb = ImageIO.read(is);
            } finally {
                IOUtils.closeQuietly(is);
            }
        }
    }
    return thumb;
}