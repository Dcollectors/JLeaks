public static List<String> getLines(File file) throws IOException 
{
    try (FileReader fr = new FileReader(file)) {
        return IOUtils.readLines(fr);
    }
}