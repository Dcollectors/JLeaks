public WebResponse getResponse(final WebRequest webRequest) throws IOException 
{
    final long startTime = System.currentTimeMillis();
    final URL url = webRequest.getUrl();
    if (LOG.isTraceEnabled()) {
        LOG.trace("about to fetch URL " + url);
    }
    // hack for JS, about, and data URLs.
    final WebResponse response = produceWebResponseForGAEProcolHack(url);
    if (response != null) {
        return response;
    }
    // this is a "normal" URL
    try {
        final HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        // connection.setUseCaches(false);
        connection.setConnectTimeout(webClient_.getOptions().getTimeout());
        connection.addRequestProperty("User-Agent", webClient_.getBrowserVersion().getUserAgent());
        connection.setInstanceFollowRedirects(false);
        // copy the headers from WebRequestSettings
        for (final Entry<String, String> header : webRequest.getAdditionalHeaders().entrySet()) {
            connection.addRequestProperty(header.getKey(), header.getValue());
        }
        addCookies(connection);
        final HttpMethod httpMethod = webRequest.getHttpMethod();
        connection.setRequestMethod(httpMethod.name());
        if (HttpMethod.POST == httpMethod || HttpMethod.PUT == httpMethod || HttpMethod.PATCH == httpMethod) {
            connection.setDoOutput(true);
            final String charset = webRequest.getCharset();
            connection.addRequestProperty("Content-Type", FormEncodingType.URL_ENCODED.getName());
            try (final OutputStream outputStream = connection.getOutputStream()) {
                final List<NameValuePair> pairs = webRequest.getRequestParameters();
                final org.apache.http.NameValuePair[] httpClientPairs = NameValuePair.toHttpClient(pairs);
                final String query = URLEncodedUtils.format(Arrays.asList(httpClientPairs), charset);
                outputStream.write(query.getBytes(charset));
                if (webRequest.getRequestBody() != null) {
                    IOUtils.write(webRequest.getRequestBody().getBytes(charset), outputStream);
                }
            }
        }
        final int responseCode = connection.getResponseCode();
        if (LOG.isTraceEnabled()) {
            LOG.trace("fetched URL " + url);
        }
        final List<NameValuePair> headers = new ArrayList<>();
        for (final Map.Entry<String, List<String>> headerEntry : connection.getHeaderFields().entrySet()) {
            final String headerKey = headerEntry.getKey();
            if (headerKey != null) {
                // map contains entry like (null: "HTTP/1.1 200 OK")
                final StringBuilder sb = new StringBuilder();
                for (final String headerValue : headerEntry.getValue()) {
                    if (sb.length() != 0) {
                        sb.append(", ");
                    }
                    sb.append(headerValue);
                }
                headers.add(new NameValuePair(headerKey, sb.toString()));
            }
        }
        final byte[] byteArray;
        try (final InputStream is = responseCode < 400 ? connection.getInputStream() : connection.getErrorStream()) {
            byteArray = IOUtils.toByteArray(is);
        }
        final long duration = System.currentTimeMillis() - startTime;
        final WebResponseData responseData = new WebResponseData(byteArray, responseCode, connection.getResponseMessage(), headers);
        saveCookies(url.getHost(), headers);
        return new WebResponse(responseData, webRequest, duration);
    } catch (final IOException e) {
        LOG.error("Exception while tyring to fetch " + url, e);
        throw new RuntimeException(e);
    }
}