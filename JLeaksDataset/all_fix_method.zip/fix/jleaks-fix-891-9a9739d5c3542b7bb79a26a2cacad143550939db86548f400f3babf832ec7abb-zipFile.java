public String zipFile(File baseDir, File fileToCompress) throws IOException 
{
    checkArgument(fileToCompress.isFile(), "File should be a file: " + fileToCompress);
    try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(bos)) {
        addToZip(baseDir.getAbsolutePath(), zos, fileToCompress);
        return Base64.getEncoder().encodeToString(bos.toByteArray());
    }
}