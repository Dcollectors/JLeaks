public void execute() throws IOException 
{
    logger.info("packing ratings from {}", input);
    logger.debug("using delimiter {}", getDelimiter());
    EventDAO dao = input.getEventDAO();
    if (dao == null) {
        throw new IOException("no data source specified");
    }
    EnumSet<BinaryFormatFlag> flags = EnumSet.noneOf(BinaryFormatFlag.class);
    if (useTimestamps()) {
        flags.add(BinaryFormatFlag.TIMESTAMPS);
    }
    logger.info("packing to {} with flags {}", getOutputFile(), flags);
    try (BinaryRatingPacker packer = BinaryRatingPacker.open(getOutputFile(), flags);
        Cursor<Rating> ratings = dao.streamEvents(Rating.class)) {
        packer.writeRatings(ratings);
        logger.info("packed {} ratings", packer.getRatingCount());
    }
}