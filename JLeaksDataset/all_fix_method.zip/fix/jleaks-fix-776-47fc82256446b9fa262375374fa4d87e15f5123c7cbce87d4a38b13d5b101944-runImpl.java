protected void runImpl(DatabaseContext2 dbCtx)
{
    try {
        AllEntityDao entityDao;
        sink.initialize(Collections.<String, Object>emptyMap());
        new SchemaVersionValidator(loginCredentials, preferences).validateVersion(ApidbVersionConstants.SCHEMA_MIGRATIONS);
        entityDao = new AllEntityDao(dbCtx.getJdbcTemplate());
        sink.process(new BoundContainer(new Bound("Osmosis " + OsmosisConstants.VERSION)));
        try (ReleasableIterator<EntityContainer> reader = entityDao.getCurrent()) {
            while (reader.hasNext()) {
                sink.process(reader.next());
            }
        }
        sink.complete();
    } finally {
        sink.close();
    }
}