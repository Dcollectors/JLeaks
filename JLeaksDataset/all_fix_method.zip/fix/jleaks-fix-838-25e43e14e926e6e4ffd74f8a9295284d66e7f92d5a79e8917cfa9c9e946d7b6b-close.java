public void close() 
{
    if (result != null) {
        try {
            result.close();
        } catch (Exception ignored) {
            // Purposely ignored, cannot do anything else here but log it.
            if ((log != null) && (log.isDebug())) {
                log.logDebug(ignored.getMessage());
            }
        }
        result = null;
    }
    if (query != null) {
        try {
            query.close();
        } catch (Exception ignored) {
            // Purposely ignored, cannot do anything else here but log it.
            if ((log != null) && (log.isDebug())) {
                log.logDebug(ignored.getMessage());
            }
        }
        query = null;
    }
    if (connection != null) {
        try {
            connection.close();
        } catch (Exception ignored) {
            // Purposely ignored, cannot do anything else here but log it.
            if ((log != null) && (log.isDebug())) {
                log.logDebug(ignored.getMessage());
            }
        }
        connection = null;
    }
}