    public void execute() throws IOException {
        logger.info("packing ratings from {}", input);
        logger.debug("using delimiter {}", getDelimiter());
        EventDAO dao = input.getEventDAO();
        if (dao == null) {
            throw new IOException("no data source specified");
        }
        EnumSet<BinaryFormatFlag> flags = EnumSet.noneOf(BinaryFormatFlag.class);
        if (useTimestamps()) {
            flags.add(BinaryFormatFlag.TIMESTAMPS);
        }
        logger.info("packing to {} with flags {}", getOutputFile(), flags);
        Closer closer = Closer.create();
        try {
            BinaryRatingPacker packer = closer.register(BinaryRatingPacker.open(getOutputFile(), flags));
            Cursor<Rating> ratings = closer.register(dao.streamEvents(Rating.class));
            packer.writeRatings(ratings);
            logger.info("packed {} ratings", packer.getRatingCount());
        } catch (Throwable th) { // NOSONAR using a closer
            throw closer.rethrow(th);
        } finally {
            closer.close();
        }
    }
