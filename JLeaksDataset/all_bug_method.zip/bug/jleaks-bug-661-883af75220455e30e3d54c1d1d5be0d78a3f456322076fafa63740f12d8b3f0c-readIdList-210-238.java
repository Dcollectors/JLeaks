    public static LongList readIdList(File file) throws IOException {
        LongList items = new LongArrayList();
        Closer closer = Closer.create();
        try {
            FileReader fread = closer.register(new FileReader(file));
            BufferedReader buf = closer.register(new BufferedReader(fread));
            String line;
            int lno = 0;
            while ((line = buf.readLine()) != null) {
                lno += 1;
                if (line.trim().isEmpty()) {
                    continue; // skip blank lines
                }
                long item;
                try {
                    item = Long.parseLong(line.trim());
                } catch (IllegalArgumentException ex) {
                    throw new IOException("invalid ID on " + file + " line " + lno + ": " + line);
                }
                items.add(item);
            }
        } catch (Throwable th) { // NOSONAR using a closer
            throw closer.rethrow(th);
        } finally {
            closer.close();
        }
        return items;
    }
