    public void close() throws IOException {
        super.close();
        out.close();
    }
