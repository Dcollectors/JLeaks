	public void write(
		JRReport report,
		String destFileName
		) throws JRException
	{
		OutputStream os = null;
		
		try
		{
			os = new BufferedOutputStream(new FileOutputStream(destFileName));
			String encoding = report.getProperty(WriterExporterOutput.PROPERTY_CHARACTER_ENCODING) != null
			? report.getProperty(WriterExporterOutput.PROPERTY_CHARACTER_ENCODING)
			: "UTF-8";//FIXME this is an export time config property
			Writer out = new OutputStreamWriter(os, encoding);
			writeReport(report, out);
		}
		catch (IOException e)
		{
			throw 
				new JRException(
					EXCEPTION_MESSAGE_KEY_FILE_WRITE_ERROR,
					new Object[]{destFileName},
					e);
		}
		finally
		{
			if (os != null)
			{
				try
				{
					os.close();
				}
				catch(IOException e)
				{
				}
			}
		}
	}
