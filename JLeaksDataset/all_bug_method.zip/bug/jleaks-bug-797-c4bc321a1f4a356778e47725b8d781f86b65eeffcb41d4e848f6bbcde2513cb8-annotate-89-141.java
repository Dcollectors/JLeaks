    public Annotation annotate(File file, String rev) throws IOException {

        Annotation a = new Annotation(file.getName());

        ArrayList<String> cmd = new ArrayList<String>();

        /*
         * ----------------------------------------------- Strip off source root
         * to get to workspace path.
        *-----------------------------------------------
         */
        String path = getDepotRelativePath(file);

        cmd.add(this.cmd);
        cmd.add("annotate");
        cmd.add("-fvu");      // version & user

        if (rev != null) {
            cmd.add("-v");
            cmd.add(rev.trim());
        }

        cmd.add(path);

        Executor executor = new Executor(cmd, file.getParentFile());
        executor.exec();

        BufferedReader reader = new BufferedReader(executor.getOutputReader());
        String line;
        int lineno = 0;
        try {
            while ((line = reader.readLine()) != null) {
                ++lineno;
                Matcher matcher = annotationPattern.matcher(line);

                if (matcher.find()) {
                    String version = matcher.group(1);
                    String author = matcher.group(2);
                    a.addLine(version, author, true);
                } else {
                    OpenGrokLogger.getLogger().log(Level.SEVERE,
                            "Did not find annotation in line "
                            + lineno + ": [" + line + "]");
                }
            }
        } catch (IOException e) {
            OpenGrokLogger.getLogger().log(Level.SEVERE,
                    "Could not read annotations for " + file, e);
        }

        IOUtils.close(reader);
        return a;
    }
