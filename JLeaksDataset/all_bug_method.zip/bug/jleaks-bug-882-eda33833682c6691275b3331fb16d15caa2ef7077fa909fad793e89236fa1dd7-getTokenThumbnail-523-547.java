  public static BufferedImage getTokenThumbnail(File file) throws Exception {
    PackedFile pakFile = new PackedFile(file);
    BufferedImage thumb;
    String thumbFileName = Token.FILE_THUMBNAIL;

    // Jamz: Lets use the Large thumbnail if needed
    if ((MapTool.getThumbnailSize().width > 50 || MapTool.getThumbnailSize().height > 50)
        && pakFile.hasFile(Token.FILE_THUMBNAIL_LARGE)) thumbFileName = Token.FILE_THUMBNAIL_LARGE;

    try {
      thumb = null;
      if (pakFile.hasFile(thumbFileName)) {
        InputStream is = null;
        try {
          is = pakFile.getFileAsInputStream(thumbFileName);
          thumb = ImageIO.read(is);
        } finally {
          IOUtils.closeQuietly(is);
        }
      }
    } finally {
      pakFile.close();
    }
    return thumb;
  }
