  public void myWonderfulUseCase() {
    // Generate span
    Span span = tracer.spanBuilder("Start my wonderful use case").startSpan();
    // Add some Event to the span
    span.addEvent("Event 0");
    // execute my use case - here we simulate a wait
    doWork();
    // Add some Event to the span
    span.addEvent("Event 1");
    span.end();
  }
