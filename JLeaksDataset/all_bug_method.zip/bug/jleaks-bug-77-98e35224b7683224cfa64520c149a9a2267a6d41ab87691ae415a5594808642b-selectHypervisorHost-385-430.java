    public EndPoint selectHypervisorHost(Scope scope) {
        StringBuilder sbuilder = new StringBuilder();
        sbuilder.append(findOneHypervisorHostInScope);
        if (scope.getScopeType() == ScopeType.ZONE) {
            sbuilder.append(" and h.data_center_id = ");
            sbuilder.append(scope.getScopeId());
        } else if (scope.getScopeType() == ScopeType.CLUSTER) {
            sbuilder.append(" and h.cluster_id = ");
            sbuilder.append(scope.getScopeId());
        }
        sbuilder.append(" ORDER by rand() limit 1");

        String sql = sbuilder.toString();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        HostVO host = null;
        TransactionLegacy txn = TransactionLegacy.currentTxn();

        try {
            pstmt = txn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                long id = rs.getLong(1);
                host = hostDao.findById(id);
            }
        } catch (SQLException e) {
            s_logger.warn("can't find endpoint", e);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException e) {
            }
        }

        if (host == null) {
            return null;
        }

        return RemoteHostEndPoint.getHypervisorHostEndPoint(host);
    }
