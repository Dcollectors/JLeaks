    public void close() throws IOException {
        flush();
    }
