        private void handleImpl(HttpExchange exchange) throws IOException {
            totalRequestsServiced++;
            InputStream is = exchange.getRequestBody();
            byte[] isBuf = new byte[is.available() + 1];
            int off = 0;
            int len;
            try {
                while ((len = is.read(isBuf, off, isBuf.length - off)) != -1) {
                    off += len;
                    if (off == isBuf.length) {
                        byte[] newBuf = new byte[isBuf.length + Math.max(isBuf.length, is.available() + 1)];
                        System.arraycopy(isBuf, 0, newBuf, 0, off);
                        isBuf = newBuf;
                    }
                }
            } finally {
                is.close();
            }
            if (log.isLoggable(Level.FINER)) {
                log.finer(RemoteDeviceDataExchange.bytesToString("Server Input: ", isBuf, off));
            }

            if (off == 0) {
                throw new IOException("Empty request to grid server");
            }
            totalBytesRead += off;
            RemoteDeviceDataExchange paramsDecoder = new RemoteDeviceDataExchange(isBuf, off);
            byte commandId = paramsDecoder.readByte();
            // Optimistically write ok status for all ops (revert if necessary)
            resultEncoder.writeByte(RemoteDevice.STATUS_OK);
            boolean checkServerClose = false;
            RuntimeException rExc = null;
            try {
                if (commandId == RemoteDevice.CREATE_IMAGE) {
                    DeviceType type = DeviceType.values()[paramsDecoder.readInt()];
                    String filename = paramsDecoder.readString();
                    String fileType = paramsDecoder.readString();
                    int width = paramsDecoder.readInt();
                    int height = paramsDecoder.readInt();
                    int deviceId;
                    synchronized (RemoteDeviceServer.class) {
                        deviceId = ++lastDeviceId;
                    }
                    GridDevice device;
                    switch (type) {
                        case BUFFERED_IMAGE:
                            try {
                                device = GridContext.openLocalOrRemoteDevice(filename, fileType, width, height);
                            } catch (NotSupportedImageFormatException ex) {
                                deviceId = -1;
                                device = null;
                            }
                            break;
                        case WINDOW:
                            device = WindowDevice.createWindowDevice(true, width, height);
                            break;
                        default:
                            throw new AssertionError();
                    }
                    if (deviceId != -1) {
                        id2Device.put(deviceId, device);
                    }
                    resultEncoder.writeInt(deviceId);
                } else if (commandId == RemoteDevice.CREATE_DRAWING_CONTEXT) {
                    ServerDrawingContext ctx = new ServerDrawingContext(paramsDecoder);
                    Integer ctxId = drawingContext2id.get(ctx);
                    if (ctxId == null) {
                        synchronized (RemoteDeviceServer.class) {
                            ctxId = ++lastDrawingContextId;
                            id2DrawingContext.put(ctxId, ctx);
                            drawingContext2id.put(ctx, ctxId);
                        }
                    } else {
                        synchronized (RemoteDeviceServer.class) {
                            ctx = getDrawingContextImpl(ctxId);
                            ctx.incRefCount();
                        }
                    }
                    resultEncoder.writeInt(ctxId);
                } else if (commandId == RemoteDevice.RELEASE_DRAWING_CONTEXT) {
                    int ctxId = paramsDecoder.readInt();
                    synchronized (RemoteDeviceServer.class) {
                        releaseDrawingContextImpl(ctxId);
                    }
                } else {
                    Integer deviceId = paramsDecoder.readInt();
                    GridDevice device = id2Device.get(deviceId);
                    if (device == null) {
                        throw new IllegalStateException("Grid device for id=" + deviceId + " does not exist on server.");
                    }
                    switch (commandId) {
                        case RemoteDevice.OPEN_NEW_PAGE: {
                            device.openNewPage();
                            break;
                        }
                        case RemoteDevice.HOLD: {
                            device.hold();
                            break;
                        }
                        case RemoteDevice.FLUSH: {
                            device.flush();
                            break;
                        }
                        case RemoteDevice.CLOSE: {
                            int[] releaseDrawingContextIds = paramsDecoder.readIntArray();
                            synchronized (RemoteDeviceServer.class) {
                                for (int i = 0; i < releaseDrawingContextIds.length; i++) {
                                    int ctxId = releaseDrawingContextIds[i];
                                    if (ctxId != 0) {
                                        releaseDrawingContextImpl(ctxId);
                                    }
                                }
                            }
                            id2Device.remove(deviceId);
                            checkServerClose = true;
                            String exMsg = null;
                            try {
                                device.close();
                            } catch (DeviceCloseException ex) {
                                exMsg = ex.getMessage();
                            }
                            resultEncoder.writeString(exMsg);
                            break;
                        }
                        case RemoteDevice.DRAW_RECT: {
                            DrawingContext ctx = getDrawingContext(paramsDecoder.readInt());
                            double leftX = paramsDecoder.readDouble();
                            double bottomY = paramsDecoder.readDouble();
                            double width = paramsDecoder.readDouble();
                            double height = paramsDecoder.readDouble();
                            double rotationAnticlockWise = paramsDecoder.readDouble();
                            device.drawRect(ctx, leftX, bottomY, width, height, rotationAnticlockWise);
                            break;
                        }
                        case RemoteDevice.DRAW_POLY_LINES: {
                            DrawingContext ctx = getDrawingContext(paramsDecoder.readInt());
                            double[] x = paramsDecoder.readDoubleArray();
                            double[] y = paramsDecoder.readDoubleArray();
                            int startIndex = paramsDecoder.readInt();
                            int length = paramsDecoder.readInt();
                            device.drawPolyLines(ctx, x, y, startIndex, length);
                            break;
                        }
                        case RemoteDevice.DRAW_POLYGON: {
                            DrawingContext ctx = getDrawingContext(paramsDecoder.readInt());
                            double[] x = paramsDecoder.readDoubleArray();
                            double[] y = paramsDecoder.readDoubleArray();
                            int startIndex = paramsDecoder.readInt();
                            int length = paramsDecoder.readInt();
                            device.drawPolygon(ctx, x, y, startIndex, length);
                            break;
                        }
                        case RemoteDevice.DRAW_CIRCLE: {
                            DrawingContext ctx = getDrawingContext(paramsDecoder.readInt());
                            double centerX = paramsDecoder.readDouble();
                            double centerY = paramsDecoder.readDouble();
                            double radius = paramsDecoder.readDouble();
                            device.drawCircle(ctx, centerX, centerY, radius);
                            break;
                        }
                        case RemoteDevice.DRAW_RASTER: {
                            double leftX = paramsDecoder.readDouble();
                            double bottomY = paramsDecoder.readDouble();
                            double width = paramsDecoder.readDouble();
                            double height = paramsDecoder.readDouble();
                            int[] pixels = paramsDecoder.readIntArray();
                            int pixelsColumnsCount = paramsDecoder.readInt();
                            ImageInterpolation interpolation = ImageInterpolation.values()[paramsDecoder.readInt()];
                            device.drawRaster(leftX, bottomY, width, height, pixels, pixelsColumnsCount, interpolation);
                            break;
                        }
                        case RemoteDevice.DRAW_STRING: {
                            DrawingContext ctx = getDrawingContext(paramsDecoder.readInt());
                            double leftX = paramsDecoder.readDouble();
                            double bottomY = paramsDecoder.readDouble();
                            double rotationAnticlockWise = paramsDecoder.readDouble();
                            String text = paramsDecoder.readString();
                            device.drawString(ctx, leftX, bottomY, rotationAnticlockWise, text);
                            break;
                        }
                        case RemoteDevice.GET_WIDTH: {
                            resultEncoder.writeDouble(device.getWidth());
                            break;
                        }
                        case RemoteDevice.GET_HEIGHT: {
                            resultEncoder.writeDouble(device.getHeight());
                            break;
                        }
                        case RemoteDevice.GET_NATIVE_WIDTH: {
                            resultEncoder.writeDouble(device.getNativeWidth());
                            break;
                        }
                        case RemoteDevice.GET_NATIVE_HEIGHT: {
                            resultEncoder.writeDouble(device.getNativeHeight());
                            break;
                        }
                        case RemoteDevice.GET_STRING_WIDTH: {
                            DrawingContext ctx = getDrawingContext(paramsDecoder.readInt());
                            String text = paramsDecoder.readString();
                            resultEncoder.writeDouble(device.getStringWidth(ctx, text));
                            break;
                        }
                        case RemoteDevice.GET_STRING_HEIGHT: {
                            DrawingContext ctx = getDrawingContext(paramsDecoder.readInt());
                            String text = paramsDecoder.readString();
                            resultEncoder.writeDouble(device.getStringHeight(ctx, text));
                            break;
                        }
                        default:
                            throw new IllegalStateException("Invalid requestId=" + commandId);
                    }
                }
            } catch (RuntimeException ex) {
                rExc = ex;
            }
            byte[] osBuf = resultEncoder.resetWrite();
            if (rExc != null) {
                resultEncoder.writeByte(RemoteDevice.STATUS_SERVER_ERROR);
                osBuf = resultEncoder.resetWrite();
            }
            if (log.isLoggable(Level.FINER)) {
                log.finer(RemoteDeviceDataExchange.bytesToString("Server Output: ", osBuf, osBuf.length));
            }
            exchange.sendResponseHeaders(200, osBuf.length);
            OutputStream os = exchange.getResponseBody();
            try {
                os.write(osBuf);
            } finally {
                os.close();
            }
            totalBytesWritten += osBuf.length;
            exchange.close();
            if (checkServerClose && rExc == null && id2Device.isEmpty()) {
                log.fine("Server closing automatically after last device was closed.");
                server.stop(0);
                System.exit(0);
            }
            if (rExc != null) {
                throw rExc;
            }
        }
