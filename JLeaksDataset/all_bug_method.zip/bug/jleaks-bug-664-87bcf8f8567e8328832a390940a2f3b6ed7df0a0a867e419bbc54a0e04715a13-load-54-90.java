	public <T extends ImageBase<T>> SimpleImageSequence<T> load(String fileName, ImageType<T> imageType) {

		// Use built in movie readers for these file types
		if( fileName.endsWith("mjpeg") || fileName.endsWith("MJPEG") ||
				fileName.endsWith("mjpg") || fileName.endsWith("MJPG") ) {
			try {
				VideoMjpegCodec codec = new VideoMjpegCodec();
				List<byte[]> data = codec.read(new FileInputStream(fileName));
				return new JpegByteImageSequence<>(imageType, data, false);
			} catch (FileNotFoundException e) {
				throw new RuntimeException(e);
			}
		} else if( fileName.endsWith("mpng") || fileName.endsWith("MPNG")) {
			try {
				return new ImageStreamSequence<>(fileName, true, imageType);
			} catch (FileNotFoundException e) {
				throw new RuntimeException(e);
			}
		}

		try {
			if( ffmpeg != null ) {
				return ffmpeg.load(fileName, imageType);
			}
		} catch( RuntimeException ignore ){}

		try {
			if( jcodec != null ) {
				if( fileName.endsWith(".mp4") || fileName.endsWith(".MP4")) {
					return jcodec.load(fileName,imageType);
				}
			}
		} catch( RuntimeException ignore ){}
		System.err.println("No working codec found for file: " + fileName);
		return null;
	}

