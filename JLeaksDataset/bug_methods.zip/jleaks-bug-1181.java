	public static boolean isZipFile( String path )
	{
		if ( path == null )
			return false;
		try
		{
			new ZipFile( path );
			return true;
		}
		catch ( IOException e )
		{
			return false;
		}
	}