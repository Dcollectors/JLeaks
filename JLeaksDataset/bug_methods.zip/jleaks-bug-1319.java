    public static String getFileContent(@NonNull File file, @NonNull String emptyValue) {
        if (!file.exists() || file.isDirectory()) return emptyValue;
        try {
            return getInputStreamContent(new FileInputStream(file));
        } catch (IOException e) {
            if (!(e.getCause() instanceof ErrnoException)) {
                // This isn't just another EACCESS exception
                e.printStackTrace();
            }
        }
        if (AppPref.isRootOrAdbEnabled()) {
            return RunnerUtils.cat(file.getAbsolutePath(), emptyValue);
        }
        return emptyValue;
    }