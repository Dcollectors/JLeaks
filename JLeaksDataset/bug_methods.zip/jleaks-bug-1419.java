    public void touch(final Path file, final TransferStatus status) throws BackgroundException {
        write.write(file, status);
    }