  private byte[] loadBytes(InputStream inputStream) {
    ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
    try {
      byte[] buf = new byte[512];
      int len;
      while (true) {
        len = inputStream.read(buf);
        if (len == -1) {
          break;
        }
        byteStream.write(buf, 0, len);
      }
      inputStream.close();
      byteStream.close();
      return byteStream.toByteArray();

     } catch (IOException ex) {
      throw new RepositoryException("Couldn't load from InputStream of content, check nested exception.", ex);
    }
  }