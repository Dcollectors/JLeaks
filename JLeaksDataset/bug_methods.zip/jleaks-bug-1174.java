    private static <T> T parseResponse(final Class<T> resultType, final HttpURLConnection connection) throws IOException {
        throwIOExceptionOnErrorResponse(connection);

        final InputStream stream = connection.getInputStream();
        final T response = MAPPER.readValue(stream, resultType);
        stream.close();
        return response;
    }