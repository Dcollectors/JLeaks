  private void executeIdempotentImport(
      UUID jobId,
      IdempotentImportExecutor idempotentImportExecutor,
      Collection<? extends DownloadableFile> downloadableFiles)
      throws Exception {
    for (DownloadableFile downloadableFile : downloadableFiles) {
      idempotentImportExecutor.executeAndSwallowIOExceptions(
          downloadableFile.getIdempotentId(),
          downloadableFile.getName(),
          () -> importDownloadableItem(downloadableFile, jobId, idempotentImportExecutor));
    }
  }

  private String importDownloadableItem(
      DownloadableFile item, UUID jobId, IdempotentImportExecutor idempotentImportExecutor)
      throws Exception {
    final long totalFileSize = discardForLength(jobFileStream.streamFile(item, jobId, jobStore));
    if (totalFileSize <= 0) {
      throw new IOException(
          String.format(
              "jobid %s hit empty unexpectedly empty (bytes=%d) download for file %s",
              jobId, totalFileSize, item.getFetchableUrl()));
    }
    InputStream fileStream = jobFileStream.streamFile(item, jobId, jobStore);

    String itemUploadUrl = createUploadSession(item, idempotentImportExecutor);

    Response finalChunkResponse =
        uploadStreamInChunks(totalFileSize, itemUploadUrl, item.getMimeType(), fileStream);
    fileStream.close();
    if (finalChunkResponse.code() != 200 && finalChunkResponse.code() != 201) {
      // Once we upload the last chunk, we should have either 200 or 201.
      // TODO: This should change to a precondition check after we debug some more.
      monitor.debug(
          () -> "Received a bad code on completion of uploading chunks", finalChunkResponse.code());
    }
    // get complete file response
    ResponseBody finalChunkResponseBody = finalChunkResponse.body();
    Map<String, Object> chunkResponseData =
        objectMapper.readValue(finalChunkResponseBody.bytes(), Map.class);
    return (String) chunkResponseData.get("id");
  }