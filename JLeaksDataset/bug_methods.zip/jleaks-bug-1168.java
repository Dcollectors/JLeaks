    private void readCounts()
            throws IOException
    {
        unigrams = new HashMap<>();
        bigrams = new HashMap<>();

        getLogger().info("Reading frequencies from " + modelLocation);
        BufferedReader reader = new BufferedReader(new InputStreamReader(CompressionUtils
                .getInputStream(modelLocation, new FileInputStream(modelLocation))));
        boolean countingUnigrams = true;

        String line;
        while ((line = reader.readLine()) != null) {
            if (line.equals(FrequencyCounter.NGRAM_SEPARATOR_LINE)) {
                countingUnigrams = false;
                continue;
            }
            String[] columns = line.split(FrequencyCounter.COLUMN_SEPARATOR);
            assert columns.length == 2;
            if (countingUnigrams) {
                unigrams.put(columns[0], Integer.parseInt(columns[1]));
            }
            else {
                bigrams.put(columns[0], Integer.parseInt(columns[1]));
            }
        }
    }