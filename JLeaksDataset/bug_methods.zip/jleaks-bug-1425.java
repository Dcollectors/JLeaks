    public void close() throws BackgroundException {
        this.fireConnectionWillCloseEvent();
        this.logout();
        this.disconnect();
        this.fireConnectionDidCloseEvent();
    }