  public String readFile(InputFile file) throws IOException {
    return CharStreams.toString(file.openReader(charset));
  }