  public void writeBytesToPath(byte[] bytes, Path pathRelativeToProjectRoot) throws IOException {
    Path path = getPathForRelativePath(pathRelativeToProjectRoot);
    java.nio.file.Files.newOutputStream(path).write(bytes);
  }