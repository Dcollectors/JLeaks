    public void writeMetaFile(File mOutDir, Map<String, Object> meta)
            throws AndrolibException {
        DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
//        options.setIndent(4);
        Yaml yaml = new Yaml(options);
        try {
            yaml.dump(meta, new FileWriter(new File(mOutDir, "apktool.yml")));
        } catch (IOException ex) {
            throw new AndrolibException(ex);
        }
    }