  public static String[] tail(File f, int n, String encoding) throws IOException {
    if (n == 0) { return new String[0]; }
    // Variables
    RandomAccessFile raf = new RandomAccessFile(f, "r");
    int linesRead = 0;
    List<Byte> bytes = new ArrayList<Byte>();
    List<String> linesReversed = new ArrayList<String>();
    // Seek to end of file
    long length = raf.length() - 1;
    raf.seek(length);
    // Read backwards
    for(long seek = length; seek >= 0; --seek){
      // Seek back
      raf.seek(seek);
      // Read the next character
      byte c = raf.readByte();
      if(c == '\n'){
        // If it's a newline, handle adding the line
        byte[] str = new byte[bytes.size()];
        for (int i = 0; i < str.length; ++i) {
          str[i] = bytes.get(str.length - i - 1);
        }
        linesReversed.add(new String(str, encoding));
        bytes = new ArrayList<Byte>();
        linesRead += 1;
        if (linesRead == n){
          break;
        }
      } else {
        // Else, register the character for later
        bytes.add(c);
      }
    }
    // Add any remaining lines
    if (linesRead < n && bytes.size() > 0) {
      byte[] str = new byte[bytes.size()];
      for (int i = 0; i < str.length; ++i) {
        str[i] = bytes.get(str.length - i - 1);
      }
      linesReversed.add(new String(str, encoding));
    }
    // Create output
    String[] rtn = new String[linesReversed.size()];
    for (int i = 0; i < rtn.length; ++i) {
      rtn[i] = linesReversed.get(rtn.length - i - 1);
    }
    return rtn;
  }