    public long getLastModified() {
        try {
            URLConnection conn = getURL().openConnection();
            long date = conn.getLastModified();
            return date;
        } catch ( IOException e ) {
            throw new RuntimeException( "Unable to get LastModified for ClasspathResource",
                                        e );
        }
    }