    public PropertiesConfiguration getConfiguration(final ConfigurationSource source) {
        final InputStream configStream = source.getInputStream();
        final Properties properties = new Properties();
        try {
            properties.load(configStream);
        } catch (final IOException ioe) {
            throw new ConfigurationException("Unable to load " + source.toString(), ioe);
        }
        return new PropertiesConfigurationBuilder().setConfigurationSource(source)
                .setRootProperties(properties).build();
    }