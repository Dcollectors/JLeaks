    public void sendCommand(String command) throws IOException {
        final ch.ethz.ssh2.Session sess = this.getClient().openSession();
        try {
            this.message(command);

            sess.execCommand(command, host.getEncoding());

            BufferedReader stdoutReader = new BufferedReader(new InputStreamReader(new StreamGobbler(sess.getStdout())));
            BufferedReader stderrReader = new BufferedReader(new InputStreamReader(new StreamGobbler(sess.getStderr())));

            // Here is the output from stdout
            while(true) {
                String line = stdoutReader.readLine();
                if(null == line) {
                    break;
                }
                this.log(false, line);
            }
            // Here is the output from stderr
            StringBuilder error = new StringBuilder();
            while(true) {
                String line = stderrReader.readLine();
                if(null == line) {
                    break;
                }
                this.log(false, line);
                // Standard error output contains all status messages, not only errors.
                if(StringUtils.isNotBlank(error.toString())) {
                    error.append(" ");
                }
                error.append(line).append(".");
            }
            if(StringUtils.isNotBlank(error.toString())) {
                this.error(error.toString(), null);
            }
        }
        finally {
            sess.close();
        }
    }