    protected void refreshSchema(boolean printReplicaIdentityInfo) throws SQLException {
        schema.refresh(createConnection(), printReplicaIdentityInfo);
    }