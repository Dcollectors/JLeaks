    public int loadTerms(InputStream is, org.grobid.core.analyzers.Analyzer analyzer, boolean caseSensitive) throws IOException {
        InputStreamReader reader = new InputStreamReader(is, UTF_8);
        BufferedReader bufReader = new BufferedReader(reader);
        String line;
        if (terms == null) {
            terms = new HashMap();
        }
        int nbTerms = 0;
        while ((line = bufReader.readLine()) != null) {
            if (line.length() == 0) continue;
            line = UnicodeUtil.normaliseText(line);
            line = StringUtils.normalizeSpace(line);
            if (!caseSensitive)
                line = line.toLowerCase();
            nbTerms += loadTerm(line, analyzer, true);
        }
        bufReader.close();
        reader.close();

        return nbTerms;
    }