  public static MicrosoftApiResponse ofResponse(Response response) {
    Builder builder =
        MicrosoftApiResponse.builder()
            .setHttpMessage(response.message())
            .setHttpStatus(response.code());

    if (response.body() != null) {
      builder.setBody(response.body());
    }

    return builder.build();
  }