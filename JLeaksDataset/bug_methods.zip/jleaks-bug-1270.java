    public static ImportControl load(final URI uri) throws CheckstyleException {
        final InputStream inputStream;
        try {
            inputStream = uri.toURL().openStream();
        }
        catch (final MalformedURLException ex) {
            throw new CheckstyleException("syntax error in url " + uri, ex);
        }
        catch (final IOException ex) {
            throw new CheckstyleException("unable to find " + uri, ex);
        }
        final InputSource source = new InputSource(inputStream);
        return load(source, uri);
    }