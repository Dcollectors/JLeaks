	public ConsumerDetails getObject() throws Exception {
		if ("rsa-cert".equals(typeOfSecret)) {
			try {
				Certificate cert = CertificateFactory.getInstance("X.509").generateCertificate(resourceLoader.getResource(secret).getInputStream());
				consumer.setSignatureSecret(new RSAKeySecret(cert.getPublicKey()));
			}
			catch (IOException e) {
				throw new BeanCreationException("RSA certificate not found at " + secret + ".",
						e);
			}
			catch (CertificateException e) {
				throw new BeanCreationException("Invalid RSA certificate at " + secret + ".", e);
			}
			catch (NullPointerException e) {
				throw new BeanCreationException("Could not load RSA certificate at " + secret + ".", e);
			}
		}
		else {
			consumer.setSignatureSecret(new SharedConsumerSecretImpl(secret));
		}
		return consumer;
	}