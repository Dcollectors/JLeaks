  public static OCFile createNewFile(ContentProviderClient cr, Account account,
      String path, long length, long creation_timestamp,
      long modified_timestamp, String mimetype, long parent_id) {
    OCFile new_file = new OCFile(cr, account);

    try {
      Cursor c = new_file.cp_.query(ProviderTableMeta.CONTENT_URI_FILE, null,
          ProviderTableMeta.FILE_ACCOUNT_OWNER + "=? AND "
              + ProviderTableMeta.FILE_PATH + "=?", new String[]{new_file.account_.name,
              path}, null);
      if (c.moveToFirst())
        new_file.setFileData(c);
    } catch (RemoteException e) {
      Log.e(TAG, e.getMessage());
    }

    new_file.path_ = path;
    new_file.length_ = length;
    new_file.creation_timestamp_ = creation_timestamp;
    new_file.modified_timestamp_ = modified_timestamp;
    new_file.mimetype_ = mimetype;
    new_file.parent_id_ = parent_id;
    Log.e(TAG, parent_id+"");

    return new_file;
  }