    public Tab findTab(int tabNo) {
        String query = "Select * FROM " + TABLE_TAB + " WHERE " + COLUMN_TAB_NO + "= \"" + tabNo + "\"";
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        Tab tab = new Tab();
        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            tab.setTab((cursor.getInt(0)));
            tab.setPath(cursor.getString(1));
            tab.setHome(cursor.getString(2));
            cursor.close();
        } else {
            tab = null;
        }
        sqLiteDatabase.close();
        return tab;
    }

    public List<Tab> getAllTabs() {
        List<Tab> tabList = new ArrayList<Tab>();
        // Select all query
        String query = "Select * FROM " + TABLE_TAB;

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        // Looping through all rows and adding them to list
        if (cursor.getCount() > 0 && cursor.moveToFirst()) {
            do {
                Tab tab = new Tab();
                tab.setTab((cursor.getInt(0)));
                tab.setPath(cursor.getString(1));
                tab.setHome(cursor.getString(2));
                //Adding them to list
                tabList.add(tab);
            } while (cursor.moveToNext());
        }
        sqLiteDatabase.close();
        return tabList;
    }