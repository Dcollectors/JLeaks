    public PropsUtil(final String propsLocn) {
        this.props = new Properties();
        final ClassLoader loader = ProviderUtil.findClassLoader();
        final InputStream in = loader.getResourceAsStream(propsLocn);
        if (null != in) {
            try {
                this.props.load(in);
                in.close();
            } catch (final java.io.IOException e) {
                // ignored
            }
        }
    }