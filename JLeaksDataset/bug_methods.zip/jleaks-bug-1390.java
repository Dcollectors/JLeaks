    public void setCacheFile(final File cacheDir, final boolean enabled) {
        cacheFile = new File(cacheDir, "weatherCache.bin");

        if (enabled) {
            LOG.info("Setting weather cache file to {}", cacheFile.getPath());

            if (cacheFile.isFile() && weatherSpec == null) {
                try {
                    final FileInputStream f = new FileInputStream(cacheFile);
                    final ObjectInputStream o = new ObjectInputStream(f);

                    weatherSpec = (WeatherSpec) o.readObject();

                    o.close();
                    f.close();
                } catch (final Throwable e) {
                    LOG.error("Failed to read weather from cache", e);
                    weatherSpec = null;
                    cacheFile = null;
                }
            } else if (weatherSpec != null) {
                saveToCache();
            }
        } else {
            if (cacheFile.isFile()) {
                LOG.info("Deleting weather cache file {}", cacheFile.getPath());

                try {
                    cacheFile.delete();
                } catch (final Throwable e) {
                    LOG.error("Failed to delete cache file", e);
                    cacheFile = null;
                }
            }
        }
    }