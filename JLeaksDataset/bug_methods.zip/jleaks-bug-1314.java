  public static Properties loadPropertiesFromResource(URL resource) {
    try {
      return loadProperties(resource.openStream());
    } catch (IOException e) {
      LOG.warn("Failed to read properties from {}: {}", resource, e.toString());
      return null;
    }
  }