    private static void downloadLocale(String locale) {
        File localeFile = GeyserConnector.getInstance().getBootstrap().getConfigFolder().resolve("locales/" + locale + ".json").toFile();

        // Check if we have already downloaded the locale file
        if (localeFile.exists()) {
            String curHash = "";
            String targetHash = "";

            if (locale.equals("en_us")) {
                try {
                    File hashFile = GeyserConnector.getInstance().getBootstrap().getConfigFolder().resolve("locales/en_us.hash").toFile();
                    if (hashFile.exists()) {
                        BufferedReader br = new BufferedReader(new FileReader(hashFile));
                        curHash = br.readLine().trim();
                    }
                } catch (IOException ignored) { }
                targetHash = clientJarInfo.getSha1();
            } else {
                curHash = byteArrayToHexString(FileUtils.calculateSHA1(localeFile));
                targetHash = ASSET_MAP.get("minecraft/lang/" + locale + ".json").getHash();
            }

            if (!curHash.equals(targetHash)) {
                GeyserConnector.getInstance().getLogger().debug("Locale out of date; re-downloading: " + locale);
            } else {
                GeyserConnector.getInstance().getLogger().debug("Locale already downloaded and up-to date: " + locale);
                return;
            }
        }

        // Create the en_us locale
        if (locale.equals("en_us")) {
            downloadEN_US(localeFile);

            return;
        }

        // Get the hash and download the locale
        String hash = ASSET_MAP.get("minecraft/lang/" + locale + ".json").getHash();
        WebUtils.downloadFile("https://resources.download.minecraft.net/" + hash.substring(0, 2) + "/" + hash, localeFile.toString());
    }