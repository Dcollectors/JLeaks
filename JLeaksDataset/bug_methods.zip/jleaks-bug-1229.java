    public static void validateTwoSegments(File dir1, File dir2) throws IOException
    {
      validateTwoSegments(
          new QueryableIndexIndexableAdapter(loadIndex(dir1)),
          new QueryableIndexIndexableAdapter(loadIndex(dir2))
      );
    }