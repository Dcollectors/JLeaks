    public void close() {
        // close everything
        for (NostrRTCSocket socket : connections.values()) {
            socket.close();
        }
        for (PendingConnection conn : pendingInitiatedConnections.values()) {
            conn.socket.close();
        }
        this.signaling.close();
        this.executor.close();
    }