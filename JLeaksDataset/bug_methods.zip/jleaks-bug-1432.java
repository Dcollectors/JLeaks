	private void doReadXML(InputStream in, Project project, File base) throws IOException, DocumentException {

		checkInputStream(in);

		try {
			SAXBugCollectionHandler handler = new SAXBugCollectionHandler(this, project, base);

			
			XMLReader xr = null;
            if (true) try { // FIXME: try this in 1.1.4
                xr = XMLReaderFactory.createXMLReader();
              } catch (SAXException e) {
                AnalysisContext.logError("Couldn't create XMLReaderFactory", e);   
              }
            
            if (xr == null) {
               //  FIXME: for now, use dom4j's XML parser
                xr = new org.dom4j.io.aelfred.SAXDriver();
                }
			xr.setContentHandler(handler);
			xr.setErrorHandler(handler);

			Reader reader = new InputStreamReader(in);

			xr.parse(new InputSource(reader));
		} catch (SAXParseException e) {
			throw new DocumentException("Parse error at line " + e.getLineNumber()
					+ " : " + e.getColumnNumber(), e);
		} catch (SAXException e) {
			// FIXME: throw SAXException from method?
			throw new DocumentException("Sax error ", e);
		}

		// Presumably, project is now up-to-date
		project.setModified(false);
	}