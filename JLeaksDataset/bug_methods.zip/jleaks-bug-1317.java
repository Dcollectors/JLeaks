private void editPermissionsRecursively(
            @Nonnull Path basePath,
            @Nonnull String chmodOp,
            @Nonnull Predicate<? super Set<PosixFilePermission>> editFn
    ) throws IOException {
        List<String> filesNotMarked = new ArrayList<>();
        Files.walk(basePath).forEach(path -> {
            try {
                editPermissions(path, editFn);
            } catch (Exception e) {
                filesNotMarked.add(basePath.relativize(path).toString());
            }

        });
        if (!filesNotMarked.isEmpty()) {
            logger.info("Couldn't 'chmod " + chmodOp + "' these files: " + filesNotMarked);
        }
    }