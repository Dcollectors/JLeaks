    static Collection<Path> listAllocationDirectoriesIn(File localStateRootDirectory)
            throws IOException {
        return Files.list(localStateRootDirectory.toPath())
                .filter(path -> path.getFileName().toString().startsWith(ALLOCATION_DIR_PREFIX))
                .collect(Collectors.toList());
    }