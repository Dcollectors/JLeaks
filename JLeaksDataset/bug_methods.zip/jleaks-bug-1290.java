  private ManifestLoadResult loadManifest(RuleKey key) {
    Preconditions.checkState(useManifestCaching());

    Path path = getManifestPath(rule);

    // Deserialize the manifest.
    Manifest manifest;
    try (InputStream input =
        new GZIPInputStream(rule.getProjectFilesystem().newFileInputStream(path))) {
      manifest = new Manifest(input);
    } catch (Exception e) {
      LOG.warn(
          e,
          "Failed to deserialize fetched-from-cache manifest for rule %s with key %s",
          rule,
          key);
      return ManifestLoadResult.error("corrupted manifest path");
    }
    }