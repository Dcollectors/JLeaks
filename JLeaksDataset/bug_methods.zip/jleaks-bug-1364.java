    private String getContactFromCursor(Cursor cursor) {
        String lookupKey = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.LOOKUP_KEY));
        Uri uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI, lookupKey);

        String vCard = "";
        try {
            InputStream inputStream = getContext().getContentResolver().openInputStream(uri);
            InputStreamReader inputStreamReader;
            char[] buffer = new char[1024];
            StringBuilder stringBuilder = new StringBuilder();

            if (inputStream != null) {
                inputStreamReader = new InputStreamReader(inputStream);

                while (true) {
                    int byteCount = inputStreamReader.read(buffer, 0, buffer.length);

                    if (byteCount > 0) {
                        stringBuilder.append(buffer, 0, byteCount);
                    } else {
                        break;
                    }
                }
            }

            vCard = stringBuilder.toString();

            return vCard;

        } catch (IOException e) {
            Log_OC.d(TAG, e.getMessage());
        }
        return vCard;
    }