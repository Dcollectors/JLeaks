        private Object loadObjectConfig(String configName, Class clazz) {
            Object config = null;

            String ymlFilename = configName + CONFIG_EXT_YML;
            try (InputStream inStream = getConfigStream(ymlFilename)) {
                if (inStream != null) {
                    if (isEnableInjection) {
                        config = yaml.loadAs(EnvConfig.resolveYaml(inStream), clazz);
                    } else {
                        config = yaml.loadAs(inStream, clazz);
                    }
                }
            } catch (IOException ioe) {
                logger.error("IOException", ioe);
            }
            if (config != null) return config;

            String yamlFilename = configName + CONFIG_EXT_YAML;
            try (InputStream inStream = getConfigStream(yamlFilename)) {
                if (inStream != null) {
                    if (isEnableInjection) {
                        config = yaml.loadAs(EnvConfig.resolveYaml(inStream), clazz);
                    } else {
                        config = yaml.loadAs(inStream, clazz);
                    }
                }
            } catch (IOException ioe) {
                logger.error("IOException", ioe);
            }
            if (config != null) return config;

            String jsonFilename = configName + CONFIG_EXT_JSON;
            try (InputStream inStream = getConfigStream(jsonFilename)) {
                if (inStream != null) {
                    if (isEnableInjection) {
                        config = mapper.readValue(EnvConfig.resolveJson(inStream), clazz);
                    } else {
                        config = mapper.readValue(inStream, clazz);
                    }
                }
            } catch (IOException ioe) {
                logger.error("IOException", ioe);
            }
            return config;
        }

        private Map<String, Object> loadMapConfig(String configName) {
            Map<String, Object> config = null;

            String ymlFilename = configName + CONFIG_EXT_YML;
            try (InputStream inStream = getConfigStream(ymlFilename)) {
                if (inStream != null) {
                    if (isEnableInjection) {
                        config = (Map<String, Object>) yaml.load(EnvConfig.resolveYaml(inStream));
                    } else {
                        config = (Map<String, Object>) yaml.load(inStream);
                    }
                }
            } catch (IOException ioe) {
                logger.error("IOException", ioe);
            }
            if (config != null) return config;

            String yamlFilename = configName + CONFIG_EXT_YAML;
            try (InputStream inStream = getConfigStream(yamlFilename)) {
                if (inStream != null) {
                    if (isEnableInjection) {
                        config = (Map<String, Object>) yaml.load(EnvConfig.resolveYaml(inStream));
                    } else {
                        config = (Map<String, Object>) yaml.load(inStream);
                    }
                }
            } catch (IOException ioe) {
                logger.error("IOException", ioe);
            }
            if (config != null) return config;

            String configFilename = configName + CONFIG_EXT_JSON;
            try (InputStream inStream = getConfigStream(configFilename)) {
                if (inStream != null) {
                    if (isEnableInjection) {
                        config = mapper.readValue(EnvConfig.resolveJson(inStream), new TypeReference<HashMap<String, Object>>() {
                        });
                    } else {
                        config = mapper.readValue(inStream, new TypeReference<HashMap<String, Object>>() {
                        });
                    }
                }
            } catch (IOException ioe) {
                logger.error("IOException", ioe);
            }
            return config;
        }