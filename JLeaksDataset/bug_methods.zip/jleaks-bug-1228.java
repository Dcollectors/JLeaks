  public Keyset read() throws IOException {
    return Keyset.parseFrom(inputStream, ExtensionRegistryLite.getEmptyRegistry());
  }