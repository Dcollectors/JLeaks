    private String createBody(String privateKeyPath, long currentTimeMs)
            throws Exception {
        JsonObject privateKeyJson = Json.parse(
                new InputStreamReader(new FileInputStream(privateKeyPath), StandardCharsets.UTF_8)).asObject();
        String privateKey = privateKeyJson.get("private_key").asString();
        String clientEmail = privateKeyJson.get("client_email").asString();

        String headerBase64 = base64encodeUrlSafe(header());
        String claimSetBase64 = base64encodeUrlSafe(claimSet(clientEmail, currentTimeMs));
        String signatureBase64 = sign(headerBase64, claimSetBase64, privateKey);

        return body(headerBase64, claimSetBase64, signatureBase64);
    }