   public HikariConfig(String propertyFileName)
   {
      this();

      File propFile = new File(propertyFileName);
      if (!propFile.isFile()) {
         throw new IllegalArgumentException("Property file " + propertyFileName + " was not found.");
      }

      try {
         FileInputStream fis = new FileInputStream(propFile);
         Properties props = new Properties();
         props.load(fis);
         PropertyBeanSetter.setTargetFromProperties(this, props);
         fis.close();
      }
      catch (IOException io) {
         throw new RuntimeException("Error loading properties file", io);
      }
   }