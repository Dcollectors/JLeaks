    public static void serialize(final String name, final Object ast) {
        if (name == null || name.length() == 0) return;

        XStream xstream = new XStream(new StaxDriver());
        try {
            File astFile = astFile(name);
            if (astFile == null) {
                System.out.println("File-name for writing " + name + " AST could not be determined!");
                return;
            }

            xstream.toXML(ast, new FileWriter(astFile, false));
            System.out.println("Written AST to " + name + ".xml");

        } catch (Exception e) {
            System.out.println("Couldn't write to " + name + ".xml");
            e.printStackTrace();
        }
    }