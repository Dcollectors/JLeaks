        public TcpSocketManager createManager(final String name, final FactoryData data) {

            InetAddress inetAddress;
            OutputStream os;
            try {
                inetAddress = InetAddress.getByName(data.host);
            } catch (final UnknownHostException ex) {
                LOGGER.error("Could not find address of " + data.host, ex, ex);
                return null;
            }
            try {
                // LOG4J2-1042
                final Socket socket = createSocket(data);
                os = socket.getOutputStream();
                return new TcpSocketManager(name, os, socket, inetAddress, data.host, data.port,
                        data.connectTimeoutMillis, data.reconnectDelayMillis, data.immediateFail, data.layout,
                        data.bufferSize, data.socketOptions);
            } catch (final IOException ex) {
                LOGGER.error("TcpSocketManager (" + name + ") " + ex, ex);
                os = NullOutputStream.getInstance();
            }
            if (data.reconnectDelayMillis == 0) {
                return null;
            }
            return new TcpSocketManager(name, os, null, inetAddress, data.host, data.port, data.connectTimeoutMillis,
                    data.reconnectDelayMillis, data.immediateFail, data.layout, data.bufferSize, data.socketOptions);
        }