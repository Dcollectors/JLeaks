    public JSONConfiguration(InputSource source, File configFile) {
        this.configFile = configFile;
        byte[] buffer;

        try {
            buffer = toByteArray(source.getByteStream());
            InputStream is = new ByteArrayInputStream(buffer);
            source = new InputSource(is);
            ObjectMapper mapper = new ObjectMapper().configure(JsonParser.Feature.ALLOW_COMMENTS, true);
            root = mapper.readTree(is);
            if (root.size() == 1) {
                Iterator<JsonNode> i = root.getElements();
                root = i.next();
            }
            processAttributes(rootNode, root);
            Level status = Level.OFF;
            boolean verbose = false;
            PrintStream stream = System.out;
            for (Map.Entry<String, String> entry : rootNode.getAttributes().entrySet()) {
                if ("status".equalsIgnoreCase(entry.getKey())) {
                    status = Level.toLevel(getSubst().replace(entry.getValue()).toUpperCase(), null);
                    if (status == null) {
                        status = Level.ERROR;
                        messages.add("Invalid status specified: " + entry.getValue() + ". Defaulting to ERROR");
                    }
                } else if ("dest".equalsIgnoreCase(entry.getKey())) {
                    String dest = entry.getValue();
                    if (dest != null) {
                        if (dest.equalsIgnoreCase("err")) {
                            stream = System.err;
                        } else {
                            try {
                                File destFile = FileUtils.fileFromURI(new URI(dest));
                                stream = new PrintStream(new FileOutputStream(destFile));
                            } catch (URISyntaxException use) {
                                System.err.println("Unable to write to " + dest + ". Writing to stdout");
                            }
                        }
                    }
                } else if ("verbose".equalsIgnoreCase(entry.getKey())) {
                    verbose = Boolean.parseBoolean(getSubst().replace(entry.getValue()));
                } else if ("packages".equalsIgnoreCase(entry.getKey())) {
                    String[] packages = getSubst().replace(entry.getValue()).split(",");
                    for (String p : packages) {
                        PluginManager.addPackage(p);
                    }
                } else if ("name".equalsIgnoreCase(entry.getKey())) {
                    setName(getSubst().replace(entry.getValue()));
                } else if ("monitorInterval".equalsIgnoreCase(entry.getKey())) {
                    int interval = Integer.parseInt(getSubst().replace(entry.getValue()));
                    if (interval > 0 && configFile != null) {
                        monitor = new FileConfigurationMonitor(this, configFile, listeners, interval);
                    }
                }
            }

            Iterator<StatusListener> statusIter = ((StatusLogger) LOGGER).getListeners();
            boolean found = false;
            while (statusIter.hasNext()) {
                StatusListener listener = statusIter.next();
                if (listener instanceof StatusConsoleListener) {
                    found = true;
                    ((StatusConsoleListener) listener).setLevel(status);
                    if (!verbose) {
                        ((StatusConsoleListener) listener).setFilters(VERBOSE_CLASSES);
                    }
                }
            }
            if (!found && status != Level.OFF) {
                StatusConsoleListener listener = new StatusConsoleListener(status, stream);
                if (!verbose) {
                    listener.setFilters(VERBOSE_CLASSES);
                }
                ((StatusLogger) LOGGER).registerListener(listener);
                for (String msg : messages) {
                    LOGGER.error(msg);
                }
            }
            if (getName() == null) {
                setName(source.getSystemId());
            }
        } catch (Exception ex) {
            LOGGER.error("Error parsing " + source.getSystemId(), ex);
            ex.printStackTrace();
        }
    }