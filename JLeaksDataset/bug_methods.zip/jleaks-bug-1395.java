        public String value() {
            Map<String, Object> value = sourceInput.value();
            if (value == null) {
                return null;
            }
            assert value instanceof LinkedHashMap<String, Object> : "the raw source order should be preserved";
            Map<String, Object> filteredMap = XContentMapValues.filter(value, includes, excludes);
            try {
                BytesReference bytes = BytesReference.bytes(new XContentBuilder(XContentType.JSON.xContent(),
                    new BytesStreamOutput(lastSourceSize)).map(filteredMap));
                lastSourceSize = bytes.length();
                return bytes.utf8ToString();
            } catch (IOException ex) {
                LOGGER.error("could not parse xContent", ex);
            }
            return null;
        }