    protected boolean isSourceNewer(URL source, Class cls) throws IOException {
        long lastMod;

        // Special handling for file:// protocol, as getLastModified() often reports
        // incorrect results (-1)
        if (source.getProtocol().equals("file")) {
            // Coerce the file URL to a File
            String path = source.getPath().replace('/', File.separatorChar).replace('|', ':');
            File file = new File(path);
            lastMod = file.lastModified();
        }
        else {
            lastMod = source.openConnection().getLastModified();
        }
        long classTime = getTimeStamp(cls);
        return classTime+config.getMinimumRecompilationInterval() < lastMod;
    }