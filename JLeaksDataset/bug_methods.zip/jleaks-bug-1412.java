    public Checksum compute(final InputStream in, final TransferStatus status) throws ChecksumException {
        return Checksum.NONE;
    }