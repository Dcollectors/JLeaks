    private long getFileChecksum(String filepath) {

        InputStream inputStream;
        try {
            inputStream = new BufferedInputStream(new FileInputStream(filepath));
            CRC32 crc = new CRC32();
            int cnt;
            while ((cnt = inputStream.read()) != -1) {
                crc.update(cnt);
            }

            return crc.getValue();

        } catch (FileNotFoundException e) {
            return -1;
        } catch (IOException e) {
            return -1;
        }
    }