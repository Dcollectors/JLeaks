        private static Optional<byte[]> read(URI uri) {
            try {
                return Optional.of(ByteStreams.toByteArray(uri.toURL().openStream()));
            } catch (Exception e) {
                return Optional.absent();
            }
        }