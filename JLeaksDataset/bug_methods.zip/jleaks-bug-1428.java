    private static Document parseDocument(@WillClose InputStream in) throws DocumentException {
        SAXReader reader = new SAXReader();

        Reader r = UTF8.bufferedReader(in);
        Document d = reader.read(r);
        Util.closeSilently(r);
        return d;

    }