    public void run() {
      String url = CHART_SERVER_URL + mPixelResolution + "x" + mPixelResolution + "&chl=" +
          mContents;
      try {
        URI uri = new URI("http", url, null);
        HttpGet get = new HttpGet(uri);
        AndroidHttpClient client = AndroidHttpClient.newInstance(mUserAgent);
        HttpResponse response = client.execute(get);
        HttpEntity entity = response.getEntity();
        Bitmap image = BitmapFactory.decodeStream(entity.getContent());
        if (image != null) {
          Message message = Message.obtain(mHandler, R.id.encode_succeeded);
          message.obj = image;
          message.sendToTarget();
        } else {
          Log.e(TAG, "Could not decode png from the network");
          Message message = Message.obtain(mHandler, R.id.encode_failed);
          message.sendToTarget();
        }
      } catch (Exception e) {
        Log.e(TAG, e.toString());
        Message message = Message.obtain(mHandler, R.id.encode_failed);
        message.sendToTarget();
      }
    }