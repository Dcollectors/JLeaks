	public FileImageSource(String sourceFilePath)
	{
		super();
		
		if (sourceFilePath == null)
		{
			throw new NullPointerException("File cannot be null.");
		}
		
		this.sourceFile = new File(sourceFilePath);
	}

	public BufferedImage read() throws IOException
	{
		try
		{
			imageSource = new InputStreamImageSource(new FileInputStream(sourceFile));
			imageSource.setThumbnailParameter(param);
		}
		catch (FileNotFoundException e)
		{
			throw new FileNotFoundException(
					"Could not find file: " + sourceFile.getAbsolutePath()
			);
		}
		
		try
		{
			return imageSource.read();
		}
		catch (UnsupportedFormatException e)
		{
			String sourcePath = sourceFile.getAbsolutePath();
			throw new UnsupportedFormatException(
					UnsupportedFormatException.UNKNOWN,
					"No suitable ImageReader found for " + sourcePath + "."
			);
		}
	}