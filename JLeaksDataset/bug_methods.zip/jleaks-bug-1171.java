    private void convertCharset(final File inputFile){
        if(inputFile.isDirectory()){
            final File[] files = inputFile.listFiles();
            for (int i = 0; i < files.length; i++) {
                convertCharset(files[i]);
            }
        }else if(FileUtils.isHTMLFile(inputFile.getName())||
                FileUtils.isHHCFile(inputFile.getName())||
                FileUtils.isHHKFile(inputFile.getName())){

            final String fileName = inputFile.getAbsolutePath();
            log("Processing " + fileName, Project.MSG_INFO);
            BufferedReader reader = null;
            Writer writer = null;
            try {
                //prepare for the input and output
                final FileInputStream inputStream = new FileInputStream(inputFile);
                final InputStreamReader streamReader = new InputStreamReader(inputStream, UTF8);
                reader = new BufferedReader(streamReader);

                final File outputFile = new File(fileName + FILE_EXTENSION_TEMP);
                final FileOutputStream outputStream = new FileOutputStream(outputFile);
                final OutputStreamWriter streamWriter = new OutputStreamWriter(outputStream, UTF8);
                writer = new BufferedWriter(streamWriter);

                String value = reader.readLine();
                while(value != null){
                    //meta tag contains charset found
                    if(value.contains("<meta http-equiv") && value.contains("charset")){
                        final int insertPoint = value.indexOf("charset=") + "charset=".length();
                        final String subString = value.substring(0, insertPoint);
                        final int remainIndex = value.indexOf(UTF8) + UTF8.length();
                        final String remainString = value.substring(remainIndex);
                        //change the charset
                        final String newValue = subString + charsetMap.get(ATTRIBUTE_FORMAT_VALUE_HTML) + remainString;
                        //write into the output file
                        writer.write(newValue);
                        //add line break
                        writer.write(LINE_SEPARATOR);
                    }else{
                        // Added on 2010-11-05 for bug Unnecessary XML declaration in HHP and HHC - ID: 3101964 start
                        if(value.contains(tag1)){
                            value = replaceXmlTag(value,tag1);
                        }else if(value.contains(tag2)){
                            value = replaceXmlTag(value,tag2);
                        }else if(value.contains(tag3)){
                            value = replaceXmlTag(value,tag3);
                        }
                        // Added on 2010-11-05 for bug Unnecessary XML declaration in HHP and HHC - ID: 3101964 end

                        //other values
                        writer.write(value);
                        writer.write(LINE_SEPARATOR);
                    }
                    value = reader.readLine();
                }

                writer.close();
                reader.close();

                //delete old file
                if (!inputFile.delete()) {
                    final Properties prop = new Properties();
                    prop.put("%1", inputFile.getPath());
                    prop.put("%2", outputFile.getPath());
                    logger.logError(MessageUtils.getMessage("DOTJ009E", prop)
                            .toString());
                }
                //rename newly created file to the old file
                if (!outputFile.renameTo(inputFile)) {
                    final Properties prop = new Properties();
                    prop.put("%1", inputFile.getPath());
                    prop.put("%2", outputFile.getPath());
                    logger.logError(MessageUtils.getMessage("DOTJ009E", prop)
                            .toString());
                }


            } catch (final FileNotFoundException e) {
                logger.logException(e);
            } catch (final UnsupportedEncodingException e) {
                logger.logException(e);
            } catch (final IOException e) {
                logger.logException(e);
            }
        }
    }