    private List<Path> listJars(Path dir) throws IOException {
        return Files.list(dir)
            .filter(it -> !Files.isDirectory(it))
            .filter(it -> it.getFileName().endsWith("jar"))
            .collect(Collectors.toList());
    }