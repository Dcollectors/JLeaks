  private void writeSessionExtensionJs(File coreDir) throws IOException {
    FrameGroupCommandQueueSet queueSet =
        FrameGroupCommandQueueSet.getQueueSet(sessionId);

    if (queueSet.getExtensionJs().length() > 0) {
      String path = "scripts/user-extensions.js[" + sessionId + "]";
      FileWriter fileWriter = new FileWriter(new File(coreDir, path));
      BufferedWriter writer = new BufferedWriter(fileWriter);

      writer.write(queueSet.getExtensionJs());
      writer.close();

      fileWriter.close();
    }
  }