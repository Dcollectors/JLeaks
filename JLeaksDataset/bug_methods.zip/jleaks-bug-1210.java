    private void addConnection(final long loginTimeout)
    {
        try
        {
            // Speculative increment of totalConnections with expectation of success (first time through)
            if (totalConnections.incrementAndGet() > configuration.getMaximumPoolSize())
            {
                totalConnections.decrementAndGet();
                return;
            }

            dataSource.setLoginTimeout((int) loginTimeout);
            Connection connection = dataSource.getConnection();

            transactionIsolation =  (transactionIsolation < 0 ? connection.getTransactionIsolation() : transactionIsolation); 
            
            if (connectionCustomizer != null)
            {
                connectionCustomizer.customize(connection);
            }

            executeInitSql(connection);

            IHikariConnectionProxy proxyConnection = ProxyFactory.getProxyConnection(this, connection, transactionIsolation, isAutoCommit, isReadOnly, catalog);
        	proxyConnection.resetConnectionState();
            idleConnectionBag.add(proxyConnection);
            return;
        }
        catch (Exception e)
        {
            // We failed, so undo speculative increment of totalConnections
            totalConnections.decrementAndGet();

            long now = System.currentTimeMillis();
            if (now - lastConnectionFailureTime > 1000 || debug)
            {
                LOGGER.warn("Connection attempt to database failed (not every attempt is logged): {}", e.getMessage(), (debug ? e : null));
            }
            lastConnectionFailureTime = now;
        }
    }