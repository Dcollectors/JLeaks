    private String getFileText(File sourceFile) {
        StringBuilder sb = new StringBuilder();
        BufferedReader br = null;
        try {
            if (sourceFile.isFile() && sourceFile.exists()) {
                InputStreamReader isr = new InputStreamReader(new FileInputStream(sourceFile));
                br = new BufferedReader(isr);
                String lineText = null;
                while ((lineText = br.readLine()) != null) {
                    sb.append(lineText).append("\n");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return sb.toString();
    }