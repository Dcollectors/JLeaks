    private String getUrlFromFile(String storagePath, Pattern pattern) {
        String url = null;

        try {
            FileReader fr = new FileReader(storagePath);
            BufferedReader br = new BufferedReader(fr);

            String line;
            while ((line = br.readLine()) != null) {
                Matcher m = pattern.matcher(line);
                if (m.find()) {
                    url = m.group(1);
                    break;
                }
            }
            br.close();
            fr.close();
        } catch (IOException e) {
			Log_OC.d(TAG, e.getMessage());
            return null;
        }
        return url;
	}