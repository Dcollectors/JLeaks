  public Annotation readUndelimited(InputStream is) throws IOException {
    return fromProto(CoreNLPProtos.Document.parseDelimitedFrom(is));
  }