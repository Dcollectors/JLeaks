    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if (evt instanceof StartEvent) {
            isHandlingRequest = true;
            startedSendingResponseToClient = false;
            closeConnection = false;
            zuulResponse = null;
        }
        else if (evt instanceof CompleteEvent) {
            if (zuulResponse != null) {
                zuulResponse.disposeBufferedBody();
            }

            // Do all the post-completion metrics and logging.
            handleComplete(ctx.channel());

            // Choose to either close the connection, or prepare it for next use.
            final CompleteEvent completeEvent = (CompleteEvent)evt;
            final CompleteReason reason = completeEvent.getReason();
            if (reason == SESSION_COMPLETE || reason == INACTIVE) {
                if (! closeConnection) {
                    //Start reading next request over HTTP 1.1 persistent connection
                    ctx.channel().read();
                }
            }
            else {
                if (isHandlingRequest) {
                    LOG.warn("Received complete event while still handling the request. With reason: " + reason.name() + ChannelUtils.channelInfoForLogging(ctx.channel()));
                }
                ctx.close();
            }

            isHandlingRequest = false;
        }
        else if (evt instanceof IdleStateEvent) {
            LOG.debug("Received IdleStateEvent.");
        }
        else {
            LOG.info("ClientResponseWriter Received event {}", evt);
        }
    }