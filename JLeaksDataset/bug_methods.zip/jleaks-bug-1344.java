    public void updateInfo(@NonNull BreakpointInfo info) throws IOException {
        final SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            final Cursor cursor = getWritableDatabase().rawQuery(
                    "SELECT " + ID + " FROM " + BREAKPOINT_TABLE_NAME + " WHERE " + ID + " ="
                            + info.id + " LIMIT 1",
                    null);
            if (!cursor.moveToNext()) return; // not exist

            // update
            removeInfo(info.id);
            insert(info);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }