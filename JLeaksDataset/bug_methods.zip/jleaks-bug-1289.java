  public UploadResponse uploadRequest(
      RequestBody requestBody, ImmutableMap<String, String> queryParams) throws IOException {
    HttpUrl url = HttpUrl.get(endpointUrl);
    if (url == null) {
      throw new IllegalStateException("endpoint url should be a valid url");
    }

    HttpUrl.Builder urlBuilder = url.newBuilder().addQueryParameter("uuid", buildId);
    queryParams.forEach(urlBuilder::addQueryParameter);

    Request request = new Request.Builder().url(urlBuilder.build()).post(requestBody).build();

    Response httpResponse = httpClient.newCall(request).execute();
    return handleResponse(httpResponse);
  }