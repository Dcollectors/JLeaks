  public static LinuxEphemeralPortRangeDetector getInstance() {
    File file = new File("/proc/sys/net/ipv4/ip_local_port_range");
    if (file.exists() && file.canRead()) {
      Reader inputFil = null;
      try {
        inputFil = new FileReader(file);
      } catch (FileNotFoundException e) {
        throw new RuntimeException(e);
      }
      return new LinuxEphemeralPortRangeDetector(inputFil);
    }
    return new LinuxEphemeralPortRangeDetector(new StringReader("49152 65535"));
  }