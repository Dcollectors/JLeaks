    public static boolean delete(@Nullable File file) {
        if (file == null) {
            LOGGER.warn("cannot delete null File");
            return false;
        }

        try {
            Files.walk(file.toPath())
            .sorted(Comparator.reverseOrder())
            .map(Path::toFile)
            .forEach(File::delete);
        } catch (IOException ex) {
            LOGGER.trace(ex.getMessage(), ex);
            LOGGER.debug("Failed to delete file: {} (error message: {}); attempting to delete on exit.", file.getPath(), ex.getMessage());
            file.deleteOnExit();
            return false;
        }

        return true;
    }