    PackageDescr xmlToPackageDescr(Resource resource) throws DroolsParserException, IOException {
        final XmlPackageReader xmlReader = new XmlPackageReader( this.configuration.getSemanticModules() );
        xmlReader.getParser().setClassLoader( this.rootClassLoader );

        try {
            xmlReader.read( resource.getReader() );
        } catch (final SAXException e) {
            throw new DroolsParserException( e.toString(),
                    e.getCause() );
        }
        return xmlReader.getPackageDescr();
    }