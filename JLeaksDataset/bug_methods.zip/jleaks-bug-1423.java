    public byte[] readToByteArray(final Path file) throws BackgroundException {
        final Read read = session.getFeature(Read.class);
        final InputStream stream = read.read(file, new TransferStatus());
        try {
            return IOUtils.toByteArray(stream);
        }
        catch(IOException e) {
            throw new DefaultIOExceptionMappingService().map(e);
        }
        finally {
            IOUtils.closeQuietly(stream);
        }
    }