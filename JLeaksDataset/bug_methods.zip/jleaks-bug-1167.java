    public void collectionProcessComplete()
            throws AnalysisEngineProcessException
    {
        try {
            OutputStream os = CompressionUtils.getOutputStream(new File(getTargetLocation()));

            Stream<String> stream = counter.uniqueSet().stream()
                    .filter(token -> counter.getCount(token) >= minCount);
            if (outputComparator.isPresent()) {
                stream = stream.sorted(outputComparator.get());
            }
            stream.forEach(token -> {
                try {
                    os.write(
                            (token + COLUMN_SEPARATOR + counter.getCount(token) + "\n").getBytes());
                }
                catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        }
        catch (IOException e) {
            throw new AnalysisEngineProcessException(e);
        }
    }