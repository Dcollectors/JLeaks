    public InputStream open(String path) throws IOException {
        final String config = new String(ByteStreams.toByteArray(delegate.open(path)), StandardCharsets.UTF_8);
        final String substituted = substitutor.replace(config);

        return new ByteArrayInputStream(substituted.getBytes(StandardCharsets.UTF_8));
    }