    public void initSchema(AppEngineConfiguration appEngineConfiguration, String databaseSchemaUpdate) {
        try {
            if (AppEngineConfiguration.DB_SCHEMA_UPDATE_CREATE_DROP.equals(databaseSchemaUpdate)) {
                dbSchemaCreate();
                
            } else if (AppEngineConfiguration.DB_SCHEMA_UPDATE_DROP_CREATE.equals(databaseSchemaUpdate)) {
                dbSchemaDrop();
                dbSchemaCreate();
                
            } else if (AppEngineConfiguration.DB_SCHEMA_UPDATE_TRUE.equals(databaseSchemaUpdate)) {
                dbSchemaUpdate();
                
            } else if (AppEngineConfiguration.DB_SCHEMA_UPDATE_FALSE.equals(databaseSchemaUpdate)) {
                Liquibase liquibase = createLiquibaseInstance(appEngineConfiguration);
                liquibase.validate();
                
            }
        } catch (Exception e) {
            throw new FlowableException("Error initialising app data model", e);
        }
    }