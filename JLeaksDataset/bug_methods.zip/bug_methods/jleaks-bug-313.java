    private CsvConfiguration suggestCsvConfiguration(byte[] sample, String encoding) throws IllegalStateException {

        char[] sampleChars = readSampleBuffer(sample, encoding);

        if (StringUtils.indexOf('\n', sampleChars) == -1 && StringUtils.indexOf('\r', sampleChars) == -1) {
            throw new IllegalStateException("No newline in first " + sampleChars.length + " chars");
        }

        int newlines = 0;
        int tabs = 0;
        int commas = 0;
        int semicolons = 0;
        int pipes = 0;
        int singleQuotes = 0;
        int doubleQuotes = 0;
        int backslashes = 0;

        for (int i = 0; i < sampleChars.length; i++) {
            char c = sampleChars[i];
            if (c == '\n') {
                newlines++;
            } else if (c == '\t') {
                tabs++;
            } else if (c == ',') {
                commas++;
            } else if (c == ';') {
                semicolons++;
            } else if (c == '\'') {
                singleQuotes++;
            } else if (c == '|') {
                pipes++;
            } else if (c == '"') {
                doubleQuotes++;
            } else if (c == '\\') {
                backslashes++;
            }
        }

        char separatorChar;
        char quoteChar;
        char escapeChar;

        int detectedSeparator = Math.max(tabs, Math.max(commas, Math.max(semicolons, pipes)));
        if (detectedSeparator == 0 || detectedSeparator < newlines) {
            separatorChar = ',';
        } else {
            // set the separator
            if (detectedSeparator == commas) {
                separatorChar = ',';
            } else if (detectedSeparator == semicolons) {
                separatorChar = ';';
            } else if (detectedSeparator == tabs) {
                separatorChar = '\t';
            } else if (detectedSeparator == pipes) {
                separatorChar = '|';
            } else {
                separatorChar = ',';
            }
        }

        if (backslashes > 0) {
            escapeChar = '\\';
        } else {
            escapeChar = CsvConfiguration.NOT_A_CHAR;
        }

        int detectedQuote = Math.max(singleQuotes, doubleQuotes);
        if (detectedQuote == 0 || detectedQuote < newlines) {
            quoteChar = '"';
        } else {
            // set the quote
            if (detectedQuote == singleQuotes) {
                quoteChar = '\'';
            } else if (detectedQuote == doubleQuotes) {
                quoteChar = '"';
            } else {
                quoteChar = '"';
            }
        }

        // detect if multi line values occur
        boolean multiline = false;
        final CsvConfiguration multiLineConfiguration = new CsvConfiguration(CsvConfiguration.DEFAULT_COLUMN_NAME_LINE,
                encoding, separatorChar, quoteChar, escapeChar, false, true);
        try {
            final CsvDataContext testDataContext = new CsvDataContext(new InMemoryResource("foo.txt", sample,
                    System.currentTimeMillis()), multiLineConfiguration);
            Table table = testDataContext.getDefaultSchema().getTable(0);
            DataSet dataSet = testDataContext.query().from(table).select(table.getColumns()).execute();
            try {
                while (dataSet.next()) {
                    final Row row = dataSet.getRow();
                    final Object[] values = row.getValues();
                    for (Object value : values) {
                        if (value != null && value instanceof String) {
                            if (((String) value).indexOf('\n') != -1) {
                                // found a multi line value
                                multiline = true;
                                break;
                            }
                        }
                    }
                }
            } finally {
                dataSet.close();
            }
        } catch (Exception e) {
            logger.warn("Failed to detect multiline property of CsvConfiguration, defaulting to 'true'", e);
            return multiLineConfiguration;
        }

        return new CsvConfiguration(CsvConfiguration.DEFAULT_COLUMN_NAME_LINE, encoding, separatorChar, quoteChar,
                escapeChar, false, multiline);
    }
