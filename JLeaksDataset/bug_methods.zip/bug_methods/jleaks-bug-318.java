private DatastoreCatalogType interceptDatastoreCatalog(final TenantContext context,
            final DataCleanerJobContext job, String datastoreName, final DatastoreCatalogType originalDatastoreCatalog) {
        final AnalyzerBeansConfiguration configuration = context.getConfiguration();
        final DatastoreCatalog datastoreCatalog = configuration.getDatastoreCatalog();
        // Create a map of all used datastores and the columns which are
        // being accessed within them.
        final Map<String, MutableSchema> datastoreUsage = new LinkedHashMap<String, MutableSchema>();
        if (job != null && StringUtils.isNullOrEmpty(datastoreName)) {
            datastoreName = job.getSourceDatastoreName();
        }
        if (StringUtils.isNullOrEmpty(datastoreName)) {
            // represent all datastores (no job-specific information is
            // known)
            for (final String name : datastoreCatalog.getDatastoreNames()) {
                datastoreUsage.put(name, new MutableSchema());
            }
        } else {
            // represent the single datastore fully
            final Datastore datastore = datastoreCatalog.getDatastore(datastoreName);
            if (datastore == null) {
                throw new IllegalArgumentException("Datastore '" + datastoreName + "' does not exist");
            }
            DatastoreConnection con = datastore.openConnection();
            try {
                final MutableSchema usageSchema = new MutableSchema();
                final Schema schema;
                if (job == null) {
                    schema = con.getDataContext().getDefaultSchema();
                } else {
                    String columnPath = job.getSourceColumnPaths().get(0);
                    Column column = con.getDataContext().getColumnByQualifiedLabel(columnPath);
                    schema = column.getTable().getSchema();
                }
                usageSchema.setName(schema.getName());
                String[] tableNames = schema.getTableNames();
                for (String tableName : tableNames) {
                    usageSchema.addTable(new MutableTable(tableName).setSchema(usageSchema).setRemarks(
                            REMARK_INCLUDE_IN_QUERY));
                }
                datastoreUsage.put(datastoreName, usageSchema);
            } finally {
                con.close();
            }

            // add schema information about the remaining datastores
            for (final String name : datastoreCatalog.getDatastoreNames()) {
                if (!datastoreName.equals(name)) {
                    datastoreUsage.put(name, new MutableSchema());
                }
            }
        }
        return interceptDatastoreCatalog(datastoreCatalog, datastoreUsage);
    }