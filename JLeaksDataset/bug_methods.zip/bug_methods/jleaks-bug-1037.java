    private void writeResponse(HttpServletResponse response, String contentType,
            String output) throws IOException {
        response.setContentType(contentType);
        final OutputStream out = response.getOutputStream();
        // Set the response type
        final PrintWriter outWriter = new PrintWriter(
                new BufferedWriter(new OutputStreamWriter(out, "UTF-8")));
        outWriter.print(output);
        outWriter.flush();
        outWriter.close();
    }
