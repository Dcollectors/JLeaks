  public <S extends Serializable> S deserializeObject(Path inputFile, Class<S> outputClass) {
    byte[] data = fromGzipFile(inputFile);
    return deserializeObject(data, outputClass);
  }
