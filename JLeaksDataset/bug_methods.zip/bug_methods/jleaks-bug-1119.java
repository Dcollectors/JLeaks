    public static void closeCluster() {
        CLUSTER.stop();
    }
