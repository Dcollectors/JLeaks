    public void sendResponse(TransportResponse response, TransportResponseOptions options) throws IOException {
        if (transport.compress) {
            options.withCompress(true);
        }

        byte status = 0;
        status = TransportStatus.setResponse(status);

        BytesStreamOutput bStream = new BytesStreamOutput();
        bStream.skip(NettyHeader.HEADER_SIZE);
        StreamOutput stream = bStream;
        if (options.compress()) {
            status = TransportStatus.setCompress(status);
            stream = CompressorFactory.defaultCompressor().streamOutput(stream);
        }
        stream = new HandlesStreamOutput(stream);
        stream.setVersion(version);
        response.writeTo(stream);
        stream.close();

        ChannelBuffer buffer = bStream.bytes().toChannelBuffer();
        NettyHeader.writeHeader(buffer, requestId, status, version);
        channel.write(buffer);
    }
