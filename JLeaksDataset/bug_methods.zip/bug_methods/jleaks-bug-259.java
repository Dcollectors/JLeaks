	public void destroy() {
		m_fileMetadata.file.delete();
	}
