  private static List<Object> getClusterSlots(JedisCluster jedis) {
    JedisException nodeException = null;
    for (Map.Entry<String, JedisPool> node : jedis.getClusterNodes().entrySet()) {
      JedisPool pool = node.getValue();
      Jedis resource = pool.getResource();
      try {
        return resource.clusterSlots();
      } catch (JedisException e) {
        nodeException = e;
        // log error with node
      } finally {
        resource.close();
      }
    }
    if (nodeException != null) {
      throw nodeException;
    }
    throw new JedisNoReachableClusterNodeException("No reachable node in cluster");
  }
