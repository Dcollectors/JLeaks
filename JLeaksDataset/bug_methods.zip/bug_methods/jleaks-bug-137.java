  public RecordWriter getRecordWriter(FileSystem ignored, JobConf job, String name,
      Progressable progress)
  throws IOException {
    // expecting exactly one path
    TableName tableName = TableName.valueOf(job.get(OUTPUT_TABLE));
    BufferedMutator mutator =  null;
    // Connection is not closed. Dies with JVM.  No possibility for cleanup.
    Connection connection = ConnectionFactory.createConnection(job);
    mutator = connection.getBufferedMutator(tableName);
    // Clear write buffer on fail is true by default so no need to reset it.
    return new TableRecordWriter(mutator);
  }
