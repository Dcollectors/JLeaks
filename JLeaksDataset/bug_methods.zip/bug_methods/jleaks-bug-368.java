    private static Map retrieveColumnInfo(String table) throws SQLException
    {
        Connection connection = null;

        try
        {
            String schema = ConfigurationManager.getProperty("db.schema");
            connection = getConnection();

            DatabaseMetaData metadata = connection.getMetaData();
            HashMap results = new HashMap();

            int max = metadata.getMaxTableNameLength();
            String tname = (table.length() >= max) ? table
                    .substring(0, max - 1) : table;

            ResultSet pkcolumns = metadata.getPrimaryKeys(null, schema, tname);
            Set pks = new HashSet();

            while (pkcolumns.next())
                pks.add(pkcolumns.getString(4));

            ResultSet columns = metadata.getColumns(null, schema, tname, null);

            while (columns.next())
            {
                String column = columns.getString(4);
                ColumnInfo cinfo = new ColumnInfo();
                cinfo.setName(column);
                cinfo.setType((int) columns.getShort(5));

                if (pks.contains(column))
                {
                    cinfo.setIsPrimaryKey(true);
                }

                results.put(column, cinfo);
            }

            return results;
        }
        finally
        {
            if (connection != null)
            {
                connection.close();
            }
        }
    }
