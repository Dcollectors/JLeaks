                public void hyperlinkUpdate(HyperlinkEvent e) {
                    if (HyperlinkEvent.EventType.ACTIVATED.equals(e.getEventType())) {
                        final String href = e.getDescription();
                        if ("http://datacleaner.org/register_datastore".equals(href)) {
                            _datastoreCatalog.addDatastore(errorDatastore);
                            JOptionPane.showMessageDialog(editorPane, "Saved datastore: " + errorDatastore.getName());
                        } else if ("http://datacleaner.org/preview_datastore".equals(href)) {
                            DatastoreConnection errorCon = errorDatastore.openConnection();
                            try {
                                Table table = errorCon.getDataContext().getDefaultSchema().getTables()[0];
                                PreviewSourceDataActionListener actionListener = new PreviewSourceDataActionListener(
                                        windowContext, errorDatastore, table);
                                actionListener.actionPerformed(null);
                            } finally {
                                errorCon.close();
                            }
                        } else {
                            logger.error("Unexpected href: " + href + ". Event was: " + e);
                        }
                    }
                }
