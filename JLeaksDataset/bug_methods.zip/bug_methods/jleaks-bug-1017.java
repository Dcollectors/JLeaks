    public void redirect(final InputStream inStream) {

      exception = null;

      this.thread =
          new Thread(
              () -> {
                final InputStreamReader in = new InputStreamReader(inStream);
                try {

                  int read = 0;
                  while (read > -1) {
                    read = in.read(buffer);
                    if (read > 0) {
                      out.write(buffer, 0, read);
                    }
                    out.flush();
                  }

                } catch (IOException exc) {
                  exception = exc;
                } finally {
                  quietlyClose(in);
                }
              });
      thread.start();
    }
