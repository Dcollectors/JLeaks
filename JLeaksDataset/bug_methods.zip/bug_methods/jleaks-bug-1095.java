    private URL[] createJarURLsFromDirectory(Path subDirectory) throws IOException {
        URL[] urls =
                Files.list(subDirectory)
                        .filter((Path p) -> Files.isRegularFile(p) && jarFileMatcher.matches(p))
                        .map(FunctionUtils.uncheckedFunction((Path p) -> p.toUri().toURL()))
                        .toArray(URL[]::new);

        if (urls.length < 1) {
            throw new IOException(
                    "Cannot find any jar files for plugin in directory ["
                            + subDirectory
                            + "]."
                            + " Please provide the jar files for the plugin or delete the directory.");
        }

        return urls;
    }
