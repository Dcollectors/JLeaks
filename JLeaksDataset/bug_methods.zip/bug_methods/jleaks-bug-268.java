  public void perform(Arguments arguments, PrintStream output) throws Exception {
    String adapterName = arguments.get(ArgumentName.ADAPTER.toString());
    File adapterConfigFile = filePathResolver.resolvePathToFile(
      arguments.get(ArgumentName.ADAPTER_SPEC.toString()));

    FileReader fileReader = new FileReader(adapterConfigFile);
    try {
      adapterClient.create(Id.Adapter.from(cliConfig.getCurrentNamespace(), adapterName),
                           GSON.fromJson(fileReader, AdapterConfig.class));
      output.printf("Successfully created adapter '%s'\n", adapterName);
    } finally {
      fileReader.close();
    }
  }
