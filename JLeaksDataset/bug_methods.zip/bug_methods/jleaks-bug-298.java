  private static void saveContentReference(VirtualFile file, int contentId) {
    //LOG.assertTrue(contentId > 0, contentId);
    if (ChangeListManagerImpl.DEBUG) {
      System.out.println("LastUnchangedContentTracker.saveCurrentContent");
      try {
        System.out.println("content = " + VfsUtil.loadText(file));
      }
      catch (IOException e) {
        e.printStackTrace();
      }
    }

    long stamp = file.getModificationStamp();
    try {
      final DataOutputStream contentStream = ACQUIRED_CONTENT_ATTR.writeAttribute(file);
      contentStream.writeInt(contentId);
      contentStream.close();

      final DataOutputStream tsStream = LAST_TS_ATTR.writeAttribute(file);
      tsStream.writeLong(stamp);
      tsStream.close();

      file.putUserData(LAST_TS_KEY, stamp);
    }
    catch (IOException e) {
      LOG.info(e);
    }
  }
