    public void abandonTransactions(Duration retention) throws InterruptedException {
        if (!Duration.ZERO.equals(retention)) {
            Optional<Scn> lastScnToAbandonTransactions = getLastScnToAbandon(jdbcConnection, retention);
            if (lastScnToAbandonTransactions.isPresent()) {
                Scn thresholdScn = lastScnToAbandonTransactions.get();
                Scn smallestScn = getTransactionCacheMinimumScn();
                if (!smallestScn.isNull() && thresholdScn.compareTo(smallestScn) >= 0) {
                    boolean first = true;
                    Iterator<Map.Entry<String, T>> iterator = getTransactionCache().entrySet().iterator();
                    try {
                        while (iterator.hasNext()) {
                            Map.Entry<String, T> entry = iterator.next();
                            if (entry.getValue().getStartScn().compareTo(thresholdScn) <= 0) {
                                if (first) {
                                    LOGGER.warn("All transactions with SCN <= {} will be abandoned.", thresholdScn);
                                    if(LOGGER.isDebugEnabled()) {
                                        LOGGER.debug("List of transactions in the cache before transactions being abandoned: [{}]",
                                                getTransactionCache().keySet().stream().collect(Collectors.joining(",")));
                                    }
                                    first = false;
                                }
                                LOGGER.warn("Transaction {} (start SCN {}, change time {}, redo thread {}, {} events) is being abandoned.",
                                        entry.getKey(), entry.getValue().getStartScn(), entry.getValue().getChangeTime(),
                                        entry.getValue().getRedoThreadId(), entry.getValue().getNumberOfEvents());

                                cleanupAfterTransactionRemovedFromCache(entry.getValue(), true);
                                iterator.remove();

                                metrics.addAbandonedTransactionId(entry.getKey());
                                metrics.setActiveTransactionCount(getTransactionCache().size());
                            }
                        }
                    }
                    finally {
                        if (iterator instanceof CloseableIterator) {
                            ((CloseableIterator<Map.Entry<String, T>>) iterator).close();
                        }
                    }
                    if(LOGGER.isDebugEnabled()) {
                        LOGGER.debug("List of transactions in the cache after transactions being abandoned: [{}]",
                                getTransactionCache().keySet().stream().collect(Collectors.joining(",")));
                    }

                    // Update the oldest scn metric are transaction abandonment
                    final Optional<T> oldestTransaction = getOldestTransactionInCache();
                    if (oldestTransaction.isPresent()) {
                        final T transaction = oldestTransaction.get();
                        metrics.setOldestScnDetails(transaction.getStartScn(), transaction.getChangeTime());
                    }
                    else {
                        metrics.setOldestScnDetails(Scn.NULL, null);
                    }

                    offsetContext.setScn(thresholdScn);
                }
                dispatcher.dispatchHeartbeatEvent(partition, offsetContext);
            }
        }
    }