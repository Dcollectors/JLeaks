    public Object load(AssetInfo info) throws IOException{
        assetManager = info.getManager();
        InputStream in = info.openStream();
        Savable obj = load(in);
        in.close();
        return obj;
    }