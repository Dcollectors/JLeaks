    protected RemoteOperationResult run(OwnCloudClient client) {
        /// perform the download
        synchronized(mCancellationRequested) {
            if (mCancellationRequested.get()) {
                return new RemoteOperationResult(new OperationCancelledException());
            }
        }

        RemoteOperationResult result;
        File newFile;
        boolean moved;

        /// download will be performed to a temporal file, then moved to the final location
        File tmpFile = new File(getTmpPath());

        String tmpFolder =  getTmpFolder();

        mDownloadOperation = new DownloadFileRemoteOperation(mFile.getRemotePath(), tmpFolder);
        Iterator<OnDatatransferProgressListener> listener = mDataTransferListeners.iterator();
        while (listener.hasNext()) {
            mDownloadOperation.addDatatransferProgressListener(listener.next());
        }
        result = mDownloadOperation.execute(client, client.isUseNextcloudUserAgent());

        if (result.isSuccess()) {
            mModificationTimestamp = mDownloadOperation.getModificationTimestamp();
            mEtag = mDownloadOperation.getEtag();
            newFile = new File(getSavePath());
            newFile.getParentFile().mkdirs();

            // decrypt file
            if (mFile.isEncrypted() && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                FileDataStorageManager fileDataStorageManager = new FileDataStorageManager(mAccount, mContext.getContentResolver());

                OCFile parent = fileDataStorageManager.getFileByPath(mFile.getParentRemotePath());

                DecryptedFolderMetadata metadata = EncryptionUtils.downloadFolderMetadata(parent, client, mContext, mAccount);

                if (metadata == null) {
                    return new RemoteOperationResult(RemoteOperationResult.ResultCode.METADATA_NOT_FOUND);
                }
                byte[] key = EncryptionUtils.decodeStringToBase64Bytes(metadata.getFiles()
                        .get(mFile.getEncryptedFileName()).getEncrypted().getKey());
                byte[] iv = EncryptionUtils.decodeStringToBase64Bytes(metadata.getFiles()
                        .get(mFile.getEncryptedFileName()).getInitializationVector());
                byte[] authenticationTag = EncryptionUtils.decodeStringToBase64Bytes(metadata.getFiles()
                        .get(mFile.getEncryptedFileName()).getAuthenticationTag());

                try {
                    byte[] decryptedBytes = EncryptionUtils.decryptFile(tmpFile, key, iv, authenticationTag);

                    FileOutputStream fileOutputStream = new FileOutputStream(tmpFile);
                    fileOutputStream.write(decryptedBytes);
                } catch (Exception e) {
                    return new RemoteOperationResult(e);
                }
            }
            moved = tmpFile.renameTo(newFile);
            newFile.setLastModified(mFile.getModificationTimestamp());
            if (!moved) {
                result = new RemoteOperationResult(RemoteOperationResult.ResultCode.LOCAL_STORAGE_NOT_MOVED);
            }
        }
        Log_OC.i(TAG, "Download of " + mFile.getRemotePath() + " to " + getSavePath() + ": " +
                result.getLogMessage());

        return result;
    }