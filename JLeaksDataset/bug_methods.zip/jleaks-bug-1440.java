    protected void encodeContent(final byte[] bytes, final String encoding, final ByteArrayOutputStream out)
        throws MessagingException, IOException {
        final OutputStream encoder = MimeUtility.encode(out, encoding);
        encoder.write(bytes);
        encoder.close();
    }