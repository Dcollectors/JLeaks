        private TrustStoreSettings(Settings settings) throws Exception {
            super(settings);

            keyStore.load(
                new FileInputStream(new File(keyStorePath)), keyStorePassword);

            TrustManagerFactory trustFactory =
                TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trustFactory.init(keyStore);

            this.trustManagers = trustFactory.getTrustManagers();
        }