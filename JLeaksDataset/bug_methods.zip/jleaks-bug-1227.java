	public static void copyFile(File source, File target) {
		try {
			FileInputStream inputStream = new FileInputStream(source);
			FileOutputStream outputStream = new FileOutputStream(target);
			FileChannel iChannel = inputStream.getChannel();
			FileChannel oChannel = outputStream.getChannel();

			ByteBuffer buffer = ByteBuffer.allocate(1024);
			while (true) {
				buffer.clear();
				int r = iChannel.read(buffer);
				if (r == -1)
					break;
				buffer.limit(buffer.position());
				buffer.position(0);
				oChannel.write(buffer);
			}
			inputStream.close();
			outputStream.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}