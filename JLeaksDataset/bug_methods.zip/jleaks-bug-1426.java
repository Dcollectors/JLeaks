	public static void loadFromIni() {
		if (DEFAULT_BASE_CONFIG_FILE.exists()) {
			String userDir = DEFAULT_BASE_DIR.getAbsolutePath();
			Map<String, String> config = new HashMap<>();
			try {
				Files.lines(DEFAULT_BASE_CONFIG_FILE.toPath()).forEach(l -> {
					if (l.charAt(0) == ';') {
						return;
					}
					String[] elements = l.split("=", 2);
					if (elements.length != 2) {
						Debug.errorf("invalid line in settings: \"%s\"", l);
						return;
					}
					config.put(elements[0], elements[1]);
				});
			} catch (IOException ex) {
				Debug.dumpException("failed to read settings", ex);
			}

			try {
				//set values
				baseCacheDir = new File(config.getOrDefault(
						"BaseCacheDir",
						DEFAULT_BASE_CACHE_DIR.getAbsolutePath()).replace("{user.dir}", userDir)
				);
				logFile = new File(config.getOrDefault(
						"LogFile",
						DEFAULT_BASE_LOG_FILE.getAbsolutePath()).replace("{user.dir}", userDir)
				);

				String localeString = config.getOrDefault("Locale", DEFAULT_LOCALE.toString());
				String[] localeSplit = localeString.split("_");
				setLocale(new Locale(localeSplit[0], localeSplit[1]));

				regionSelectionColor = new Color(config.getOrDefault("RegionSelectionColor", DEFAULT_REGION_SELECTION_COLOR.toString()));
				chunkSelectionColor = new Color(config.getOrDefault("ChunkSelectionColor", DEFAULT_CHUNK_SELECTION_COLOR.toString()));
				pasteChunksColor = new Color(config.getOrDefault("PasteChunksColor", DEFAULT_PASTE_CHUNKS_COLOR.toString()));
				processThreads = Integer.parseInt(config.getOrDefault("ProcessThreads", DEFAULT_PROCESS_THREADS + ""));
				writeThreads = Integer.parseInt(config.getOrDefault("WriteThreads", DEFAULT_WRITE_THREADS + ""));
				maxLoadedFiles = Integer.parseInt(config.getOrDefault("MaxLoadedFiles", DEFAULT_MAX_LOADED_FILES + ""));
				mcSavesDir = config.getOrDefault("MCSavesDir", DEFAULT_MC_SAVES_DIR);
				if (!new File(mcSavesDir).exists()) {
					mcSavesDir = DEFAULT_MC_SAVES_DIR;
				}
				debug = Boolean.parseBoolean(config.getOrDefault("Debug", DEFAULT_DEBUG + ""));
			} catch (Exception ex) {
				Debug.dumpException("error loading settings", ex);
			}
		}


		// load overlays
		if (DEFAULT_BASE_OVERLAYS_FILE.exists()) {
			JSONArray overlayArray = null;
			try {
				overlayArray = new JSONArray(new String(Files.readAllBytes(DEFAULT_BASE_OVERLAYS_FILE.toPath())));
			} catch (IOException ex) {
				Debug.dumpException("failed to read overlays", ex);
			}
			if (overlayArray != null) {
				List<OverlayParser> overlays = new ArrayList<>();
				for (Object o : overlayArray) {
					try {
						overlays.add(OverlayParser.fromJSON((JSONObject) o));
					} catch (Exception ex) {
						Debug.dumpException("failed to parse overlay", ex);
					}
				}
				Config.overlays = overlays;
			}
		}
	}