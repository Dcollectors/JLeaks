    public ClassFieldInspector(final Class< ? > clazz,
                               final boolean includeFinalMethods) throws IOException {
        final String name = getResourcePath( clazz );
        final InputStream stream = clazz.getResourceAsStream( name );

        if ( stream != null ) {
            processClassWithByteCode( clazz,
                                      stream,
                                      includeFinalMethods );
        } else {
            processClassWithoutByteCode( clazz,
                                         includeFinalMethods );
        }
        stream.close();
    }