	public List<BundleRequirement> getAllRequirements() {
		try {
			updateRequirementsFromMetadata();
		}
		catch (GhidraBundleException e) {
			throw new RuntimeException(e);
		}
		Map<String, BundleRequirement> reqs = getComputedReqs();
		// insert requirements from a source manifest
		ResourceFile manifestFile = getSourceManifestFile();
		if (manifestFile.exists()) {
			try {
				Manifest manifest = new Manifest(manifestFile.getInputStream());
				String importPackage = manifest.getMainAttributes().getValue("Import-Package");
				for (BundleRequirement r : OSGiUtils.parseImportPackage(importPackage)) {
					reqs.putIfAbsent(r.toString(), r);
				}
			}
			catch (IOException | BundleException e) {
				throw new RuntimeException(e);
			}
		}
		return new ArrayList<>(reqs.values());
	}