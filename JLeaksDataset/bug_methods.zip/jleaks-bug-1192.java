  protected void doPost(HttpServletRequest request,
      HttpServletResponse response)
      throws ServletException, IOException {
    response.setContentType("text/html");
    response.setStatus(HttpServletResponse.SC_OK);

    File file = (File) request.getAttribute("upload");
    file.deleteOnExit();

    int length = (int) file.length();
    byte[] buffer = new byte[length];
    InputStream in = new FileInputStream(file);
    in.read(buffer, 0, length);
    String content = new String(buffer, "UTF-8");
    in.close();

    // Slow down the upload so we can verify WebDriver waits.
    try {
      Thread.sleep(2500);
    } catch (InterruptedException ignored) {
    }
    response.getWriter().write(content);
    response.getWriter().write(
        "<script>window.top.window.onUploadDone();</script>");
    response.setStatus(HttpServletResponse.SC_OK);
  }