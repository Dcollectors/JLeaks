    public static MultiLayerNetwork restoreMultiLayerNetwork(@NonNull File file, boolean loadUpdater)
            throws IOException {
        return restoreMultiLayerNetwork(new FileInputStream(file), loadUpdater);
    }