  public void writeToChannel(WritableByteChannel channel) throws IOException
  {
    final ReadableByteChannel from = Channels.newChannel(combineStreams().getInput());
    ByteStreams.copy(from, channel);
  }