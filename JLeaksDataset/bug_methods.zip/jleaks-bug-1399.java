    private static FullHttpResponse clusterStateRespToHttpResponse(HttpMethod method,
                                                                   ClusterStateResponse response,
                                                                   ByteBufAllocator alloc,
                                                                   @Nullable String nodeName) {
        var httpStatus = response.getState().blocks().hasGlobalBlock(RestStatus.SERVICE_UNAVAILABLE)
            ? HttpResponseStatus.SERVICE_UNAVAILABLE
            : HttpResponseStatus.OK;
        try {
            DefaultFullHttpResponse resp;
            if (method == HttpMethod.HEAD) {
                resp = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, httpStatus);
                HttpUtil.setContentLength(resp, 0);
            } else {
                var buffer = alloc.buffer();
                var outputStream = new ByteBufOutputStream(buffer);
                writeJSON(outputStream, response, httpStatus, nodeName);
                resp = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, httpStatus, buffer);
                resp.headers().set(HttpHeaderNames.CONTENT_TYPE, "application/json");
                HttpUtil.setContentLength(resp, buffer.readableBytes());
            }
            return resp;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }