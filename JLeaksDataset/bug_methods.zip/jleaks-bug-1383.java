	private void uploadLogFile(
			Connection connection, 
			int execId, 
			String name, 
			int attempt, 
			File[] files, 
			EncodingType encType) throws ExecutorManagerException, IOException {
		// 50K buffer... if logs are greater than this, we chunk.
		// However, we better prevent large log files from being uploaded somehow
		byte[] buffer = new byte[50*1024];
		int pos = 0;
		int length = buffer.length;
		int startByte = 0;
		BufferedInputStream bufferedStream = null;
		try {
			for (int i = 0; i < files.length; ++i) {
				File file = files[i];
				
				bufferedStream = new BufferedInputStream(new FileInputStream(file));
				int size = bufferedStream.read(buffer, pos, length);
				while (size >= 0) {
					if (pos + size == buffer.length) {
						// Flush here.
						uploadLogPart(
								connection, 
								execId, 
								name, 
								attempt, 
								startByte, 
								startByte + buffer.length, 
								encType, 
								buffer, 
								buffer.length);
						
						pos = 0;
						length = buffer.length;
						startByte += buffer.length;
					}
					else {
						// Usually end of file.
						pos += size;
						length = buffer.length - pos;
					}
					size = bufferedStream.read(buffer, pos, length);
				}
			}
			
			// Final commit of buffer.
			if (pos > 0) {
				uploadLogPart(
						connection, 
						execId, 
						name, 
						attempt, 
						startByte, 
						startByte + pos, 
						encType, 
						buffer, 
						pos);
			}
		}
		catch (SQLException e) {
			throw new ExecutorManagerException("Error writing log part.", e);
		}
		catch (IOException e) {
			throw new ExecutorManagerException("Error chunking", e);
		}
		finally {
			IOUtils.closeQuietly(bufferedStream);
		}
	}