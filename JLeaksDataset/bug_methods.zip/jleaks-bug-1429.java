    public void visit(Code obj) { 

        codeBytes = obj.getCode();
        DataInputStream byteStream = new DataInputStream (new ByteArrayInputStream(codeBytes));

	lineNumberTable = obj.getLineNumberTable();

        try {
            for(int i = 0; i < codeBytes.length; ) {
		PC = i;
		wide = false;
                opCode = byteStream.readUnsignedByte(); 
                i++;
		// System.out.println(OPCODE_NAMES[opCode]);
                int byteStreamArgCount = NO_OF_OPERANDS[opCode];
                if (byteStreamArgCount == UNPREDICTABLE) {

                    if (opCode == LOOKUPSWITCH) {
                        int pad = 4 - (i & 3);
			if (pad == 4) pad = 0;
                        byteStream.skipBytes(pad); 
                        i += pad;	
                        defaultSwitchOffset = byteStream.readInt(); 
                            branchOffset = defaultSwitchOffset;
                            branchTarget = branchOffset+PC;
                        i += 4; 
                        int npairs = byteStream.readInt(); 
                        i += 4;
			switchOffsets = new int[npairs];
		        switchLabels =  new int[npairs];
                        for(int o = 0; o < npairs; o++) {
                            switchLabels[o] = byteStream.readInt();
                            switchOffsets[o] = byteStream.readInt();
                            i += 8;
                        };
			// Sort by offset
                        for(int j = 0; j < npairs; j++) {
			  int min = j;
                          for(int k = j+1; k < npairs; k++) 
				if (switchOffsets[min] > switchOffsets[k])
					min = k;
			  if (min > j) {
				int tmp = switchOffsets[min];
				switchOffsets[min] = switchOffsets[j];
				switchOffsets[j] = tmp;
				tmp = switchLabels[min];
				switchLabels[min] = switchLabels[j];
				switchLabels[j] = tmp;
				}
			}
                    }
                    else if (opCode == TABLESWITCH) {
                        int pad = 4 - (i & 3);
			if (pad == 4) pad = 0;
                        byteStream.skipBytes(pad); 
                        i += pad;	
                        defaultSwitchOffset = byteStream.readInt(); 
                            branchOffset = defaultSwitchOffset;
                            branchTarget = branchOffset+PC;
                        i += 4; 
                        int switchLow = byteStream.readInt(); 
                        i += 4;
                        int switchHigh = byteStream.readInt(); 
                        i += 4;
			int npairs = switchHigh - switchLow +1;
			switchOffsets = new int[npairs];
		        switchLabels =  new int[npairs];
                        for(int o = 0; o < npairs; o++) {
                            switchLabels[o] = o+switchLow;
                            switchOffsets[o] = byteStream.readInt();
                            i += 4;
                        };
                    }
                    else if (opCode == WIDE) {
			wide = true;
                        opCode = byteStream.readUnsignedByte(); 
                        i++;
                        switch (opCode) {
                            case ILOAD:
                                case FLOAD:
                                case ALOAD:
                                case LLOAD:
                                case DLOAD:
                                case ISTORE:
                                case FSTORE:
                                case ASTORE:
                                case LSTORE:
                                case DSTORE:
                                case RET:
                                register = byteStream.readUnsignedShort(); 
                                i+=2;
                                break;
                            case IINC:
                                register = byteStream.readUnsignedShort(); 
                                i+=2;
                                intConstant = byteStream.readShort(); 
                                i+=2;
                                break;
                        default:
                            throw new IllegalStateException("bad wide bytecode: " + OPCODE_NAMES[opCode]);
                        }
                    }
                    else throw new IllegalStateException("bad unpredicatable bytecode: " + OPCODE_NAMES[opCode]);
                }
                else {
                    if (byteStreamArgCount < 0) throw new IllegalStateException("bad length for bytecode: " + OPCODE_NAMES[opCode]);
                    for(int k = 0; k < TYPE_OF_OPERANDS[opCode].length; k++) {

                        int v;
                        int t = TYPE_OF_OPERANDS[opCode][k];
                        int m = MEANING_OF_OPERANDS[opCode][k];
                        boolean unsigned = (m == M_CP || m == M_R || m == M_UINT);
                        switch(t) {
                        case T_BYTE:  
			    if (unsigned) v = byteStream.readUnsignedByte(); 
                            else v = byteStream.readByte(); 
			    /*
			    System.out.print("Read byte " + v);
			    System.out.println(" with meaning" + m);
			    */
			    i++;
                            break;
                        case T_SHORT: 
                            if (unsigned) v = byteStream.readUnsignedShort(); 
                            else v = byteStream.readShort(); 
			    i+=2;
                            break;
                        case T_INT:   
                            v = byteStream.readInt(); i+=4;
                            break;
                        default: 
                            throw new IllegalStateException();
                        }
                        switch(m) {
                        case M_BR : 
                            branchOffset = v;
                            branchTarget = v+PC;
			    break;
                        case M_CP : 
			    constantRef = constant_pool.getConstant(v);
			    if (constantRef instanceof ConstantClass)  {
				ConstantClass clazz = (ConstantClass)constantRef;
				classConstant = getStringFromIndex(clazz.getNameIndex());
				betterClassConstant 
					= classConstant.replace('/','.');
				}
			    if (constantRef instanceof ConstantInteger) 
				intConstant = ((ConstantInteger)constantRef).getBytes();
			    else if (constantRef instanceof ConstantLong) 
				longConstant = ((ConstantLong)constantRef).getBytes();
			    else if (constantRef instanceof ConstantFloat) 
				floatConstant = ((ConstantFloat)constantRef).getBytes();
			    else if (constantRef instanceof ConstantDouble) 
				doubleConstant = ((ConstantDouble)constantRef).getBytes();
			    else if (constantRef instanceof ConstantString) {
				int s = ((ConstantString)constantRef).getStringIndex();
				
			        stringConstant = getStringFromIndex(s);
				}
			    else if (constantRef instanceof ConstantCP) {
				ConstantCP cp = (ConstantCP) constantRef;
				ConstantClass  clazz
				  = (ConstantClass) constant_pool.getConstant(cp.getClassIndex());
				classConstant = getStringFromIndex(clazz.getNameIndex());
				betterClassConstant 
					= classConstant.replace('/','.');
				ConstantNameAndType sig 
				  = (ConstantNameAndType) constant_pool.getConstant(cp.getNameAndTypeIndex());
				nameConstant = getStringFromIndex(sig.getNameIndex());
				sigConstant = getStringFromIndex(sig.getSignatureIndex());
				betterSigConstant 
					= sigConstant.replace('/','.');
				StringBuffer ref = new StringBuffer(
						5+betterClassConstant.length()
						+nameConstant.length()
						+betterSigConstant.length());
			
				ref.append( betterClassConstant )
				.append( "." )
				.append( nameConstant )
				.append( " : " )
				.append( betterSigConstant );
				refConstant = ref.toString();
				}
			    break;
                        case M_R : 
                            register = v;
			    break;
                        case M_UINT : 
                        case M_INT : 
			    intConstant = v;
                        }
                    }

                }
	switch (opCode) {
	    case ILOAD:
		case FLOAD:
		case ALOAD:
		case LLOAD:
		case DLOAD:
		registerKind = opCode - ILOAD;
		break;
		case ISTORE:
		case FSTORE:
		case ASTORE:
		case LSTORE:
		case DSTORE:
		registerKind = opCode - ISTORE;
		break;
		case RET:
		registerKind = R_REF;
		break;
		case GETSTATIC:
		case PUTSTATIC:
			refFieldIsStatic = true;
			break;
		case GETFIELD:
		case PUTFIELD:
			refFieldIsStatic = false;
			break;
		}
	sawOpcode(opCode);

        if (opCode == TABLESWITCH) {
		sawInt(switchLow);
		sawInt(switchHigh);
		int prevOffset = i-PC;
		for(int o = 0; o <= switchHigh-switchLow; o++) {
			sawOffset(switchOffsets[o] - prevOffset);
			prevOffset = switchOffsets[o];
			}
		sawOffset(defaultSwitchOffset - prevOffset);
		}
        else if (opCode == LOOKUPSWITCH) {
		sawInt(switchOffsets.length);
		int prevOffset = i-PC;
		for(int o = 0; o < switchOffsets.length; o++) {
			sawOffset(switchOffsets[o] - prevOffset);
			prevOffset = switchOffsets[o];
		        sawInt(switchLabels[o]);
			}
		sawOffset(defaultSwitchOffset - prevOffset);
		}
	else 
	    for(int k = 0; k < TYPE_OF_OPERANDS[opCode].length; k++) {
		int m = MEANING_OF_OPERANDS[opCode][k];
		switch(m) {
                        case M_BR : 
			    if (branchOffset > 0)
				    sawOffset(branchOffset-(i-PC));
			    else
				    sawOffset(branchOffset);
			    break;
                        case M_CP : 
			    if (constantRef instanceof ConstantInteger) 
				sawInt(intConstant);
			    else if (constantRef instanceof ConstantLong) 
				sawLong(longConstant);
			    else if (constantRef instanceof ConstantFloat) 
				sawFloat(floatConstant);
			    else if (constantRef instanceof ConstantDouble) 
				sawDouble(doubleConstant);
			    else if (constantRef instanceof ConstantString) 
				sawString(stringConstant);
			    else if (constantRef instanceof ConstantFieldref) 
				sawField();
			    else if (constantRef instanceof ConstantMethodref) 
				sawMethod();
			    else if (constantRef instanceof ConstantInterfaceMethodref)
				sawIMethod();
			    else if (constantRef instanceof ConstantClass)
				sawClass();
			    break;
                        case M_R : 
			    sawRegister(register);
			    break;
                        case M_INT : 
		            sawInt(intConstant);
			    break;
			}
		}
            }
        }
        catch (IOException e) {
            System.out.println("Got IO Exception:");
	    e.printStackTrace();
        }

    }