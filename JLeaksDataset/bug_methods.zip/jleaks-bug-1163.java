    public AppsV1Api apiClient(final DeploymentProperties deploymentProperties) {
        try {
            ApiClient client = Config.fromToken(
                    deploymentProperties.getApiServer(),
                    deploymentProperties.getToken(),
                    false
            );
            client.setSslCaCert(new FileInputStream(deploymentProperties.getCaCertPath()));
            return new AppsV1Api(client);

        } catch (IOException e) {
            logger.error("kubernetes apiClient create error", e);
        }
        return null;
    }