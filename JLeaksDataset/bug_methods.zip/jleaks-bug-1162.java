    public static void main(String[] args) throws Exception {
        // Create a connection to the S7 PLC (s7://{hostname/ip}/{racknumber}/{slotnumber})
        logger.info("Connecting");
        try (PlcConnection plcConnection = new PlcDriverManager().getConnection("s7://192.168.0.1/0/0")){
            logger.info("Connected");

            Optional<PlcReader> reader = plcConnection.getReader();
            // Check if this connection support reading of data.
            if (reader.isPresent()) {
                PlcReader plcReader = reader.get();

                Scanner scanner = new Scanner(System.in);
                String line;
                while(!"exit".equalsIgnoreCase(line = scanner.next())) {
                    try {
                        Address address = plcConnection.parseAddress(line);
                        PlcReadResponse plcReadResponse = plcReader.read(new PlcReadRequest(Byte.class, address)).get();
                        List<Object> data = plcReadResponse.getResponseItems().get(0).getValues();
                        System.out.println("Response: " + data.get(0));
                    } catch(Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        // Catch any exception or the application won't be able to finish if something goes wrong.
        catch (Exception e) {
            e.printStackTrace();
        }
        // The application would cleanly terminate after several seconds ... this just speeds things up.
        System.exit(0);
    }