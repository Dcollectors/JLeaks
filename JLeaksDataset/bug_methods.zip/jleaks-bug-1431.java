    private void actuallyTrackUsage(URI trackerUrl, Collection<Plugin> plugins, String entryPoint) throws IOException {
//        System.out.println("Submitting anonymous usage tracking info to " + trackerUrl + " for " + getPluginNames(plugins));
        HttpURLConnection conn = (HttpURLConnection) trackerUrl.toURL().openConnection();
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setRequestMethod("POST");
        conn.connect();
        OutputStream out = conn.getOutputStream();
        XMLOutput xmlOutput = new OutputStreamXMLOutput(out);
        xmlOutput.beginDocument();
        xmlOutput.startTag("findbugs-invocation");
        xmlOutput.addAttribute("version", Version.RELEASE);
        String applicationName = Version.getApplicationName();
        if (applicationName.equals("")) {
            int lastDot = entryPoint.lastIndexOf('.');
            if (lastDot == -1)
                applicationName = entryPoint;
            else
                applicationName = entryPoint.substring(lastDot + 1);
        }
        xmlOutput.addAttribute("app-name", applicationName);
        xmlOutput.addAttribute("app-version", Version.getApplicationVersion());
        xmlOutput.addAttribute("entry-point", entryPoint);
        xmlOutput.addAttribute("os", SystemProperties.getProperty("os.name", ""));
        xmlOutput.addAttribute("java-version", getMajorJavaVersion());
        xmlOutput.addAttribute("uuid", getUuid());
        xmlOutput.stopTag(false);
        for (Plugin plugin : plugins) {
            xmlOutput.startTag("plugin");
            xmlOutput.addAttribute("id", plugin.getPluginId());
            xmlOutput.addAttribute("name", plugin.getShortDescription());
            xmlOutput.addAttribute("version", plugin.getVersion());
            xmlOutput.stopTag(true);
        }

        xmlOutput.closeTag("findbugs-invocation");
        xmlOutput.finish();
        out.close();
        int responseCode = conn.getResponseCode();
        if (responseCode != 200) {
            logError(Level.WARNING, "Error submitting anonymous usage data to " + trackerUrl + ": "
                    + responseCode + " - " + conn.getResponseMessage());
        }
        parseUpdateXml(trackerUrl, plugins, conn.getInputStream());
    }