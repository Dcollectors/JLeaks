    private int calcBitmapSampleSize(Uri bitmapUri) throws IOException {
        InputStream is = getContentResolver().openInputStream(bitmapUri);
        // read image size
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(is, null, options);
        is.close();

        // Get max texture size of OpenGL as it limits bitmap size drawn on Imageview
        int[] maxSize = new int[1];
        GLES10.glGetIntegerv(GLES10.GL_MAX_TEXTURE_SIZE, maxSize, 0);

        int sampleSize = 1;
        while (options.outHeight / sampleSize > maxSize[0] || options.outWidth / sampleSize > maxSize[0]) {
            sampleSize = sampleSize << 1;
        }
        return sampleSize;
    }