	public void execute(String query) throws SQLException {
		Statement s = getConnection().createStatement();
		s.executeUpdate(query);
		s.close();
	}