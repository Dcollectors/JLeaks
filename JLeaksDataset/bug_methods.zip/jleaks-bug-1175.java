    public void onEnable() {
        saveDefaultConfig();
        FileConfiguration config = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "config.yml"));
        boolean needToSaveConfig = false;
        try {
            for (String option : YamlConfiguration.loadConfiguration(getClassLoader().getResource("config.yml").openStream())
                    .getKeys(false)) {
                if (!config.contains(option)) {
                    config.set(option, getConfig().get(option));
                    needToSaveConfig = true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (needToSaveConfig) {
            try {
                config.save(new File(getDataFolder(), "config.yml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        PacketsManager.init(this);
        DisguiseUtilities.init(this);
        DisguiseConfig.setSoundsEnabled(getConfig().getBoolean("DisguiseSounds"));
        DisguiseConfig.setVelocitySent(getConfig().getBoolean("SendVelocity"));
        DisguiseConfig.setViewDisguises(getConfig().getBoolean("ViewSelfDisguises"));
        DisguiseConfig.setHearSelfDisguise(getConfig().getBoolean("HearSelfDisguise"));
        DisguiseConfig.setHideArmorFromSelf(getConfig().getBoolean("RemoveArmor"));
        DisguiseConfig.setHideHeldItemFromSelf(getConfig().getBoolean("RemoveHeldItem"));
        DisguiseConfig.setAddEntityAnimations(getConfig().getBoolean("AddEntityAnimations"));
        DisguiseConfig.setNameOfPlayerShownAboveDisguise(getConfig().getBoolean("ShowNamesAboveDisguises"));
        DisguiseConfig.setNameAboveHeadAlwaysVisible(getConfig().getBoolean("NameAboveHeadAlwaysVisible"));
        DisguiseConfig.setModifyBoundingBox(getConfig().getBoolean("ModifyBoundingBox"));
        DisguiseConfig.setMonstersIgnoreDisguises(getConfig().getBoolean("MonstersIgnoreDisguises"));
        DisguiseConfig.setDisguiseBlownOnAttack(getConfig().getBoolean("BlowDisguises"));
        DisguiseConfig.setDisguiseBlownMessage(ChatColor.translateAlternateColorCodes('&',
                getConfig().getString("BlownDisguiseMessage")));
        DisguiseConfig.setKeepDisguiseOnPlayerDeath(getConfig().getBoolean("KeepDisguises.PlayerDeath"));
        DisguiseConfig.setKeepDisguiseOnPlayerLogout(getConfig().getBoolean("KeepDisguises.PlayerLogout"));
        DisguiseConfig.setKeepDisguiseOnEntityDespawn(getConfig().getBoolean("KeepDisguises.EntityDespawn"));
        try {
            // Here I use reflection to set the plugin for Disguise..
            // Kind of stupid but I don't want open API calls for a commonly used object.
            Field field = Disguise.class.getDeclaredField("plugin");
            field.setAccessible(true);
            field.set(null, this);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        PacketsManager.addPacketListeners(this);
        DisguiseListener listener = new DisguiseListener(this);
        Bukkit.getPluginManager().registerEvents(listener, this);
        getCommand("disguise").setExecutor(new DisguiseCommand());
        getCommand("undisguise").setExecutor(new UndisguiseCommand());
        getCommand("disguiseplayer").setExecutor(new DisguisePlayerCommand());
        getCommand("undisguiseplayer").setExecutor(new UndisguisePlayerCommand());
        getCommand("undisguiseentity").setExecutor(new UndisguiseEntityCommand(listener));
        getCommand("disguiseentity").setExecutor(new DisguiseEntityCommand(listener));
        getCommand("disguiseradius").setExecutor(new DisguiseRadiusCommand(getConfig().getInt("DisguiseRadiusMax")));
        getCommand("undisguiseradius").setExecutor(new UndisguiseRadiusCommand(getConfig().getInt("UndisguiseRadiusMax")));
        getCommand("disguisehelp").setExecutor(new DisguiseHelpCommand());
        registerValues();
    }