        public RollingRandomAccessFileManager createManager(final String name, final FactoryData data) {
            final File file = new File(name);
            final File parent = file.getParentFile();
            if (null != parent && !parent.exists()) {
                parent.mkdirs();
            }

            if (!data.append) {
                file.delete();
            }
            final long size = data.append ? file.length() : 0;
            final long time = file.exists() ? file.lastModified() : System.currentTimeMillis();

            RandomAccessFile raf;
            try {
                raf = new RandomAccessFile(name, "rw");
                if (data.append) {
                    raf.seek(raf.length());
                } else {
                    raf.setLength(0);
                }
                return new RollingRandomAccessFileManager(raf, name, data.pattern, new DummyOutputStream(), data.append,
                        data.immediateFlush, size, time, data.policy, data.strategy, data.advertiseURI, data.layout);
            } catch (final IOException ex) {
                LOGGER.error("RollingRandomAccessFileManager (" + name + ") " + ex);
            }
            return null;
        }