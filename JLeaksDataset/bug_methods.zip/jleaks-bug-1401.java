    public void close() {
        synchronized (this) {
            if (discoveredNodes != null && discoveredNodes.isDone() && !discoveredNodes.isCompletedExceptionally()) {
                DiscoveredNodes nodes = discoveredNodes.join();

                var it = nodes.connections.entrySet().iterator();
                while (it.hasNext()) {
                    DiscoveryNode node = it.next().getKey();
                    transportService.disconnectFromNode(node);
                    it.remove();
                }
            }
            discoveredNodes = null;
        }
    }