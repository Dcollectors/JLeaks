	public byte[] readContents() {
		try {
            return ByteStreams.toByteArray(uri.toURL().openStream());
        } catch (final IOException ioe) {
			throw new RuntimeException(ioe);
		}
	}