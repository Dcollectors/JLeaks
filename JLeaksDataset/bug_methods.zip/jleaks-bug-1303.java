	public synchronized void disconnect()
	{
		try
		{
            currentRepository=null;
            
			closeStepAttributeLookupPreparedStatement();
            closeTransAttributeLookupPreparedStatement();
            closeLookupJobEntryAttribute();
            
            if (!database.isAutoCommit()) commit();
			repinfo.setLock(false);
			database.disconnect();
		}
		catch (KettleException dbe)
		{
			log.logError(toString(), "Error disconnecting from database : " + dbe.getMessage());
			//return false;
		}
	}