    public static Config loadFromFile(File configFile, Properties properties) throws FileNotFoundException {
        checkTrue(configFile != null, "configFile can't be null");
        checkTrue(properties != null, "properties can't be null");

        String path = configFile.getPath();
        InputStream stream = new FileInputStream(configFile);
        if (path.endsWith(".xml")) {
            return applyEnvAndSystemVariableOverrides(
                    new XmlConfigBuilder(stream).setProperties(properties).build().setConfigurationFile(configFile)
            );
        }
        if (path.endsWith(".yaml") || path.endsWith(".yml")) {
            return applyEnvAndSystemVariableOverrides(
                    new YamlConfigBuilder(stream).setProperties(properties).build().setConfigurationFile(configFile)
            );
        }

        throw new IllegalArgumentException("Unknown configuration file extension");
    }