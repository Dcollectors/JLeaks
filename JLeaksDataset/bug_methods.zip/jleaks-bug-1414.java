    private void load(final String table) throws IOException {
        final LineNumberReader reader = new LineNumberReader(new InputStreamReader(new FileInputStream(
                String.format("%s/%s.lproj/%s.strings", resources.getAbsolute(), locale, table)
        ), Charset.forName("UTF-16")));
        String line;
        while((line = reader.readLine()) != null) {
            final Matcher matcher = pattern.matcher(line);
            if(matcher.matches()) {
                cache.put(new Key(table, matcher.group(1)), matcher.group(2));
            }
        }
    }