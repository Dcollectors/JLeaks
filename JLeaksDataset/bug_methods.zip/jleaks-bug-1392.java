    public static void copyStringToFile(String string, File dst, String mode) throws IOException{
        BufferedWriter writer;
        if (Objects.equals(mode, "append")) {
            writer = new BufferedWriter(new FileWriter(dst, true));
        } else {
            writer = new BufferedWriter(new FileWriter(dst, false));
        }
        writer.write(string);
        writer.close();
    }