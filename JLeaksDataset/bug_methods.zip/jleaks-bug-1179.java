   public static File createZipArchive(String dir, String archiveFileName) throws IOException {
      File srcDir = new File(dir);
      String filename = dir + "-" + archiveFileName + ".zip";
      File file = new File(filename);
      FileOutputStream fout = new FileOutputStream(filename);