    default <T> T processStream(Function<InputStream, T> processor) {
        return processor.apply(stream());
    }