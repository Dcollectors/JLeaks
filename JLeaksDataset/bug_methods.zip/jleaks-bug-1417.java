    public boolean authenticate(final Host host, final LoginCallback prompt, CancelCallback cancel)
            throws BackgroundException {
        if(log.isDebugEnabled()) {
            log.debug(String.format("Login using public key authentication with credentials %s", host.getCredentials()));
        }
        if(host.getCredentials().isPublicKeyAuthentication()) {
            final Local identity = host.getCredentials().getIdentity();
            final FileKeyProvider provider;
            try {
                final KeyFormat format = KeyProviderUtil.detectKeyFileFormat(
                        new InputStreamReader(identity.getInputStream()), true);
                if(format.equals(KeyFormat.OpenSSH)) {
                    provider = new OpenSSHKeyFile.Factory().create();
                }
                else if(format.equals(KeyFormat.PKCS8)) {
                    provider = new PKCS8KeyFile.Factory().create();
                }
                else if(format.equals(KeyFormat.PuTTY)) {
                    provider = new PuTTYKeyFile.Factory().create();
                }
                else {
                    throw new IOException(String.format("Unknown key format for file %s", identity.getName()));
                }
                provider.init(new InputStreamReader(identity.getInputStream(), Charset.forName("UTF-8")), new PasswordFinder() {
                    @Override
                    public char[] reqPassword(Resource<?> resource) {
                        if(StringUtils.isEmpty(host.getCredentials().getPassword())) {
                            try {
                                prompt.prompt(host.getProtocol(), host.getCredentials(),
                                        LocaleFactory.localizedString("Private key password protected", "Credentials"),
                                        String.format("%s (%s)",
                                                LocaleFactory.localizedString("Enter the passphrase for the private key file", "Credentials"),
                                                identity.getAbbreviatedPath()), new LoginOptions(host.getProtocol())
                                );
                            }
                            catch(LoginCanceledException e) {
                                // Return null if user cancels
                                return null;
                            }
                        }
                        return host.getCredentials().getPassword().toCharArray();
                    }

                    @Override
                    public boolean shouldRetry(Resource<?> resource) {
                        return false;
                    }
                });
                session.getClient().authPublickey(host.getCredentials().getUsername(), provider);
                return session.getClient().isAuthenticated();
            }
            catch(IOException e) {
                throw new SFTPExceptionMappingService().map(e);
            }
        }
        return false;
    }