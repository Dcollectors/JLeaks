    public void process() throws IOException
    {
        final File newFile = generateUnusedFileName(source, "new");
        final File oldFile = generateUnusedFileName(source, "old");

        try
        {
            final JarFile inputFile = new JarFile(source);
            final LinkedHashMap<String, JarEntry> entries = new LinkedHashMap<>();
            inputFile.stream().forEach(jarEntry -> entries.putIfAbsent(jarEntry.getName(), jarEntry));

            try (JarOutputStream jarOutputStream = new JarOutputStream(Files.newOutputStream(newFile.toPath())))
            {
                entries.forEach(
                    (k, v) ->
                    {
                        final byte[] buf = new byte[4096];
                        try
                        {
                            final InputStream inputStream = inputFile.getInputStream(v);
                            jarOutputStream.putNextEntry(new ZipEntry(k));
                            int read;
                            while (-1 != (read = inputStream.read(buf)))
                            {
                                jarOutputStream.write(buf, 0, read);
                            }
                            jarOutputStream.flush();
                        }
                        catch (final IOException e)
                        {
                            throw new RuntimeException(e);
                        }
                    });
            }

            if (!source.renameTo(oldFile))
            {
                throw new IOException("Failed to rename: " + source + " to " + oldFile);
            }
            if (!newFile.renameTo(source))
            {
                throw new IOException("Failed to rename: " + newFile + " to " + source);
            }

            cleanup(oldFile, null);
        }
        catch (final IOException ex)
        {
            cleanup(newFile, ex);
            cleanup(oldFile, ex);
        }
    }