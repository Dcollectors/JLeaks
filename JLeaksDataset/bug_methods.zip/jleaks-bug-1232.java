  public static void writeJobIdToFile(String hadoopJobIdFileName, String hadoopJobId)
  {
    if (hadoopJobId != null && hadoopJobIdFileName != null) {
      try {
        HadoopDruidIndexerConfig.JSON_MAPPER.writeValue(
            new OutputStreamWriter(new FileOutputStream(new File(hadoopJobIdFileName)), StandardCharsets.UTF_8),
            hadoopJobId
        );
        log.info("MR job id [%s] is written to the file [%s]", hadoopJobId, hadoopJobIdFileName);
      }
      catch (IOException e) {
        log.warn(e, "Error writing job id [%s] to the file [%s]", hadoopJobId, hadoopJobIdFileName);
      }
    } else {
      log.info("Either job id or file name is null for the submitted job. Skipping writing the file [%s]", hadoopJobIdFileName);
    }
  }