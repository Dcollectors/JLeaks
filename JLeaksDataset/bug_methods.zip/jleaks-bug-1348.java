	private String getNameFromContentUri(Uri contentUri) {
		final String name;
		final Cursor returnCursor = application.getContentResolver().query(contentUri, null, null, null, null);
		if (returnCursor != null && returnCursor.moveToFirst()) {
			name = returnCursor.getString(returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
			returnCursor.close();
		} else {
			name = null;
		}
		return name;
	}