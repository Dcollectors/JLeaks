    public ExternalProcess start() throws UncheckedIOException {
      // redirect the stderr to stdout
      builder.redirectErrorStream(true);

      Process process;
      try {
        process = builder.start();
      } catch (IOException ex) {
        throw new UncheckedIOException(ex);
      }

      CircularOutputStream circular;
      try {
        circular = new CircularOutputStream(bufferSize);

        new Thread(
                () -> {
                  InputStream input = process.getInputStream();
                  // use the CircularOutputStream as mandatory, we know it will never raise a
                  // IOException
                  OutputStream output = new MultiOutputStream(circular, copyOutputTo);
                  while (process.isAlive()) {
                    try {
                      // we must read the output to ensure the process will not lock up
                      input.transferTo(output);
                    } catch (IOException ex) {
                      LOG.log(
                          Level.WARNING,
                          "failed to copy the output of process " + process.pid(),
                          ex);
                    }
                  }
                })
            .start();
      } catch (Throwable t) {
        // ensure we do not leak a process in case of failures
        try {
          process.destroyForcibly();
        } catch (Throwable t2) {
          t.addSuppressed(t2);
        }
        throw t;
      }

      return new ExternalProcess(process, circular);
    }