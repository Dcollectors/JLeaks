  DalvikStatsCache() {
    cache = new MapMaker().weakKeys().makeMap();
  }

  DalvikStatsTool.Stats getStats(FileLike entry) {
    String name = entry.getRelativePath();
    if (!name.endsWith(".class")) {
      // Probably something like a pom.properties file in a JAR: this does not contribute
      // to the linear alloc size, so return zero.
      return DalvikStatsTool.Stats.ZERO;
    }

    DalvikStatsTool.Stats stats = cache.get(entry);
    if (stats != null) {
      return stats;
    }

    try {
      stats = DalvikStatsTool.getEstimate(entry.getInput());
      cache.put(entry, stats);
      return stats;
    } catch (IOException e) {
      throw new RuntimeException(String.format("Error calculating size for %s.", name), e);
    } catch (RuntimeException e) {
      throw new RuntimeException(String.format("Error calculating size for %s.", name), e);
    }
  }