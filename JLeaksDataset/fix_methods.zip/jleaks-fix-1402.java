    public CompletableFuture<?> sync(Planner planner, JobsLogs jobsLogs) {
        assert analyzedStatement != null : "analyzedStatement must not be null";

        if (consumer != null && consumer.suspended()) {
            LOGGER.trace("Resuming existing consumer {}", consumer);
            consumer.replaceResultReceiver(resultReceiver, maxRows);
            consumer.resume();
            return resultReceiver.completionFuture();
        }

        UUID jobId = UUID.randomUUID();
        RoutingProvider routingProvider = new RoutingProvider(Randomness.get().nextInt(), planner.getAwarenessAttributes());
        ClusterState clusterState = planner.currentClusterState();
        PlannerContext plannerContext = new PlannerContext(
            clusterState,
            routingProvider,
            jobId,
            planner.functions(),
            transactionContext,
            defaultLimit,
            maxRows
        );
        Plan plan;
        try {
            plan = planner.plan(analyzedStatement, plannerContext);
        } catch (Throwable t) {
            jobsLogs.logPreExecutionFailure(jobId, query, SQLExceptions.messageOf(t), sessionContext.user());
            throw t;
        }

        DependencyCarrier dependencyCarrier = portalContext.getExecutor();
        if (!analyzedStatement.isWriteOperation()) {
            resultReceiver = new RetryOnFailureResultReceiver(
                dependencyCarrier.clusterService(),
                clusterState,
                dependencyCarrier.threadPool().getThreadContext(),
                // not using planner.currentClusterState().metaData()::hasIndex to make sure the *current*
                // clusterState at the time of the index check is used
                indexName -> clusterState.metaData().hasIndex(indexName),
                resultReceiver,
                jobId,
                (newJobId, resultReceiver) -> retryQuery(planner, newJobId)
            );
        }

        jobsLogs.logExecutionStart(jobId, query, sessionContext.user(), StatementClassifier.classify(plan));
        consumer = new RowConsumerToResultReceiver(
            resultReceiver,
            maxRows,
            new JobsLogsUpdateListener(jobId, jobsLogs)
        );
        try {
            plan.execute(
                dependencyCarrier,
                plannerContext,
                consumer,
                rowParams,
                SubQueryResults.EMPTY
            );
        } catch (Exception e) {
            consumer.accept(null, e);
        }
        synced = true;
        return resultReceiver.completionFuture();
    }