  private JsonObject getRequestJSON(HttpServletRequest request) throws IOException {
    JsonObject requestJSON = new JsonObject();

    try (BufferedReader rd = new BufferedReader(new InputStreamReader(request.getInputStream()))) {
      StringBuilder s = new StringBuilder();
      CharStreams.copy(rd, s);
      String json = s.toString();
      if (!"".equals(json)) {
        requestJSON = new JsonParser().parse(json).getAsJsonObject();
      }
    }
    return requestJSON;
  }