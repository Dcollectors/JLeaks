    public DataStreamSink<Row> outputStream(FlinkEnvironment env, DataStream<Row> dataStream) {

        final StreamingFileSink<Row> sink = StreamingFileSink
                .forRowFormat(filePath, (Encoder<Row>) (element, stream) -> {
                    try (PrintStream out = new PrintStream(stream)) {
                        out.println(element);
                    }
                })
                .build();
        return dataStream.addSink(sink);
        }