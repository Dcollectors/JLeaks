  private static String getStdErrorOutput(Optional<Path> stdErr) throws IOException {
    if (!stdErr.isPresent()) {
      return "";
    }
    StringBuilder sb = new StringBuilder();
    try (InputStream inputStream = Files.newInputStream(stdErr.get());
        BufferedReader errorReader = new BufferedReader(new InputStreamReader(inputStream))) {
      while (errorReader.ready()) {
        sb.append("\t").append(errorReader.readLine()).append("\n");
      }
    }
    return sb.toString();
  }