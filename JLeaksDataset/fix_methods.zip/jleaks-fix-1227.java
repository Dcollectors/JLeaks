	public static void copyFile(File source, File target) {

		FileInputStream inputStream = null;
		FileOutputStream outputStream = null;
		try {
			inputStream = new FileInputStream(source);
			outputStream = new FileOutputStream(target);
			FileChannel iChannel = inputStream.getChannel();
			FileChannel oChannel = outputStream.getChannel();

			ByteBuffer buffer = ByteBuffer.allocate(1024);
			while (true) {
				buffer.clear();
				int r = iChannel.read(buffer);
				if (r == -1)
					break;
				buffer.limit(buffer.position());
				buffer.position(0);
				oChannel.write(buffer);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			closeQuitely(inputStream);
			closeQuitely(outputStream);
		}
	}

	private static void closeQuitely(Closeable closeable) {
		if (closeable != null) {
			try {
				closeable.close();
			} catch (Exception ignored) {
			}
		}
	}