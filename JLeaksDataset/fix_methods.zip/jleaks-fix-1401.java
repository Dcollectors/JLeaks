    public void close() {
        synchronized (this) {
            if (discoveredNodes == null) {
                return;
            }
            if (discoveredNodes.isCompletedExceptionally()) {
                discoveredNodes = null;
                return;
            }
            discoveredNodes.thenAccept(nodes -> {
                synchronized (nodes) {
                    var it = nodes.connections.entrySet().iterator();
                    while (it.hasNext()) {
                        DiscoveryNode node = it.next().getKey();
                        transportService.disconnectFromNode(node);
                        it.remove();
                    }
                }
            });
            discoveredNodes = null;
        }
    }