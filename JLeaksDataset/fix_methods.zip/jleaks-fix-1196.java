  private static Properties loadBuildProperties() {
    Properties properties = new Properties();

    Manifest manifest = null;
    JarFile jar = null;
    try {
      URL url = BuildInfo.class.getProtectionDomain().getCodeSource().getLocation();
      File file = new File(url.toURI());
      jar = new JarFile(file);
      manifest = jar.getManifest();
    } catch (NullPointerException ignored) {
    } catch (URISyntaxException ignored) {
    } catch (IOException ignored) {
    } catch (IllegalArgumentException ignored) {
    } finally {
      Closeables.closeQuietly(jar);
    }

    if (manifest == null) {
      return properties;
    }

    try {
      Attributes attributes = manifest.getAttributes("Build-Info");
      Set<Entry<Object, Object>> entries = attributes.entrySet();
      for (Entry<Object, Object> e : entries) {
        properties.put(String.valueOf(e.getKey()), String.valueOf(e.getValue()));
      }
    } catch (NullPointerException e) {
      // Fall through
    }

    return properties;
  }