  private void executeIdempotentImport(
      UUID jobId,
      IdempotentImportExecutor idempotentImportExecutor,
      Collection<? extends DownloadableFile> downloadableFiles)
      throws Exception {
    for (DownloadableFile downloadableFile : downloadableFiles) {
      idempotentImportExecutor.executeAndSwallowIOExceptions(
          downloadableFile.getIdempotentId(),
          downloadableFile.getName(),
          () -> importDownloadableItem(downloadableFile, jobId, idempotentImportExecutor));
    }
  }

  private String importDownloadableItem(
      DownloadableFile item, UUID jobId, IdempotentImportExecutor idempotentImportExecutor)
      throws Exception {
    final long totalFileSize = discardForLength(jobFileStream.streamFile(item, jobId, jobStore));
    if (totalFileSize <= 0) {
      throw new IOException(
          String.format(
              "jobid %s hit empty unexpectedly empty (bytes=%d) download for file %s",
              jobId, totalFileSize, item.getFetchableUrl()));
    }
    try (InputStream fileStream = jobFileStream.streamFile(item, jobId, jobStore)) {
      String itemUploadUrl = createUploadSession(item, idempotentImportExecutor);

      MicrosoftApiResponse finalChunkResponse =
          uploadStreamInChunks(totalFileSize, itemUploadUrl, item.getMimeType(), fileStream);
      checkState(
          finalChunkResponse.isOkay(),
          "final chunk-upload response should have had an ID, but a non-OK response came back: %s",
          finalChunkResponse.toString());

      // get complete file response
      return finalChunkResponse.getJsonValue(
          objectMapper,
          "id",
          "final chunk-upload response should have had ID, but got empty HTTP response-body");
    }
  }