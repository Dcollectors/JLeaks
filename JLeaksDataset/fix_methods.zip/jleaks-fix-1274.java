  private byte[] loadBytes(InputStream inputStream) {
    ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
    try {
      byte[] buf = new byte[512];
      int len;
      while (true) {
        len = inputStream.read(buf);
        if (len == -1) {
          break;
        }
        byteStream.write(buf, 0, len);
      }
      return byteStream.toByteArray();

     } catch (IOException ex) {
       throw new RepositoryException("Couldn't load from InputStream of content, check nested exception.", ex);
     } finally {
       // Close inputstream. Closing of ByteArrayOutputStream not nessecairy, does nothing
       IoUtil.closeSilently(inputStream);
     }
  }