    private static void initializeSyncedRealm(Realm realm) {
        boolean commitChanges = false;
        OsRealmSchema schema = null;
        try {
            realm.beginTransaction();
            long currentVersion = realm.getVersion();
            final boolean unversioned = currentVersion == UNVERSIONED;

            RealmConfiguration configuration = realm.getConfiguration();

            final RealmProxyMediator mediator = configuration.getSchemaMediator();
            final Set<Class<? extends RealmModel>> modelClasses = mediator.getModelClasses();

            final OsRealmSchema.Creator schemaCreator = new OsRealmSchema.Creator();
            for (Class<? extends RealmModel> modelClass : modelClasses) {
                mediator.createRealmObjectSchema(modelClass, schemaCreator);
            }

            // Assumption: When SyncConfiguration then additive schema update mode.
            schema = new OsRealmSchema(schemaCreator);
            long newVersion = configuration.getSchemaVersion();
            // !!! FIXME: This appalling kludge is necessitated by current package structure/visiblity constraints.
            // It absolutely breaks encapsulation and needs to be fixed!
            long schemaNativePointer = schema.getNativePtr();
            if (realm.sharedRealm.requiresMigration(schemaNativePointer)) {
                if (currentVersion >= newVersion) {
                    throw new IllegalArgumentException(String.format(
                            "The schema was changed but the schema version was not updated. " +
                                    "The configured schema version (%d) must be greater than the version " +
                                    " in the Realm file (%d) in order to update the schema.",
                            newVersion, currentVersion));
                }
                realm.sharedRealm.updateSchema(schemaNativePointer, newVersion);
                // The OS currently does not handle setting the schema version. We have to do it manually.
                realm.setVersion(newVersion);
                commitChanges = true;
            }

            final Map<Class<? extends RealmModel>, ColumnInfo> columnInfoMap = new HashMap<>(modelClasses.size());
            for (Class<? extends RealmModel> modelClass : modelClasses) {
                columnInfoMap.put(modelClass, mediator.validateTable(modelClass, realm.sharedRealm, false));
            }

            realm.getSchema().setInitialColumnIndices(
                    (unversioned) ? newVersion : currentVersion,
                    columnInfoMap);

            if (unversioned) {
                final Transaction transaction = configuration.getInitialDataTransaction();
                if (transaction != null) {
                    transaction.execute(realm);
                }
            }
        } catch (Exception e) {
            commitChanges = false;
            throw e;
        } finally {
            if (schema != null) {
                schema.close();
            }
            if (commitChanges) {
                realm.commitTransaction();
            } else {
                realm.cancelTransaction();
            }
        }
    }