	public ConsumerDetails getObject() throws Exception {
		if ("rsa-cert".equals(typeOfSecret)) {
			InputStream inputStream = null;
			try {
				inputStream = resourceLoader.getResource(secret).getInputStream();
				Certificate cert = CertificateFactory.getInstance("X.509").generateCertificate(inputStream);
				consumer.setSignatureSecret(new RSAKeySecret(cert.getPublicKey()));
			}
			catch (IOException e) {
				throw new BeanCreationException("RSA certificate not found at " + secret + ".",
						e);
			}
			catch (CertificateException e) {
				throw new BeanCreationException("Invalid RSA certificate at " + secret + ".", e);
			}
			catch (NullPointerException e) {
				throw new BeanCreationException("Could not load RSA certificate at " + secret + ".", e);
			}
			finally {
				try {
					if (inputStream != null) {
						inputStream.close();
					}
				} 
				catch (IOException e) {
					logger.warn("Cannot close open stream: ", e);
				}
			}
		}
		else {
			consumer.setSignatureSecret(new SharedConsumerSecretImpl(secret));
		}
		return consumer;
	}