	public static List<DirData> loadTestData(String file) throws IOException {
		try (InputStream is = ResourceManager.getResourceAsStream(file)) {
			List<String> lines = FileUtilities.getLines(is);
			List<DirData> data = new ArrayList<>();
			for (String line : lines) {
				data.add(new DirData(line));
			}
			return data;
		}
	}