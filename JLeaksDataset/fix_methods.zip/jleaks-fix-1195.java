    private String stringContentsOfInputStream(Reader rdr) throws IOException {
        StringBuffer sb = new StringBuffer();
        int c;
        try {
          while ((c = rdr.read()) != -1) {
              sb.append((char) c);
          }
          return sb.toString();
        } finally {
          rdr.close();
        }
    }