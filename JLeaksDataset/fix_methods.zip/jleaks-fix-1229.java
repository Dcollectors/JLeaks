    public static void validateTwoSegments(File dir1, File dir2) throws IOException
    {
      try(QueryableIndex queryableIndex1 = loadIndex(dir1)) {
        try(QueryableIndex queryableIndex2 = loadIndex(dir2)) {
          validateTwoSegments(
              new QueryableIndexIndexableAdapter(queryableIndex1),
              new QueryableIndexIndexableAdapter(queryableIndex2)
          );
        }
      }
    }