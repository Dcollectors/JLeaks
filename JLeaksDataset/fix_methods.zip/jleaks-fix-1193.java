  private synchronized void persistKeyPairMap() {
    persistMap(new File(root, KEYMAP_SER_FILE), _rememberedPrivateKeys);
  }

  private void persistMap(File outputFile, Map<?, ?> toPersist) {
    ObjectOutput out = null;
    try {
      out = new ObjectOutputStream(new FileOutputStream(outputFile));
      out.writeObject(toPersist);
      out.flush();
    } catch (FileNotFoundException e) {
      // writing, won't happen.
      e.printStackTrace();
    } catch (IOException e) {
      // very bad
      e.printStackTrace();
      throw new Error(e);
    } finally {
      if (out != null) {
        try {
          out.close();
        } catch (IOException e) {
          // Nothing sane to do.
          log.log(Level.WARNING, "Unable to close " + outputFile.getName(), e);
        }
      }
    }
  }