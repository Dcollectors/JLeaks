   private static File createZipArchive(String dir, String archiveFileName) throws IOException {
      File srcDir = new File(dir);
      String filename = dir + "-" + archiveFileName + ".zip";
      File file = new File(filename);

      try (
         FileOutputStream fout = new FileOutputStream(filename);
         ZipArchiveOutputStream taos = new ZipArchiveOutputStream(fout)
      ) {
         archiveResultsZip(archiveFileName, taos, srcDir, "", true);
         logger.info(Constants.CONSOLE, "Archive: " + filename + " was created");
         return file;
      }
   }