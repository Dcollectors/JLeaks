   public HikariConfig(String propertyFileName)
   {
      this();

      final File propFile = new File(propertyFileName);
      try (final InputStream is = propFile.isFile() ? new FileInputStream(propFile) : this.getClass().getResourceAsStream(propertyFileName)) {
         if (is != null) {
            Properties props = new Properties();
            props.load(is);
            PropertyBeanSetter.setTargetFromProperties(this, props);
         }
         else {
            throw new IllegalArgumentException("Property file " + propertyFileName + " was not found.");
         }
      }
      catch (IOException io) {
         throw new RuntimeException("Error loading properties file", io);
      }
   }