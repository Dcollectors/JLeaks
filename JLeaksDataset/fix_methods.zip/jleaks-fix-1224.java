  protected ChannelFuture sendFile(RandomAccessFile raf, long fileLength) throws IOException {
    // Write the content.
    ChannelFuture writeFuture;
    if (!supportsFileRegion()) {
      // Cannot use zero-copy
      writeFuture = writeToChannel(new ChunkedFile(raf, 0, fileLength, 8192));
    } else {
      // No encryption - use zero-copy.
      FileRegion region = new DefaultFileRegion(raf.getChannel(), 0, fileLength);
      writeFuture = writeToChannel(region);
    }
    if (writeFuture != null) {
      writeFuture.addListener(fut -> raf.close());
    } else {
      raf.close();
    }
    return writeFuture;
  }