    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        if (edgeProxy != null) {
            LOG.debug("Origin channel inactive. channel-info={}", ChannelUtils.channelInfoForLogging(ctx.channel()));
            OriginConnectException ex = new OriginConnectException("Origin server inactive", RESET_CONNECTION);
            edgeProxy.errorFromOrigin(ex);
        }
        super.channelInactive(ctx);
        ctx.close();
    }