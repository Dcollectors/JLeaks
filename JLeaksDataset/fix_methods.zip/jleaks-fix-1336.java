	public BufferedImage read() throws IOException {
		FileInputStream fis;
		try {
			fis = new FileInputStream(sourceFile);

		} catch (FileNotFoundException e) {
			throw new FileNotFoundException(
					"Could not find file: " + sourceFile.getAbsolutePath()
			);
		}

		try {
			imageSource = new InputStreamImageSource(fis);
			imageSource.setThumbnailParameter(param);
			return imageSource.read();

		} catch (UnsupportedFormatException e) {
			String sourcePath = sourceFile.getAbsolutePath();
			throw new UnsupportedFormatException(
					UnsupportedFormatException.UNKNOWN,
					"No suitable ImageReader found for " + sourcePath + "."
			);
		} finally {
			fis.close();
		}
	}