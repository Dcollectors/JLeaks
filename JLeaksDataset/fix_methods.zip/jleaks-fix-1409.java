    public boolean fetch(RowData data) {
        if (data instanceof DdlRowData) {
            DdlRowData ddlRowData = (DdlRowData) data;
            String tableIdentifier = ddlRowData.getTableIdentifier();
            String[] split = tableIdentifier.split("\\.");
            try {
                select.setString(1, split[0].replace("'", ""));
                select.setString(2, split[1].replace("'", ""));
                select.setString(3, ddlRowData.getLsn());
                try (ResultSet resultSet = select.executeQuery()) {
                    String table = null;
                    while (resultSet.next()) {
                        table = resultSet.getString(1);
                    }
                    return table != null;
                }
            } catch (SQLException e) {
                throw new RuntimeException(
                        "Select ddl failed! tableIdentifier: " + tableIdentifier, e);
            }
        }

        return false;
    }