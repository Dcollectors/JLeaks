  public Response execute(Command command) throws IOException {
    if (command.getSessionId() == null) {
      if (QUIT.equals(command.getName())) {
        return new Response();
      }
      if (!GET_ALL_SESSIONS.equals(command.getName())
          && !NEW_SESSION.equals(command.getName())) {
        throw new SessionNotFoundException(
            "Session ID is null. Using WebDriver after calling quit()?");
      }
    }

    HttpRequest httpRequest = commandCodec.encode(command);
    try {
      log(LogType.PROFILER, new HttpProfilerLogEntry(command.getName(), true));
      HttpResponse httpResponse = client.execute(httpRequest, true);
      log(LogType.PROFILER, new HttpProfilerLogEntry(command.getName(), false));

      Response response = responseCodec.decode(httpResponse);
      if (response.getSessionId() == null && httpResponse.getTargetHost() != null) {
        String sessionId = HttpSessionId.getSessionId(httpResponse.getTargetHost());
        response.setSessionId(sessionId);
      }
      if (QUIT.equals(command.getName())) {
    	  client.close();
      }
      return response;
    } catch (UnsupportedCommandException e) {
      if (e.getMessage() == null || "".equals(e.getMessage())) {
        throw new UnsupportedOperationException(
            "No information from server. Command name was: " + command.getName(),
            e.getCause());
      }
      throw e;
    }
  }