  public void writeToChannel(WritableByteChannel channel) throws IOException
  {
    try (final ReadableByteChannel from = Channels.newChannel(combineStreams().getInput())) {
      ByteStreams.copy(from, channel);
    }
  }