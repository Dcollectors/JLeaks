    public void touch(final Path file) throws BackgroundException {
        if(file.isFile()) {
            try {
                final Permission permission = new Permission(Preferences.instance().getInteger("queue.upload.permissions.file.default"));
                final FileAttributes attr = new FileAttributes.Builder()
                        .withPermissions(Integer.parseInt(permission.getMode(), 8))
                        .build();
                final RemoteFile handle = session.sftp().open(file.getAbsolute(), EnumSet.of(OpenMode.CREAT), attr);
                handle.close();
            }
            catch(IOException e) {
                throw new SFTPExceptionMappingService().map("Cannot create file {0}", e, file);
            }
        }
    }