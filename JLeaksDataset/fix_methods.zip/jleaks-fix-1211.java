        public Properties loadConfig() throws Exception {
            Properties properties = new Properties();
            try (InputStream in = new BufferedInputStream(Files.newInputStream(Paths.get(file)))) {
                properties.load(in);
            }
            return properties;
        }