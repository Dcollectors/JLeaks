    public long getLastModified() {
        URLConnection conn = null;
        try {
            conn = getURL().openConnection();
            if (conn instanceof JarURLConnection) {
                // There is a bug in sun's jar url connection that causes file handle leaks when calling getLastModified()
                // Since the time stamps of jar file contents can't vary independent from the jar file timestamp, just use
                // the jar file timestamp
                URL jarURL = ((JarURLConnection)conn).getJarFileURL();
                if (jarURL.getProtocol().equals("file")) {
                    // Return the last modified time of the underlying file - saves some opening and closing
                    return new File(jarURL.getFile()).lastModified();
                } else {
                    // Use the URL mechanism
                    URLConnection jarConn = null;
                    try {
                        jarConn = jarURL.openConnection();
                        return jarConn.getLastModified();
                    } catch (IOException e) {
                        return -1;
                    } finally {
                        try {
                            if (jarConn!=null) jarConn.getInputStream().close();
                        } catch (IOException e) { }
                    }
                }
            } else {
                return conn.getLastModified();
            }
        } catch ( IOException e ) {
            throw new RuntimeException( "Unable to get LastModified for ClasspathResource", e );
        } finally {
            if (conn != null) {
                try {
                    conn.getInputStream().close();
                } catch (IOException e) { }
            }
        }
    }