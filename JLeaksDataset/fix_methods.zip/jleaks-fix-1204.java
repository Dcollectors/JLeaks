  public static JSONObject loadJSON(String resource) {
    InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(resource);

    if (in == null) {
      try {
        in = new FileInputStream(resource);
      } catch (FileNotFoundException e) {
        // ignore
      }
    }

    if (in == null) {
      throw new RuntimeException(resource + " is not a valid resource.");
    }

    StringBuilder b = new StringBuilder();
    InputStreamReader inputreader = new InputStreamReader(in);
    BufferedReader buffreader = new BufferedReader(inputreader);
    String line;

    try {
      while ((line = buffreader.readLine()) != null) {
        b.append(line);
      }
    } catch (IOException e) {
      throw new GridConfigurationException("Cannot read file " + resource + " , " + e.getMessage(), e);
    } finally {
      try {
        buffreader.close();
        inputreader.close();
        in.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }

    String json = b.toString();
    JSONObject o;
    try {
      o = new JSONObject(json);
    } catch (JSONException e) {
      throw new GridConfigurationException("Wrong format for the JSON input : " + e.getMessage(), e);
    }

    return o;
  }