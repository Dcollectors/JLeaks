    private int calculateBitmapSampleSize(Uri bitmapUri) throws IOException {
        InputStream is = null;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        try {
            is = getContentResolver().openInputStream(bitmapUri);
            BitmapFactory.decodeStream(is, null, options); // Just get image size
        } finally {
            CropUtil.closeSilently(is);
        }

        // Get max texture size of OpenGL as it limits bitmap size drawn on ImageView
        int[] maxSize = new int[1];
        GLES10.glGetIntegerv(GLES10.GL_MAX_TEXTURE_SIZE, maxSize, 0);

        int sampleSize = 1;
        while (options.outHeight / sampleSize > maxSize[0] || options.outWidth / sampleSize > maxSize[0]) {
            sampleSize = sampleSize << 1;
        }
        return sampleSize;
    }