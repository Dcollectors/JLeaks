    public void touch(final Path file, final TransferStatus status) throws BackgroundException {
        new DefaultStreamCloser().close(write.write(file, status));
    }