  public void execute(HttpRequest req, HttpResponse resp) throws IOException {
    String resource = req.getUri();
    if (resource.contains(HELPER_SERVLET_ASSET_PATH_PREFIX) &&
        !resource.replace(HELPER_SERVLET_ASSET_PATH_PREFIX, "").contains("/") &&
        !resource.replace(HELPER_SERVLET_ASSET_PATH_PREFIX, "").equals("")) {
      // request is for an asset of the help page
      resource = resource.replace(HELPER_SERVLET_ASSET_PATH_PREFIX, "");
      try (InputStream in = getResourceInputStream(resource)) {
        if (in == null) {
          resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
          return;
        } else {
          resp.setStatus(HttpServletResponse.SC_OK);
          resp.setContent(ByteStreams.toByteArray(in));
          return;
        }
      }
    } else {
      // request is for an unknown entity. show the help page
      try (InputStream in = getResourceInputStream(HELPER_SERVLET_TEMPLATE)) {
        if (in == null) {
          resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
        } else {
          StringBuilder jsonBuilder = new StringBuilder();
          try (JsonOutput out = json.newOutput(jsonBuilder)) {
            out.setPrettyPrint(false).write(servletConfig);
          }

          final String json = jsonBuilder.toString();

          final String htmlTemplate;
          try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, UTF_8))) {
              htmlTemplate = reader.lines().collect(Collectors.joining("\n"));
          }
          final String updatedTemplate =
              htmlTemplate.replace(HELPER_SERVLET_TEMPLATE_CONFIG_JSON_VAR, json);
          if (resource.equals("/")) {
            resp.setStatus(HttpServletResponse.SC_OK);
          } else {
            resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
          }

          resp.setHeader("Content-Type", MediaType.HTML_UTF_8.toString());
          resp.setContent(updatedTemplate.getBytes(UTF_8));
        }
      }
    }
  }