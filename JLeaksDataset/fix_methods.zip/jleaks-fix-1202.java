  private static void addToZip(String basePath, ZipOutputStream zos, File toAdd) throws IOException {
    if (toAdd.isDirectory()) {
      File[] files = toAdd.listFiles();
      if (files != null) {
        for (File file : files) {
          addToZip(basePath, zos, file);
        }
      }
    } else {
      try (FileInputStream fis = new FileInputStream(toAdd)) {
        String name = toAdd.getAbsolutePath().substring(basePath.length() + 1);

        ZipEntry entry = new ZipEntry(name.replace('\\', '/'));
        zos.putNextEntry(entry);


        int len;
        byte[] buffer = new byte[4096];
        while ((len = fis.read(buffer)) != -1) {
          zos.write(buffer, 0, len);
        }

        zos.closeEntry();
      }
    }
  }