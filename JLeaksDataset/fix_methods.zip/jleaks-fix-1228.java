  public Keyset read() throws IOException {
    try {
      Keyset keyset = Keyset.parseFrom(inputStream, ExtensionRegistryLite.getEmptyRegistry());
      return keyset;
    } finally {
      if (closeStreamAfterReading) {
        inputStream.close();
      }
    }
  }