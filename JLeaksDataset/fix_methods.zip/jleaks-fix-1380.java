    InputStream getHistoryGet(String parent, String basename, String rev) {

        ArrayList<String> cmd = new ArrayList<String>();
        InputStream inputStream = null;
        File directory = new File(parent);

        /*
         * ----------------------------------------------------------------- The
         * only way to guarantee getting the contents of a file is to fire off
         * an AccuRev 'stat'us command to get the element ID number for the
         * subsequent 'cat' command. (Element ID's are unique for a file, unless
         * evil twins are present) This is because it is possible that the file
         * may have been moved to a different place in the depot. The 'stat'
         * command will produce a line with the format:
         *
         * <filePath> <elementID> <virtualVersion> (<realVersion>) (<status>)
         *
         *  /./myFile e:17715 CP.73_Depot/2 (3220/2) (backed)
        *-----------------------------------------------------------------
         */
        cmd.add(this.cmd);
        cmd.add("stat");
        cmd.add("-fe");
        cmd.add(basename);
        Executor executor = new Executor(cmd, directory);
        executor.exec();

        String elementID = null;

        try (BufferedReader info = new BufferedReader(executor.getOutputReader())) {
            String line = info.readLine();
            String[] statInfo = line.split("\\s+");
            elementID = statInfo[1].substring(2); // skip over 'e:'

        } catch (IOException e) {
            OpenGrokLogger.getLogger().log(Level.SEVERE,
                    "Could not obtain status for " + basename);
        }

        if (elementID != null) {
            /*
             * ------------------------------------------ This really gets the
             * contents of the file.
            *------------------------------------------
             */
            cmd.clear();
            cmd.add(this.cmd);
            cmd.add("cat");
            cmd.add("-v");
            cmd.add(rev.trim());
            cmd.add("-e");
            cmd.add(elementID);

            executor = new Executor(cmd, directory);
            executor.exec();

            inputStream =
                    new ByteArrayInputStream(executor.getOutputString().getBytes());
        }

        return inputStream;
    }