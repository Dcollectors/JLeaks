  public String readFile(InputFile file) throws IOException {
    try (Reader reader = file.openReader(charset)) {
      return CharStreams.toString(reader);
    }
  }