    @ConditionalOnMissingBean(DeploymentProperties.class)
    public AppsV1Api apiClient(final DeploymentProperties deploymentProperties) {
        try {
            ApiClient client = Config.fromToken(
                    deploymentProperties.getApiServer(),
                    deploymentProperties.getToken(),
                    false
            );
            try (FileInputStream caCertStream = new FileInputStream(deploymentProperties.getCaCertPath())) {
                client.setSslCaCert(caCertStream);
            }
            return new AppsV1Api(client);

        } catch (IOException e) {
            logger.error("kubernetes apiClient create error", e);
        }
        return null;
    }