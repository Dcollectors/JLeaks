    public void onStartInstall(GBDevice device) {
        if (mPBWReader.isFirmware() || mPBWReader.isLanguage()) {
            return;
        }

        File destDir;
        GBDeviceApp app = mPBWReader.getGBDeviceApp();
        try {
            destDir = new File(FileUtils.getExternalFilesDir() + "/pbw-cache");
            destDir.mkdirs();
            FileUtils.copyURItoFile(mContext, mUri, new File(destDir, app.getUUID().toString() + ".pbw"));

            AppManagerActivity.addToAppOrderFile("pbwcacheorder.txt", app.getUUID());
        } catch (IOException e) {
            LOG.error("Installation failed: " + e.getMessage(), e);
            return;
        }

        File outputFile = new File(destDir, app.getUUID().toString() + ".json");
        Writer writer;
        try {
            writer = new BufferedWriter(new FileWriter(outputFile));
        } catch (IOException e) {
            LOG.error("Failed to open output file: " + e.getMessage(), e);
            return;
        }
        try {
            LOG.info(app.getJSON().toString());
            JSONObject appJSON = app.getJSON();
            JSONObject appKeysJSON = mPBWReader.getAppKeysJSON();
            if (appKeysJSON != null) {
                appJSON.put("appKeys", appKeysJSON);
            }
            writer.write(appJSON.toString());

            writer.close();
        } catch (IOException e) {
            LOG.error("Failed to write to output file: " + e.getMessage(), e);
        } catch (JSONException e) {
            LOG.error(e.getMessage(), e);
        }

        InputStream jsConfigFile = mPBWReader.getInputStreamFile("pebble-js-app.js");
        if (jsConfigFile != null) {
            try {
                outputFile = new File(destDir, app.getUUID().toString() + "_config.js");
                FileUtils.copyStreamToFile(jsConfigFile, outputFile);
            } catch (IOException e) {
                LOG.error("Failed to open output file: " + e.getMessage(), e);
            } finally {
                try {
                    jsConfigFile.close();
                } catch (IOException e) {
                }
            }
        }
    }