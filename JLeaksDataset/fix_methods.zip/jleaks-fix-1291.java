  private List<Path> getSourceFiles(BuildContext context) {
    List<Path> srcFiles = new ArrayList<>();
    for (SourcePath path : srcs) {
      Path srcPath = context.getSourcePathResolver().getAbsolutePath(path);
      if (Files.isDirectory(srcPath)) {
        try (Stream<Path> sourcePaths = Files.list(srcPath)) {
          srcFiles.addAll(sourcePaths.filter(Files::isRegularFile).collect(Collectors.toList()));
        } catch (IOException e) {
          throw new RuntimeException("An error occur when listing the files under " + srcPath, e);
        }
      } else {
        srcFiles.add(srcPath);
      }
    }
    return srcFiles;
  }