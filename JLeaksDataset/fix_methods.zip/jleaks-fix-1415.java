    public void mkdir(final Path file, final String type, final TransferStatus status) throws BackgroundException {
        try {
            if(containerService.isContainer(file)) {
                final B2BucketResponse response = session.getClient().createBucket(containerService.getContainer(file).getName(),
                        null == type ? BucketType.valueOf(PreferencesFactory.get().getProperty("b2.bucket.acl.default")) : BucketType.valueOf(type));
                switch(response.getBucketType()) {
                    case allPublic:
                        file.attributes().setAcl(new Acl(new Acl.GroupUser(Acl.GroupUser.EVERYONE, false), new Acl.Role(Acl.Role.READ)));
                }
            }
            else {
                status.setChecksum(session.getFeature(ChecksumCompute.class, ChecksumComputeFactory.get(HashAlgorithm.sha1)).compute(new NullInputStream(0L), status.length(0L)));
                status.setMime(MIMETYPE);
                new DefaultStreamCloser().close(write.write(file, status));
            }
        }
        catch(B2ApiException e) {
            throw new B2ExceptionMappingService(session).map("Cannot create folder {0}", e, file);
        }
        catch(IOException e) {
            throw new DefaultIOExceptionMappingService().map(e);
        }
    }