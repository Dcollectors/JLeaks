  protected void process(HttpServletRequest request, HttpServletResponse response)
      throws IOException {
    String requestJsonString;

    try (BufferedReader rd = new BufferedReader(new InputStreamReader(request.getInputStream()))) {
      requestJsonString = CharStreams.toString(rd);
    }
    log.fine("getting the following registration request  : " + requestJsonString);

    // getting the settings from the registration
    JsonObject json = new JsonParser().parse(requestJsonString).getAsJsonObject();

    if (!json.has("configuration")) {
      // bad request. there must be a configuration for the proxy
      throw new GridConfigurationException("No configuration received for proxy.");
    }

    final RegistrationRequest registrationRequest;
    if (isV2RegistrationRequestJson(json)) {
      // Se2 compatible request
      GridNodeConfiguration nodeConfiguration =
        mapV2Configuration(json.getAsJsonObject("configuration"));
      registrationRequest = new RegistrationRequest(nodeConfiguration);
      // get the "capabilities" and "id" from the v2 json request
      considerV2Json(registrationRequest.getConfiguration(), json);
    } else {
      // Se3 compatible request.
      registrationRequest = RegistrationRequest.fromJson(json);
    }

    final RemoteProxy proxy = BaseRemoteProxy.getNewInstance(registrationRequest, getRegistry());

    reply(response, "ok");

    new Thread(new Runnable() {  // Thread safety reviewed
      public void run() {
        getRegistry().add(proxy);
        log.fine("proxy added " + proxy.getRemoteHost());
      }
    }).start();
  }