    public ExternalProcess start() throws UncheckedIOException {
      // redirect the stderr to stdout
      builder.redirectErrorStream(true);

      Process process;
      try {
        process = builder.start();
      } catch (IOException ex) {
        throw new UncheckedIOException(ex);
      }

      try {
        CircularOutputStream circular = new CircularOutputStream(bufferSize);

        new Thread(
                () -> {
                  // use the CircularOutputStream as mandatory, we know it will never raise a
                  // IOException
                  try (InputStream input = process.getInputStream();
                      OutputStream output = new MultiOutputStream(circular, copyOutputTo)) {
                    // we must read the output to ensure the process will not lock up
                    input.transferTo(output);
                  } catch (IOException ex) {
                    LOG.log(
                        Level.WARNING, "failed to copy the output of process " + process.pid(), ex);
                  }
                  LOG.log(Level.FINE, "completed to copy the output of process " + process.pid());
                })
            .start();

        return new ExternalProcess(process, circular);
      } catch (Throwable t) {
        // ensure we do not leak a process in case of failures
        try {
          process.destroyForcibly();
        } catch (Throwable t2) {
          t.addSuppressed(t2);
        }
        throw t;
      }
    }