	public void execute(String query) throws SQLException {
		try ( Statement s = getConnection().createStatement()) {
			s.execute(query);
		}
	}