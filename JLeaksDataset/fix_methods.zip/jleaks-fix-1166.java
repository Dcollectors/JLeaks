    static Collection<Path> listAllocationDirectoriesIn(File localStateRootDirectory)
            throws IOException {
        try (Stream<Path> fileListStream = Files.list(localStateRootDirectory.toPath())) {
            return fileListStream
                    .filter(path -> path.getFileName().toString().startsWith(ALLOCATION_DIR_PREFIX))
                    .collect(Collectors.toList());
        }
    }