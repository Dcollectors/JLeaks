    public void upload(String uri, InputStream payload, long payloadSize) {
        HttpURLConnection connection = null;
        try {
            URL url = new URI(uri).toURL();

            connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setRequestMethod("PUT");

            try (BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(connection.getOutputStream())) {
                long count = IOUtils.copy(payload, bufferedOutputStream);
                bufferedOutputStream.flush();
                logger.debug("Uploaded {} bytes to uri: {}", count, uri);

                // Check the HTTP response code
                int responseCode = connection.getResponseCode();
                logger.debug("Upload completed with HTTP response code: {}", responseCode);
            }
        } catch (URISyntaxException | MalformedURLException e) {
            String errorMsg = String.format("Invalid path specified: %s", uri);
            logger.error(errorMsg, e);
            throw new ConductorClientException(errorMsg, e);
        } catch (IOException e) {
            String errorMsg = String.format("Error uploading to path: %s", uri);
            logger.error(errorMsg, e);
            throw new ConductorClientException(errorMsg, e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            try {
                if (payload != null) {
                    payload.close();
                }
            } catch (IOException e) {
                logger.warn("Unable to close inputstream when uploading to uri: {}", uri);
            }
        }
    }