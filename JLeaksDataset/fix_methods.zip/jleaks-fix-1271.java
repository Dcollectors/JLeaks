    private Properties createOverridingProperties()
    {
        final Properties retVal = new Properties();

        // Load the properties file if specified
        if (mPropertiesFile != null) {
            FileInputStream inStream = null;
            try {
                inStream = new FileInputStream(mPropertiesFile);
                retVal.load(inStream);
            }
            catch (FileNotFoundException e) {
                throw new BuildException(
                    "Could not find Properties file '" + mPropertiesFile + "'",
                    e, getLocation());
            }
            catch (IOException e) {
                throw new BuildException(
                    "Error loading Properties file '" + mPropertiesFile + "'",
                    e, getLocation());
            }
            finally {
                try {
                    if (inStream != null) {
                        inStream.close();
                    }
                }
                catch (IOException e) {
                    throw new BuildException(
                        "Error closing Properties file '"
                        + mPropertiesFile + "'",
                        e, getLocation());
                }
            }
        }

        // Now override the properties specified
        for (Iterator it = mOverrideProps.iterator(); it.hasNext();) {
            final Property p = (Property) it.next();
            retVal.put(p.getKey(), p.getValue());
        }

        return retVal;
    }