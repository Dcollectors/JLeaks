    protected List<MavenArtifact> processResponse(Dependency dependency, HttpURLConnection conn) throws IOException {
        final JsonObject asJsonObject;
        try (final InputStreamReader streamReader = new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8)) {
            asJsonObject = new JsonParser().parse(streamReader).getAsJsonObject();
        }
        final JsonArray results = asJsonObject.getAsJsonArray("results");
        final int numFound = results.size();
        if (numFound == 0) {
            throw new FileNotFoundException("Artifact " + dependency + " not found in Artifactory");
        }


        final List<MavenArtifact> result = new ArrayList<>(numFound);
        for (JsonElement jsonElement : results) {

            final JsonObject checksumList = jsonElement.getAsJsonObject().getAsJsonObject("checksums");
            final JsonPrimitive sha256Primitive = checksumList.getAsJsonPrimitive("sha256");
            final String sha1 = checksumList.getAsJsonPrimitive("sha1").getAsString();
            final String sha256 = sha256Primitive == null ? null : sha256Primitive.getAsString();
            final String md5 = checksumList.getAsJsonPrimitive("md5").getAsString();

            checkHashes(dependency, sha1, sha256, md5);

            final String downloadUri = jsonElement.getAsJsonObject().getAsJsonPrimitive("downloadUri").getAsString();

            final String path = jsonElement.getAsJsonObject().getAsJsonPrimitive("path").getAsString();

            final Matcher pathMatcher = PATH_PATTERN.matcher(path);
            if (!pathMatcher.matches()) {
                throw new IllegalStateException("Cannot extract the Maven information from the apth retrieved in Artifactory " + path);
            }
            final String groupId = pathMatcher.group("groupId").replace('/', '.');
            final String artifactId = pathMatcher.group("artifactId");
            final String version = pathMatcher.group("version");

            result.add(new MavenArtifact(groupId, artifactId, version, downloadUri, MavenArtifact.derivePomUrl(artifactId, version, downloadUri)));
        }

        return result;
    }