  public static LinuxEphemeralPortRangeDetector getInstance() {
    File file = new File("/proc/sys/net/ipv4/ip_local_port_range");
    if (file.exists() && file.canRead()) {
      try (Reader inputFil = new FileReader(file)) {
        return new LinuxEphemeralPortRangeDetector(inputFil);
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    }
    return new LinuxEphemeralPortRangeDetector(new StringReader("49152 65535"));
  }