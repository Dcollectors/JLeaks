    protected Integer doInBackground(String... args) {
        try {
            URL url = new URL(args[0]);
            try (BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()))){

                Integer latestVersion = Integer.parseInt(in.readLine());
                in.close();

                return latestVersion;

            } catch (IOException e) {
                Log_OC.e(TAG, "Error loading version number", e);
            }
        } catch (MalformedURLException e) {
            Log_OC.e(TAG, "Malformed URL", e);
        }
        return -1;
    }