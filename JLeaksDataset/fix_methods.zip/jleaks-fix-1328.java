    public ClassFieldInspector(final Class< ? > clazz,
                               final boolean includeFinalMethods) throws IOException {
        final String name = getResourcePath( clazz );
        final InputStream stream = clazz.getResourceAsStream( name );

        if ( stream != null ) {
            try {
            processClassWithByteCode( clazz,
                                      stream,
                                      includeFinalMethods );
            } finally {
                stream.close();
            }
        } else {
            processClassWithoutByteCode( clazz,
                                         includeFinalMethods );
        }
    }