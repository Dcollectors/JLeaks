    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: " + AddMessages.class.getName() + " <input collection> <output collection>");
            System.exit(1);
        }

        // Load plugins, in order to get message files
        DetectorFactoryCollection.instance();

        String inputFile = args[0];
        String outputFile = args[1];
        Project project = new Project();

        SortedBugCollection inputCollection = new SortedBugCollection(project);
        inputCollection.readXML(inputFile);

        Document document = inputCollection.toDocument();

        AddMessages addMessages = new AddMessages(inputCollection, document);
        addMessages.execute();

        try (XMLWriter writer = new XMLWriter(new BufferedOutputStream(Files.newOutputStream(Path.of(outputFile))),
                OutputFormat.createPrettyPrint())) {
            writer.write(document);
        }
    }