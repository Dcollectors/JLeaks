	public List<BundleRequirement> getAllRequirements() {
		try {
			updateRequirementsFromMetadata();
		}
		catch (GhidraBundleException e) {
			throw new RuntimeException(e);
		}
		Map<String, BundleRequirement> reqs = getComputedReqs();
		// insert requirements from a source manifest
		ResourceFile manifestFile = getSourceManifestFile();
		if (manifestFile.exists()) {
			try {
				try (InputStream manifestInputStream = manifestFile.getInputStream()) {
					Manifest manifest = new Manifest(manifestInputStream);
					String importPackage = manifest.getMainAttributes().getValue("Import-Package");
					for (BundleRequirement r : OSGiUtils.parseImportPackage(importPackage)) {
						reqs.putIfAbsent(r.toString(), r);
					}
				}
			}
			catch (IOException | BundleException e) {
				throw new RuntimeException(e);
			}
		}
		return new ArrayList<>(reqs.values());
	}