  private void writeSessionExtensionJs(File coreDir) throws IOException {
    FrameGroupCommandQueueSet queueSet =
        FrameGroupCommandQueueSet.getQueueSet(sessionId);

    if (queueSet.getExtensionJs().length() > 0) {
      String path = "scripts/user-extensions.js[" + sessionId + "]";

      FileWriter fileWriter = null;
      BufferedWriter writer = null;

      try {
        fileWriter = new FileWriter(new File(coreDir, path));
        writer = new BufferedWriter(fileWriter);

        writer.write(queueSet.getExtensionJs());
      } finally {
        if (writer != null) {
          writer.close();
        }
        if (fileWriter != null) {
          fileWriter.close();
        }
      }


      fileWriter.close();
    }
  }