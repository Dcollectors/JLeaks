  private String uploadPhoto(PhotoModel photo, UUID jobId) throws IOException, FlickrException {
    BufferedInputStream inStream = imageStreamProvider.get(photo.getFetchableUrl());
    // TODO: do we want to keep COPY_PREFIX?  I think not
    String photoTitle =
        Strings.isNullOrEmpty(photo.getTitle()) ? "" : COPY_PREFIX + photo.getTitle();
    String photoDescription = cleanString(photo.getDescription());

    UploadMetaData uploadMetaData =
        new UploadMetaData()
            .setAsync(false)
            .setPublicFlag(false)
            .setFriendFlag(false)
            .setFamilyFlag(false)
            .setTitle(photoTitle)
            .setDescription(photoDescription);
    perUserRateLimiter.acquire();
    String uploadResult = uploader.upload(inStream, uploadMetaData);
    inStream.close();
    monitor.debug(() -> String.format("%s: Flickr importer uploading photo: %s", jobId, photo));
    return uploadResult;
  }