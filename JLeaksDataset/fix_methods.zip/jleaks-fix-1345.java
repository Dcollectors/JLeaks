    public void close() throws IOException {
        out.close();
        fos.close();
        pdf.close();
    }