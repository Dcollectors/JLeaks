    private Properties retrievePomProperties(String path, final JarFile jar) throws IOException {
        Properties pomProperties = null;
        final String propPath = path.substring(0, path.length() - 7) + "pom.properies";
        final ZipEntry propEntry = jar.getEntry(propPath);
        if (propEntry != null) {
            Reader reader = null;
            try {
                reader = new InputStreamReader(jar.getInputStream(propEntry), "UTF-8");
                pomProperties = new Properties();
                pomProperties.load(reader);
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException ex) {
                        LOGGER.log(Level.FINEST, "close error", ex);
                    }
                }
            }
        }
        return pomProperties;
    }