        public String value() {
            Map<String, Object> value = sourceInput.value();
            if (value == null) {
                return null;
            }
            assert value instanceof LinkedHashMap<String, Object> : "the raw source order should be preserved";
            Map<String, Object> filteredMap = XContentMapValues.filter(value, includes, excludes);
            try (var stream = new BytesStreamOutput(lastSourceSize)) {
                XContentBuilder xContentBuilder = new XContentBuilder(XContentType.JSON.xContent(), stream);
                BytesReference bytes = BytesReference.bytes(xContentBuilder.map(filteredMap));
                lastSourceSize = bytes.length();
                return bytes.utf8ToString();
            } catch (IOException ex) {
                LOGGER.error("could not parse xContent", ex);
            }
            return null;
        }