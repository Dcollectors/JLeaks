    public void apply() throws ApplicationException {
      File objectFile = getObjectFile();
      String[] args = {objectFile.getAbsolutePath(),
              destination.getAbsolutePath()};

      if (objectFile.isDirectory()) {
        if (!destination.exists()) {
            destination.mkdirs();
        }
      } else {

        // If overwriting and the destination exists then kill it
        if (destination.exists() && overwrite) {
          deleteRecursively(destination);
        }

        if (!destination.exists()) {
          if (Utils.insureParentsExist(destination)) {
            if (application != null) {
              application.notifyListeners(application.getFormattedWithPoints(
                      getMsg("progress-copying-file", args)));
            }
            LOG.log(Level.INFO, "copying file '" +
                    objectFile.getAbsolutePath() + "' to '" +
                    destination.getAbsolutePath() + "'");
            FileInputStream fis = null;
            FileOutputStream fos = null;
            try {
              fis = new FileInputStream(objectFile);
              fos = new FileOutputStream(destination);
              byte[] buf = new byte[1024];
              int i;
              while ((i = fis.read(buf)) != -1) {
                fos.write(buf, 0, i);
              }
              if (destination.exists()) {
                // TODO:  set the file's permissions.  This is made easier in
                // Java 1.6 but until then use the TestUtilities methods
                if (Utils.isUnix()) {
                  String permissions =
                          Utils.getFileSystemPermissions(objectFile);
                  Utils.setPermissionsUnix(
                          Utils.getPath(destination),
                          permissions);
                }
              }

              if (application != null) {
                application.notifyListeners(application.getFormattedDone() +
                        application.getLineBreak());
              }

            } catch (Exception e) {
              String errMsg = getMsg("error-copying-file", args);
              throw new ApplicationException(
                      ApplicationException.Type.FILE_SYSTEM_ERROR,
                      errMsg, null);
            } finally {
              if (fis != null) {
                try {
                  fis.close();
                } catch (IOException e) {
                  // ignore;
                }
              }
              if (fos != null) {
                try {
                  fos.close();
                } catch (IOException e) {
                  // ignore;
                }
              }
            }
          } else {
            String errMsg = getMsg("error-copying-file", args);
            throw new ApplicationException(
                    ApplicationException.Type.FILE_SYSTEM_ERROR, errMsg, null);
          }
        } else {
          LOG.log(Level.INFO, "Ignoring file '" +
                  objectFile.getAbsolutePath() + "' since '" +
                  destination.getAbsolutePath() + "' already exists");
          if (application != null) {
            application.notifyListeners(getMsg("info-ignoring-file", args) +
                    application.getLineBreak());
          }
        }
      }
    }