  public void run() {
    Sketch sketch = editor.getSketch();
    
    // first save the sketch so that things don't archive strangely
    boolean success = false;
    try {
      success = sketch.save();
    } catch (Exception e) {
      e.printStackTrace();
    }
    if (!success) {
      Base.showWarning(_("Couldn't archive sketch"),
                       _("Archiving the sketch has been canceled because\nthe sketch couldn't save properly."), null);
      return;
    }

    File location = sketch.getFolder();
    String name = location.getName();
    File parent = new File(location.getParent());

    //System.out.println("loc " + location);
    //System.out.println("par " + parent);

    File newbie = null;
    String namely = null;
    int index = 0;
    do {
      // only use the date if the sketch name isn't the default name
      useDate = !name.startsWith("sketch_");

      if (useDate) {
        String purty = dateFormat.format(new Date());
        String stamp = purty + ((char) ('a' + index));
        namely = name + "-" + stamp;
        newbie = new File(parent, namely + ".zip");

      } else {
        String diggie = numberFormat.format(index + 1);
        namely = name + "-" + diggie;
        newbie = new File(parent, namely + ".zip");
      }
      index++;
    } while (newbie.exists());

    // open up a prompt for where to save this fella
    FileDialog fd = new FileDialog(editor, _("Archive sketch as:"), FileDialog.SAVE);
    fd.setDirectory(parent.getAbsolutePath());
    fd.setFile(newbie.getName());
    fd.setVisible(true);

    String directory = fd.getDirectory();
    String filename = fd.getFile();

    // only write the file if not canceled
    if (filename != null) {
      newbie = new File(directory, filename);

      ZipOutputStream zos = null;
      try {
        //System.out.println(newbie);
        zos = new ZipOutputStream(new FileOutputStream(newbie));

        // recursively fill the zip file
        buildZip(location, name, zos);

        // close up the jar file
        zos.flush();
        editor.statusNotice("Created archive " + newbie.getName() + ".");
      } catch (IOException e) {
        e.printStackTrace();
      } finally {
        IOUtils.closeQuietly(zos);
      }
    } else {
      editor.statusNotice(_("Archive sketch canceled."));
    }
  }