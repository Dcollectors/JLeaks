    public void close() throws BackgroundException {
        this.fireConnectionWillCloseEvent();
        try {
            this.logout();
            this.disconnect();
        }
        finally {
            this.fireConnectionDidCloseEvent();
        }
    }