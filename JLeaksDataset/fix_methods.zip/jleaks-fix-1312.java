    public byte[] readContents() {
        InputStream stream = null;
        try {
            stream = uri.toURL().openStream();
            return ByteStreams.toByteArray(stream);
        } catch (final IOException ioe) {
            throw new RuntimeException(ioe);
        } finally {
            closeStream(stream);
        }
    }