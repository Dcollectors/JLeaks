  public void writeBytesToPath(byte[] bytes, Path pathRelativeToProjectRoot) throws IOException {
    Path path = getPathForRelativePath(pathRelativeToProjectRoot);
    try (OutputStream outputStream = java.nio.file.Files.newOutputStream(path)) {
      outputStream.write(bytes);
    }
  }