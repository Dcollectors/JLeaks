    private static Document parseDocument(@WillClose InputStream in) throws DocumentException {
        try {
            SAXReader reader = new SAXReader();

            Reader r = UTF8.bufferedReader(in);
            Document d = reader.read(r);

            return d;
        } finally {
            Util.closeSilently(in);
        }
    }