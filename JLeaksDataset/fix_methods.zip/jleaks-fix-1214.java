    public void writeMetaFile(File mOutDir, Map<String, Object> meta)
            throws AndrolibException {
        DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
//        options.setIndent(4);
        Yaml yaml = new Yaml(options);

        FileWriter writer = null;
        try {
            writer = new FileWriter(new File(mOutDir, "apktool.yml"));
            yaml.dump(meta, writer);
        } catch (IOException ex) {
            throw new AndrolibException(ex);
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException ex) {}
            }
        }
    }