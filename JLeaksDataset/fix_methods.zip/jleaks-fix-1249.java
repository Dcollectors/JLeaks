    public static void readLines(Path path, Consumer<String> lineProcessor) throws IOException {
        try (Stream<String> stream = Files.lines(path)) {
            stream.forEach(lineProcessor);
        }
    }