    public boolean save(Savable object, File f) throws IOException {
        File parentDirectory = f.getParentFile();
        if (parentDirectory != null && !parentDirectory.exists()) {
            parentDirectory.mkdirs();
        }

        FileOutputStream fos = new FileOutputStream(f);
        try {
            return save(object, fos);
        } finally {
            if (fos != null) {
                fos.close();
            }
        }
    }