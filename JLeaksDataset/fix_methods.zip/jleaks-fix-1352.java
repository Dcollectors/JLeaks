       public Object call(final ArrayList<ArrayList<KeyValue>> rows)
         throws Exception {
         hbase_time += (System.nanoTime() - starttime) / 1000000;
         try {
           if (rows == null) {
             hbase_time += (System.nanoTime() - starttime) / 1000000;
             scanlatency.add(hbase_time);
             LOG.info(TsdbQuery.this + " matched " + nrows + " rows in " +
                 spans.size() + " spans");
             if (nrows < 1) {
               results.callback(null);
             } else {
               results.callback(spans);
             }
             scanner.close();
             return null;
           }
           
           for (final ArrayList<KeyValue> row : rows) {
             final byte[] key = row.get(0).key();
             if (Bytes.memcmp(metric, key, 0, metric_width) != 0) {
               scanner.close();
               throw new IllegalDataException(
                   "HBase returned a row that doesn't match"
                   + " our scanner (" + scanner + ")! " + row + " does not start"
                   + " with " + Arrays.toString(metric));
             }
             Span datapoints = spans.get(key);
             if (datapoints == null) {
               datapoints = new Span(tsdb);
               spans.put(key, datapoints);
             }
             final KeyValue compacted = 
               tsdb.compact(row, datapoints.getAnnotations());
             if (compacted != null) { // Can be null if we ignored all KVs.
               datapoints.addRow(compacted);
               nrows++;
             }
           }
           
           return scan();
         } catch (Exception e) {
           scanner.close();
           results.callback(e);
           return null;
         }
       }