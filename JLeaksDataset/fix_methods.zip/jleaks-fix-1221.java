	private boolean downloadImage() throws IOException {
		InputStream is = getDownloader().getStream(uri, options.getExtraForDownloader());
		try {
			return configuration.diskCache.save(uri, is, this);
		} finally {
			IoUtils.closeSilently(is);
		}
	}