  public boolean exists() throws IOException {
    try (JarFile jarFile = new JarFile(jarPath)) {
      ZipEntry entry = jarFile.getEntry(internalPath);
      return entry != null;
    }
  }