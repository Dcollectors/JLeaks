    static {
        String hash = "NA";
        String hashShort = "NA";
        String timestamp = "NA";

        try {
            String properties = Streams.copyToStringFromClasspath("/crate-build.properties");
            Properties props = new Properties();
            try (FastStringReader fsr = new FastStringReader(properties)) {
                props.load(fsr);
            }
            hash = props.getProperty("hash", hash);
            if (!hash.equals("NA")) {
                hashShort = hash.substring(0, 7);
            }
            String gitTimestampRaw = props.getProperty("timestamp");
            if (gitTimestampRaw != null) {
                timestamp = ISODateTimeFormat.dateTimeNoMillis().withZone(DateTimeZone.UTC).print(Long.parseLong(gitTimestampRaw));
            }
        } catch (IOException e) {
            // just ignore...
        }

        CURRENT = new Build(hash, hashShort, timestamp);
    }