    public AttributedList<Path> list(final Path directory, final ListProgressListener listener) throws BackgroundException {
        try {
            final AttributedList<Path> children = new AttributedList<Path>();
            final RemoteDirectory handle = session.sftp().openDir(directory.getAbsolute());
            for(RemoteResourceInfo f : handle.scan(new RemoteResourceFilter() {
                @Override
                public boolean accept(RemoteResourceInfo remoteResourceInfo) {
                    return true;
                }
            })) {
                final PathAttributes attributes = feature.convert(f.getAttributes());
                final EnumSet<Path.Type> type = EnumSet.noneOf(Path.Type.class);
                if(f.getAttributes().getType().equals(FileMode.Type.DIRECTORY)) {
                    type.add(Path.Type.directory);
                }
                if(f.getAttributes().getType().equals(FileMode.Type.REGULAR)) {
                    type.add(Path.Type.file);
                }
                if(f.getAttributes().getType().equals(FileMode.Type.SYMKLINK)) {
                    type.add(Path.Type.symboliclink);
                }
                final Path file = new Path(directory, f.getName(), type, attributes);
                this.post(file);
                children.add(file);
                listener.chunk(children);
            }
            handle.close();
            return children;
        }
        catch(IOException e) {
            throw new SFTPExceptionMappingService().map("Listing directory failed", e, directory);
        }
    }