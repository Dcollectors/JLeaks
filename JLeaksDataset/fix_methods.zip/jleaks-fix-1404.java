    public Object load(AssetInfo info) throws IOException {
        assetManager = info.getManager();
        InputStream in = info.openStream();
        try {
            return load(in);
        } finally {
            if (in != null)
                in.close();
        }
    }