        private TrustStoreSettings(Settings settings) throws Exception {
            super(settings);

            try (FileInputStream stream = new FileInputStream(new File(keyStorePath))) {
                keyStore.load(stream, keyStorePassword);
            }

            TrustManagerFactory trustFactory =
                TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trustFactory.init(keyStore);

            this.trustManagers = trustFactory.getTrustManagers();
        }