        public long predictMemoryBytes(ExecPlan plan) {
            PlanFeatures planFeatures = FeatureExtractor.extractFeatures(plan.getPhysicalPlan());
            String header = PlanFeatures.featuresHeader();
            String featureString = planFeatures.toFeatureCsv();

            try {
                // Use Apache HttpClient to send the HTTP request
                HttpPost httpPost = new HttpPost(Config.query_cost_prediction_service_address + PREDICT_URL);

                // Encode the request in CSV format
                String csvData = header + "\n" + featureString;
                StringEntity entity = new StringEntity(csvData);
                entity.setContentType("text/csv");
                httpPost.setEntity(entity);

                try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                    int status = response.getStatusLine().getStatusCode();
                    if (status == HttpStatus.SC_OK) {
                        HttpEntity responseEntity = response.getEntity();
                        String responseBody = EntityUtils.toString(responseEntity);
                        return (long) Double.parseDouble(responseBody);
                    } else {
                        // Handle the error
                        throw new IOException("Failed to predict memory bytes: HTTP error code " + status);
                    }
                }
            } catch (IOException e) {
                // Log the error or handle it appropriately
                throw new RuntimeException("Failed to predict memory bytes", e);
            }
        }