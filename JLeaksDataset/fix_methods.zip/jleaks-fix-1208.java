  public static void main(String[] Fiset) {
    Scanner sc = new Scanner(System.in);
    while (true) {
      N = sc.nextInt();
      K = sc.nextInt();

      if (N == 0 && K == 0) break;

      gallery = new int[N][2];
      dp = new Integer[K][N][3];

      for (int i = 0; i < N; i++) {
        gallery[i][LEFT] = sc.nextInt();
        gallery[i][RIGHT] = sc.nextInt();
        sum += gallery[i][LEFT] + gallery[i][RIGHT];
      }

      System.out.println(f(K, N));
    }
    sc.close();
  }