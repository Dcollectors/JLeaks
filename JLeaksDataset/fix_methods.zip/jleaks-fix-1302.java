    public void close() {
        // close everything
        for (NostrRTCSocket socket : connections.values()) {
            try{
                socket.close();
            }catch(Exception e){
                logger.log(Level.WARNING, "Error closing socket", e);
            }
        }
        for (PendingConnection conn : pendingInitiatedConnections.values()) {
            try{
                conn.socket.close();
            }catch(Exception e){
                logger.log(Level.WARNING, "Error closing pending socket", e);
            }
        }
        try{
            this.signaling.close();
        }catch(Exception e){
            logger.log(Level.WARNING, "Error closing signaling", e);
        }
        try{
            this.executor.close();
        }catch(Exception e){
            logger.log(Level.WARNING, "Error closing executor", e);
        }
    }