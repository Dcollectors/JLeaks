  public abstract Optional<String> body();

  /**
   * Builds from key fields within an HTTP response, closing said response
   *
   * <p>Warning: this loads the entire response body to memory, as we assume all Microsoft API
   * responses we're dealing with are (at the most complex end) just JSON responses intended to be
   * parsed (as opposed to say, streams of an arbitrarily-large file's bytes).
   */
  public static MicrosoftApiResponse ofResponse(Response response) throws IOException {
    Builder builder =
        MicrosoftApiResponse.builder()
            .setHttpMessage(response.message())
            .setHttpStatus(response.code());

    if (response.body() != null) {
      final String body;
      try {
        body = response.body().string();
      } catch (IOException e) {
        throw builder
            .build()
            .toIoException("bug? loading body from response shouldn't hit IOException, but did", e);
      }

      if (!Strings.isNullOrEmpty(body)) {
        builder.setBody(body);
      }
      response.close(); // only close if we _had_ a body field to read
    }

    return builder.build();
  }