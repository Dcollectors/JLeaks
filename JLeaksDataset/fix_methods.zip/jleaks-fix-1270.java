    public static ImportControl load(final URI uri) throws CheckstyleException {

        InputStream inputStream = null;
        try {
            inputStream = uri.toURL().openStream();
            final InputSource source = new InputSource(inputStream);
            return load(source, uri);
        }
        catch (final MalformedURLException ex) {
            throw new CheckstyleException("syntax error in url " + uri, ex);
        }
        catch (final IOException ex) {
            throw new CheckstyleException("unable to find " + uri, ex);
        }
        finally {
            closeStream(inputStream);
        }
    }