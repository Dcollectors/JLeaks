  private void refreshMetadataOnMismatchedLength(OutOfRangeException e) {
    try (CloseableResource<FileSystemMasterClient> client =
        mContext.acquireMasterClientResource()) {
      // Force refresh the file metadata by loadMetadata
      AlluxioURI path = new AlluxioURI(mStatus.getPath());
      ListStatusPOptions refreshPathOptions = ListStatusPOptions.newBuilder()
          .setCommonOptions(
              FileSystemMasterCommonPOptions.newBuilder().setSyncIntervalMs(0).build())
          .setLoadMetadataOnly(true)
          .build();
      ListStatusPOptions mergedOptions = FileSystemOptionsUtils.listStatusDefaults(
          mContext.getPathConf(path)).toBuilder().mergeFrom(refreshPathOptions).build();
      client.get().listStatus(path, mergedOptions);
      LOG.info("Notified the master that {} should be sync-ed with UFS on the next access",
          mStatus.getPath());
      throw new IllegalStateException(e.getMessage());
    } catch (AlluxioStatusException x) {
      String msg = String.format("Failed to force a metadata sync on path %s. "
          + "Please manually sync metadata by `bin/alluxio fs loadMetadata -f {path}` "
          + "before you retry reading this file.", mStatus.getPath());
      throw new IllegalStateException(msg, e);
    }
  }