    CGroupHierarchy getCgroupHierarchy() throws IOException {
        if (!Files.exists(PathUtils.get("/proc/self/cgroup"))) {
            return CGroupHierarchy.UNAVAILABLE;
        }
        Predicate<? super String> fileExists = x -> Files.exists(PathUtils.get(x));
        if (V1_FILES.stream().allMatch(fileExists)) {
            return CGroupHierarchy.V1;
        }
        Path cgroupPath = Paths.get("/sys/fs/cgroup");
        for (String v2Glob : V2_FILE_GLOBS) {
            PathMatcher pathMatcher = FileSystems.getDefault().getPathMatcher(v2Glob);
            try (Stream<Path> walk = Files.walk(cgroupPath)) {
                Iterator<Path> it = walk.iterator();
                while (it.hasNext()) {
                    Path path = it.next();
                    if (pathMatcher.matches(path)) {
                        return CGroupHierarchy.V2;
                    }
                }
            }
        }
        return CGroupHierarchy.UNAVAILABLE;
    }