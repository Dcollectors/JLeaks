    public Checksum compute(final InputStream in, final TransferStatus status) throws ChecksumException {
        IOUtils.closeQuietly(in);
        return Checksum.NONE;
    }