	static JdbcChatMemoryRepositoryDialect from(DataSource dataSource) {
		// Simple detection (could be improved)
		try (Connection connection = dataSource.getConnection()) {
			String url = connection.getMetaData().getURL().toLowerCase();
			if (url.contains("postgresql")) {
				return new PostgresChatMemoryRepositoryDialect();
			}
			if (url.contains("mysql")) {
				return new MysqlChatMemoryRepositoryDialect();
			}
			if (url.contains("mariadb")) {
				return new MysqlChatMemoryRepositoryDialect();
			}
			if (url.contains("sqlserver")) {
				return new SqlServerChatMemoryRepositoryDialect();
			}
			if (url.contains("hsqldb")) {
				return new HsqldbChatMemoryRepositoryDialect();
			}
			// Add more as needed
		}
		catch (Exception ignored) {
		}
		return new PostgresChatMemoryRepositoryDialect(); // default
	}