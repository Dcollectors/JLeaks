    default <T> T processStream(Function<InputStream, T> processor) {
        try (InputStream in = stream()) {
            return processor.apply(in);
        } catch (IOException e) {

            // presumably IOException in this situation is only possible on close. All other exceptions won't be of the
            // checked kind
            throw new RuntimeException("Error closing stream", e);
        }
    }