    public void close() {
        trace("close");
        closed = true;
        executeRequests();
        if (pending.get() == 0) {
            setResult();
        }
        stopExecutor();
    }

    private void stopExecutor() {
        scheduledExecutorService.shutdown();
        try {
            scheduledExecutorService.awaitTermination(100, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            scheduledExecutorService.shutdownNow();
        }
    }