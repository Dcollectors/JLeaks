	public static void main(String[] args) throws Exception {
		DetectorFactoryCollection.instance(); // load plugins

		MineBugHistory mineBugHistory = new MineBugHistory();
		MineBugHistoryCommandLine commandLine = mineBugHistory.new MineBugHistoryCommandLine();
		int argCount = commandLine.parse(args, 0, 2, "Usage: " + MineBugHistory.class.getName()
				+ " [options] [<xml results> [<history]] ");

		SortedBugCollection bugCollection = new SortedBugCollection();
		if (argCount < args.length)  
			bugCollection.readXML(args[argCount++], new Project());
		else bugCollection.readXML(System.in, new Project());
		mineBugHistory.setBugCollection(bugCollection);

		mineBugHistory.execute();
		PrintStream out = System.out;
		
		try {
		if (argCount < args.length)  
			out = new PrintStream(args[argCount++]);
		mineBugHistory.dump(out);
		} finally {
		out.close();
		}
		
	}