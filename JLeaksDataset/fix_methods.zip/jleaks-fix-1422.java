    public void touch(final Path file) throws BackgroundException {
        try {
            final IRODSFileSystemAO fs = session.filesystem();
            final int descriptor = fs.createFile(file.getAbsolute(),
                    DataObjInp.OpenFlags.WRITE_TRUNCATE, DataObjInp.DEFAULT_CREATE_MODE);
            fs.fileClose(descriptor, false);
        }
        catch(JargonException e) {
            throw new IRODSExceptionMappingService().map("Cannot create file {0}", e, file);
        }
    }