    public ChannelDefinitionParse execute(EventRegistryEngineConfiguration eventEngineConfig) {
        String encoding = eventEngineConfig.getXmlEncoding();
        ChannelJsonConverter converter = new ChannelJsonConverter();

        try (InputStreamReader in = newInputStreamReaderForSource(encoding)) {
            String channelJson = IOUtils.toString(in);
            channelModel = converter.convertToChannelModel(channelJson);

            if (channelModel != null && channelModel.getKey() != null) {
                ChannelDefinitionEntity channelDefinitionEntity = eventEngineConfig.getChannelDefinitionEntityManager().create();
                channelDefinitionEntity.setCreateTime(new Date());
                channelDefinitionEntity.setKey(channelModel.getKey());
                channelDefinitionEntity.setCategory(channelModel.getCategory());
                channelDefinitionEntity.setName(channelModel.getName());
                channelDefinitionEntity.setDescription(channelModel.getDescription());
                channelDefinitionEntity.setResourceName(name);
                channelDefinitionEntity.setDeploymentId(deployment.getId());
                channelDefinitions.add(channelDefinitionEntity);
            }
        } catch (Exception e) {
            throw new FlowableException("Error parsing channel definition JSON", e);
        }
        return this;
    }