private void write(final File file) 
{
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(file)))
    {
        writer.write("digraph " + graphName + "{");
        writer.newLine();
        for (final String line : lines) {
            writer.write(line + ";");
            writer.newLine();
        }
        writer.write("}");
        writer.flush();
    } catch (IOException exc) {
        throw new BugInCF(exc, "Exception visualizing type:%nfile=%s%ntype=%s", file, type);
    }
}