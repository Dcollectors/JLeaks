private void savePolygons() 
{
    final String polyName = new FileSave("Where To Save Polygons.txt ?", "polygons.txt", mapFolderLocation).getPathString();
    try {
        if (polyName == null) {
            return;
        }
        try (final FileOutputStream out = new FileOutputStream(polyName)) {
            PointFileReaderWriter.writeOneToManyPolygons(out, polygons);
        }
        System.out.println("Data written to :" + new File(polyName).getCanonicalPath());
    } catch (final Exception ex) {
        ClientLogger.logQuietly("file save name: " + polyName, ex);
    }
}