public void close() throws IOException 
{
    outputStream.close();
}