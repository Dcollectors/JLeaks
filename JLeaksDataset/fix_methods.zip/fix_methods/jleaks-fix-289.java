public static void writeFile(File file, InputStream content) throws IOException 
{
    if (content == null) {
        throw new IllegalArgumentException("content must not be null");
    }
    if (!file.exists()) {
        file.createNewFile();
    }
    try (FileOutputStream stream = new FileOutputStream(file)) {
        byte[] buffer = new byte[1024];
        int length;
        while ((length = content.read(buffer)) != -1) {
            stream.write(buffer, 0, length);
        }
    }
    content.close();
}