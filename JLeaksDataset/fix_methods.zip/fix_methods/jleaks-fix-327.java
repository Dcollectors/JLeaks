public NDArray rpowi(Number n) 
{
    try (NDArray temp = manager.create(n);
        NDArray casted = temp.toType(array.getDataType(), false)) {
        TFE_TensorHandle newHandle = manager.opExecutor("Pow").addInput(casted).addInput(array).buildRawPointer(1)[0];
        array.setHandle(newHandle);
        return array;
    }
}