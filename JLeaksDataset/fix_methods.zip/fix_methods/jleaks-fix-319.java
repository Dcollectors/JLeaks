private String getFileText(File sourceFile) 
{
    StringBuilder sb = new StringBuilder();
    try (InputStreamReader isr = new InputStreamReader(new FileInputStream(sourceFile));
        BufferedReader br = new BufferedReader(isr)) {
        if (sourceFile.isFile() && sourceFile.exists()) {
            String lineText = null;
            while ((lineText = br.readLine()) != null) {
                sb.append(lineText).append("\n");
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return sb.toString();
}