    public Configuration getConfiguration(final ConfigurationSource source) {
        final ConfigurationBuilder<BuiltConfiguration> builder;
        try (final InputStream configStream = source.getInputStream()) {
            builder = new Log4j1ConfigurationParser().buildConfigurationBuilder(configStream);
        } catch (IOException e) {
            throw new ConfigurationException("Unable to load " + source.toString(), e);
        }
        if (builder == null) return null;
        return builder.build();
    }