    public void write(final Collection<S> collection, final Local file) throws AccessDeniedException {
        final NSArray list = new NSArray(collection.size());
        int i = 0;
        for(S bookmark : collection) {
            list.setValue(i, bookmark.<NSDictionary>serialize(SerializerFactory.get()));
            i++;
        }
        final String content = list.toXMLPropertyList();
        final OutputStream out = file.getOutputStream(false);
        try {
            IOUtils.write(content, out, Charset.forName("UTF-8"));
        }
        catch(IOException e) {
            throw new AccessDeniedException(String.format("Cannot create file %s", file.getAbsolute()), e);
        }
        finally {
            IOUtils.closeQuietly(out);
        }
    }