  private static JsonObject extractObject(HttpResponse resp) throws IOException {
    try (Reader rd = new BufferedReader(new InputStreamReader(resp.getEntity().getContent()))) {
      StringBuilder s = new StringBuilder();
      CharStreams.copy(rd, s);
      return new JsonParser().parse(s.toString()).getAsJsonObject();
    }
  }