  public void asyncFilePipe(Vertx vertx) {
    final AsyncFile output = vertx.fileSystem().openBlocking("target/classes/plagiary.txt", new OpenOptions());

    vertx.fileSystem().open("target/classes/les_miserables.txt", new OpenOptions(), result -> {
      if (result.succeeded()) {
        AsyncFile file = result.result();
        file.pipeTo(output)
          .onComplete(v -> {
            file.close();
            System.out.println("Copy done");
          });
      } else {
        System.err.println("Cannot open file " + result.cause());
      }
    });
  }