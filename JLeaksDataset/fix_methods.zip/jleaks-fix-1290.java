  private ManifestLoadResult loadManifest(RuleKey key) {
    Preconditions.checkState(useManifestCaching());

    Path path = getManifestPath(rule);

    // Deserialize the manifest.
    Manifest manifest;
    // Keep the file input stream in a separate variable so that it gets closed if the
    // GZIPInputStream constructor throws.
    try (InputStream manifestFile = rule.getProjectFilesystem().newFileInputStream(path);
        InputStream input = new GZIPInputStream(manifestFile)) {
      manifest = new Manifest(input);
    } catch (Exception e) {
      LOG.warn(
          e,
          "Failed to deserialize fetched-from-cache manifest for rule %s with key %s",
          rule,
          key);
      return ManifestLoadResult.error("corrupted manifest path");
    }

    return ManifestLoadResult.success(manifest);
  }