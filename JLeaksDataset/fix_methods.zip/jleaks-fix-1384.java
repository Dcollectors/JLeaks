    public int loadTerms(InputStream is, org.grobid.core.analyzers.Analyzer analyzer, boolean caseSensitive) throws IOException {
        if (terms == null) {
            terms = new HashMap();
        }
        int nbTerms = 0;
        try (InputStreamReader reader = new InputStreamReader(is, UTF_8);
             BufferedReader bufReader = new BufferedReader(reader)) {
            String line;
            while ((line = bufReader.readLine()) != null) {
                if (line.length() == 0) continue;
                line = UnicodeUtil.normaliseText(line);
                line = StringUtils.normalizeSpace(line);
                if (!caseSensitive)
                    line = line.toLowerCase();
                nbTerms += loadTerm(line, analyzer, true);
            }
        } finally {
            // Close the input stream if it's not already closed
            if (is != null) {
                is.close();
            }
        }
        return nbTerms;
    }