    public void close() {
        if (connection != null) {
            connection.close();
        }
    }
