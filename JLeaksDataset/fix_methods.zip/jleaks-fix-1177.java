    public void execute(DiagnosticContext context) {
        try {
            SystemInfo si = new SystemInfo();
            HardwareAbstractionLayer hal = si.getHardware();
            OperatingSystem os = si.getOperatingSystem();
            File sysFileJson = new File(context.tempDir + SystemProperties.fileSeparator + "system-digest.json");

            try (
                OutputStream outputStreamJson = new FileOutputStream(sysFileJson);
                BufferedWriter jsonWriter = new BufferedWriter(new OutputStreamWriter(outputStreamJson));
            ) {
                String jsonInfo = si.toPrettyJSON();
                jsonWriter.write(jsonInfo);
            }

            File sysFile = new File(context.tempDir + SystemProperties.fileSeparator + "system-digest.txt");

            try (
                OutputStream outputStream = new FileOutputStream(sysFile);
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream));
            ) {
                printComputerSystem(writer, hal.getComputerSystem());
                writer.newLine();

                printProcessor(writer, hal.getProcessor());
                writer.newLine();

                printMemory(writer, hal.getMemory());
                writer.newLine();

                printCpu(writer, hal.getProcessor());
                writer.newLine();

                printProcesses(writer, os, hal.getMemory());
                writer.newLine();

                printDisks(writer, hal.getDiskStores());
                writer.newLine();

                printFileSystem(writer, os.getFileSystem());
                writer.newLine();

                printNetworkInterfaces(writer, hal.getNetworkIFs());
                writer.newLine();

                printNetworkParameters(writer, os.getNetworkParams());
                writer.newLine();
            }

            logger.info("Finished querying SysInfo.");
        } catch (final Exception e) {
            logger.info("Failed saving system-digest.txt file.", e);
        }

    }