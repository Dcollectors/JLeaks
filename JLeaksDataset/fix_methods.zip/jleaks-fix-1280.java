    private List<Path> listJars(Path dir) throws IOException {
        try (Stream<Path> stream = Files.list(dir)) {
            return stream
                    .filter(it -> !Files.isDirectory(it))
                    .filter(it -> it.getFileName().endsWith("jar"))
                    .collect(Collectors.toList());
        }
    }