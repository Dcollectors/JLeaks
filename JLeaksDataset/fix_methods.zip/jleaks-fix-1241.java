  private void downloadFile() throws InterruptedException {
    RandomAccessFile file = null;

    try {
      // Open file and seek to the end of it
      file = new RandomAccessFile(outputFile, "rw");
      initialSize = file.length();
      file.seek(initialSize);

      setStatus(Status.CONNECTING);

      Proxy proxy = new CustomProxySelector(PreferencesData.getMap()).getProxyFor(downloadUrl.toURI());
      if ("true".equals(System.getProperty("DEBUG"))) {
        System.err.println("Using proxy " + proxy);
      }

      HttpURLConnection connection = (HttpURLConnection) downloadUrl.openConnection(proxy);

      if (downloadUrl.getUserInfo() != null) {
        String auth = "Basic " + new String(new Base64().encode(downloadUrl.getUserInfo().getBytes()));
        connection.setRequestProperty("Authorization", auth);
      }

      connection.setRequestProperty("Range", "bytes=" + initialSize + "-");
      connection.setConnectTimeout(5000);
      setDownloaded(0);

      // Connect
      connection.connect();
      int resp = connection.getResponseCode();

      if (resp == HttpURLConnection.HTTP_MOVED_PERM || resp == HttpURLConnection.HTTP_MOVED_TEMP) {
        URL newUrl = new URL(connection.getHeaderField("Location"));

        proxy = new CustomProxySelector(PreferencesData.getMap()).getProxyFor(newUrl.toURI());

        // open the new connnection again
        connection = (HttpURLConnection) newUrl.openConnection(proxy);
        if (downloadUrl.getUserInfo() != null) {
          String auth = "Basic " + new String(new Base64().encode(downloadUrl.getUserInfo().getBytes()));
          connection.setRequestProperty("Authorization", auth);
        }

        connection.setRequestProperty("Range", "bytes=" + initialSize + "-");
        connection.setConnectTimeout(5000);

        connection.connect();
        resp = connection.getResponseCode();
      }

      if (resp < 200 || resp >= 300) {
        throw new IOException("Received invalid http status code from server: " + resp);
      }

      // Check for valid content length.
      long len = connection.getContentLength();
      if (len >= 0) {
        setDownloadSize(len);
      }
      setStatus(Status.DOWNLOADING);

      synchronized (this) {
        stream = connection.getInputStream();
      }
      byte buffer[] = new byte[10240];
      while (status == Status.DOWNLOADING) {
        int read = stream.read(buffer);
        if (read == -1)
          break;

        file.write(buffer, 0, read);
        setDownloaded(getDownloaded() + read);

        if (Thread.interrupted()) {
          file.close();
          throw new InterruptedException();
        }
      }

      if (getDownloadSize() != null) {
        if (getDownloaded() < getDownloadSize())
          throw new Exception("Incomplete download");
      }
      setStatus(Status.COMPLETE);
    } catch (InterruptedException e) {
      setStatus(Status.CANCELLED);
      // lets InterruptedException go up to the caller
      throw e;

    } catch (SocketTimeoutException e) {
      setStatus(Status.CONNECTION_TIMEOUT_ERROR);
      setError(e);

    } catch (Exception e) {
      setStatus(Status.ERROR);
      setError(e);

    } finally {
      IOUtils.closeQuietly(file);

      synchronized (this) {
        IOUtils.closeQuietly(stream);
      }
    }
  }