  public static void main(String[] args) throws IOException
  {
    ObjectMapper mapper = new ObjectMapper();

    String[] fields = args[0].split(",");
    File inFile = new File(args[1]);
    File outFile = new File(args[2]);

    FieldHandler[] handlers = new FieldHandler[fields.length];
    for (int i = 0; i < fields.length; i++) {
      String field = fields[i];
      String[] fieldParts = field.split(":");
      String fieldName = fieldParts[0];
      if (fieldParts.length < 2 || "string".equalsIgnoreCase(fieldParts[1])) {
        handlers[i] = new StringField(fieldName);
      }
      else if ("number".equalsIgnoreCase(fieldParts[1])) {
        handlers[i] = new NumberField(fieldName);
      }
      else if ("ISO8601".equals(fieldParts[1])) {
        handlers[i] = new IsoToNumberField(fieldName);
      }
      else {
        throw new IAE("Unknown type[%s]", fieldParts[1]);
      }
    }

    BufferedReader in = null;
    BufferedWriter out = null;
    try {
      in = new BufferedReader(new InputStreamReader(new FileInputStream(inFile), Charsets.UTF_8));
      out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outFile), Charsets.UTF_8));
      String line = null;
      int count = 0;
      long currTime = System.currentTimeMillis();
      long startTime = currTime;
      while ((line = in.readLine()) != null) {
        if (count % 1000000 == 0) {
          long nowTime = System.currentTimeMillis();
          System.out.printf("Processed [%,d] lines in %,d millis.  Incremental time %,d millis.%n", count, nowTime - startTime, nowTime - currTime);
          currTime = nowTime;
        }
        ++count;
        String[] splits = line.split("\t");

        if (splits.length == 30) {
          continue;
        }

        if (splits.length != handlers.length) {
          throw new IAE("splits.length[%d] != handlers.length[%d]; line[%s]", splits.length, handlers.length, line);
        }

        Map<String, Object> jsonMap = Maps.newLinkedHashMap();
        for (int i = 0; i < handlers.length; ++i) {
          jsonMap.put(handlers[i].getFieldName(), handlers[i].process(splits[i]));
        }

        final String str = mapper.writeValueAsString(jsonMap);
        out.write(str);
        out.write("\n");
      }
      System.out.printf("Completed %,d lines in %,d millis.%n", count, System.currentTimeMillis() - startTime);
      out.flush();
    } finally {
      if (out != null) {
        out.close();
      }
      if (in != null) {
        in.close();
      }
    }
  }