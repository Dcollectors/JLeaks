    public void save(String headFile) throws IOException {
        File file = new File(headFile);
        if (!file.isAbsolute()) {
            file = new File(System.getProperty("user.dir")// $NON-NLS-1$
                    + File.separator + headFile);
        }
        try ( FileWriter fw = new FileWriter(file);
                PrintWriter writer = new PrintWriter(fw);) { // TODO Charset ? 
            writer.println("# JMeter generated Header file");// $NON-NLS-1$
            final CollectionProperty hdrs = getHeaders();
            for (int i = 0; i < hdrs.size(); i++) {
                final JMeterProperty hdr = hdrs.get(i);
                Header head = (Header) hdr.getObjectValue();
                writer.println(head.toString());
            }
        }
    }