    private static History readCache(File file) throws IOException {
        try (FileInputStream in = new FileInputStream(file);
            XMLDecoder d = new XMLDecoder(new GZIPInputStream(
                new BufferedInputStream(in)))) {
            return (History) d.readObject();
        }
    }