  public static String zip(File input) throws IOException {
    try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
      try (ZipOutputStream zos = new ZipOutputStream(bos)) {
        if (input.isDirectory()) {
          addToZip(input.getAbsolutePath(), zos, input);
        } else {
          addToZip(input.getParentFile().getAbsolutePath(), zos, input);
        }
      }
      return Base64.getEncoder().encodeToString(bos.toByteArray());
    }
  }