    private long getFileChecksum(String filepath) {

        InputStream inputStream = null;
        try {
            inputStream = new BufferedInputStream(new FileInputStream(filepath));
            CRC32 crc = new CRC32();
            int cnt;
            while ((cnt = inputStream.read()) != -1) {
                crc.update(cnt);
            }

            return crc.getValue();

        } catch (FileNotFoundException e) {
            return -1;
        } catch (IOException e) {
            return -1;
        } finally {
            IOHelper.close(inputStream);
        }
    }