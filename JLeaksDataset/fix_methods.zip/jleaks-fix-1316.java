    public static Config loadFromFile(File configFile, Properties properties) throws FileNotFoundException {
        checkTrue(configFile != null, "configFile can't be null");
        checkTrue(properties != null, "properties can't be null");

        String path = configFile.getPath();
        try (InputStream stream = new FileInputStream(configFile)) {
            final Config config;

            if (path.endsWith(".xml")) {
                config = new XmlConfigBuilder(stream).setProperties(properties).build();
            } else if (path.endsWith(".yaml") || path.endsWith(".yml")) {
                config = new YamlConfigBuilder(stream).setProperties(properties).build();
            } else {
                throw new IllegalArgumentException("Unknown configuration file extension");
            }

            return applyEnvAndSystemVariableOverrides(config.setConfigurationFile(configFile));
        } catch (FileNotFoundException e) {
            throw e;
        } catch (IOException e) {
            throw ExceptionUtil.sneakyThrow(e);
        }
    }