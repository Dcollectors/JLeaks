    public void close() {
        try {
            // 1. try close the split task
            if (snapshotSplitReadTask != null) {
                try {
                    snapshotSplitReadTask.shutdown();
                } catch (Exception e) {
                    log.error("Close snapshot split read task error", e);
                }
            }
            // 2. close the fetcher thread
            if (executorService != null) {
                executorService.shutdown();
                if (!executorService.awaitTermination(
                        READER_CLOSE_TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
                    log.warn(
                            "Failed to close the scan fetcher in {} seconds. Service will execute force close(ExecutorService.shutdownNow)",
                            READER_CLOSE_TIMEOUT_SECONDS);
                    executorService.shutdownNow();
                }
            }
        } catch (Exception e) {
            log.error("Close scan fetcher error", e);
        } finally {
            // 3. close the task context
            if (taskContext != null) {
                taskContext.close();
            }
        }
    }