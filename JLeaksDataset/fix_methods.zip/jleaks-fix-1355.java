    public void loadJar(File file) throws IOException, InvalidNodeException {
        Manifest manifest;
        try (JarFile jarFile = new JarFile(file)) {
            manifest = jarFile.getManifest();
        }
        if (manifest == null)
            throw new IOException(Lang.get("err_noManifestFound"));
        Attributes attr = manifest.getMainAttributes();
        String main = attr.getValue("Main-Class");
        if (main == null)
            throw new IOException(Lang.get("err_noMainFoundInManifest"));

        URLClassLoader cl = new URLClassLoader(new URL[]{file.toURI().toURL()});

        try {
            Class<?> c = cl.loadClass(main);
            ComponentSource cs = (ComponentSource) c.newInstance();
            cs.registerComponents(this);
        } catch (ClassNotFoundException e) {
            throw new IOException(Lang.get("err_mainClass_N_NotFound", main));
        } catch (IllegalAccessException | InstantiationException e) {
            throw new IOException(Lang.get("err_couldNotInitializeMainClass_N", main));
        }
    }