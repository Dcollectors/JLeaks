    public static ArchivingMediaDriver launch(final MediaDriver.Context driverCtx, final Archive.Context archiveCtx)
    {
        MediaDriver driver = null;
        Archive archive = null;
        try
        {
            driver = MediaDriver.launch(driverCtx);

            archive = Archive.launch(archiveCtx
                .mediaDriverAgentInvoker(driver.sharedAgentInvoker())
                .errorHandler(driverCtx.errorHandler())
                .errorCounter(driverCtx.systemCounters().get(SystemCounterDescriptor.ERRORS)));

            return new ArchivingMediaDriver(driver, archive);
        }
        catch (final Exception ex)
        {
            CloseHelper.quietCloseAll(archive, driver);
            throw ex;
        }
    }