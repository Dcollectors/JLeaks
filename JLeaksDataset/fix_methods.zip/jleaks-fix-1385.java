    protected static PDDocument annotate(File originFile, boolean isparallelExec,
                                       final GrobidRestUtils.Annotation type, Engine engine) throws Exception {
        // starts conversion process
        PDDocument outputDocument = null;
        // list of TEI elements that should come with coordinates
        List<String> elementWithCoords = new ArrayList();
            elementWithCoords.add("ref");
            elementWithCoords.add("biblStruct");

        GrobidAnalysisConfig config = new GrobidAnalysisConfig
                .GrobidAnalysisConfigBuilder()
                .generateTeiCoordinates(elementWithCoords)
                .build();

        Document teiDoc = engine.fullTextToTEIDoc(originFile, config);

        try (PDDocument document = PDDocument.load(originFile)) {
            //If no pages, skip the document
            if (document.getNumberOfPages() > 0) {
                DocumentSource documentSource = DocumentSource.fromPdf(originFile);
                if (isparallelExec) {
                    outputDocument = dispatchProcessing(type, document, documentSource, teiDoc);
                    GrobidPoolingFactory.returnEngine(engine);
                } else {
                    synchronized (engine) {
                        //TODO: VZ: sync on local var does not make sense
                        outputDocument = dispatchProcessing(type, document, documentSource, teiDoc);
                    }
                }
            } else {
                throw new RuntimeException("Cannot identify any pages in the input document. " +
                    "The document cannot be annotated. Please check whether the document is valid or the logs.");
            }
        }

        return outputDocument;
    }