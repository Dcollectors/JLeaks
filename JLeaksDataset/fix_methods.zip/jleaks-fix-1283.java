    public void close() {
        if (cursor != null) {
            cursor.close();
        }
        if (clientProvider != null) {
            clientProvider.close();
        }
    }