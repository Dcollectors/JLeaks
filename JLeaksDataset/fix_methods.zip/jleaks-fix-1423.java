    public byte[] readToByteArray(final Path file) throws BackgroundException {
        final Read read = session.getFeature(Read.class);
        final InputStream in = read.read(file, new TransferStatus());
        try {
            return IOUtils.toByteArray(in);
        }
        catch(IOException e) {
            throw new DefaultIOExceptionMappingService().map(e);
        }
        finally {
            try {
                in.close();
            }
            catch(IOException e) {
                throw new DefaultIOExceptionMappingService().map(e);
            }
        }
    }