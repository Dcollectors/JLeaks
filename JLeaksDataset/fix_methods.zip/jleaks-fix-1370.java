    public static void deriveKeyWithScrypt(KeyCrypterScrypt keyCrypterScrypt, String password, DeriveKeyResultHandler resultHandler) {
        new Thread(() -> {
            try {
                log.debug("Doing key derivation");
                long start = System.currentTimeMillis();
                KeyParameter aesKey = keyCrypterScrypt.deriveKey(password);
                long duration = System.currentTimeMillis() - start;
                log.debug("Key derivation took {} msec", duration);
                UserThread.execute(() -> {
                    try {
                        resultHandler.handleResult(aesKey);
                    } catch (Throwable t) {
                        t.printStackTrace();
                        log.error("Executing task failed. " + t.getMessage());
                        throw t;
                    }
                });
            } catch (Throwable t) {
                t.printStackTrace();
                log.error("Executing task failed. " + t.getMessage());
                throw t;
            }
        }, "ScryptUtil:deriveKeyWithScrypt").start();
    }