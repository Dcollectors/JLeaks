    private static <T> T parseResponse(final Class<T> resultType, final HttpURLConnection connection) throws IOException {
        throwIOExceptionOnErrorResponse(connection);
        try (InputStream stream = connection.getInputStream()) {
            return MAPPER.readValue(stream, resultType);
        }
    }