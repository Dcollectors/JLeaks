	public FileImageSource(String sourceFilePath)
	{
		super();
		
		if (sourceFilePath == null)
		{
			throw new NullPointerException("File cannot be null.");
		}
		
		this.sourceFile = new File(sourceFilePath);
	}

	public BufferedImage read() throws IOException
	{
		try
		{
			FileInputStream fis = new FileInputStream(sourceFile);
			imageSource = new InputStreamImageSource(fis);
			imageSource.setThumbnailParameter(param);
			BufferedImage img = imageSource.read();
			fis.close();

			return img;
		}
		catch (FileNotFoundException e)
		{
			throw new FileNotFoundException(
					"Could not find file: " + sourceFile.getAbsolutePath()
			);
		}
		catch (UnsupportedFormatException e)
		{
			String sourcePath = sourceFile.getAbsolutePath();
			throw new UnsupportedFormatException(
					UnsupportedFormatException.UNKNOWN,
					"No suitable ImageReader found for " + sourcePath + "."
			);
		}
	}