{
    ImmutableSetMultimap.Builder<String, String> mapping = ImmutableSetMultimap.builder();
    try {
        Enumeration<URL> urls = loader.getResources("META-INF/classes.lst");
        while (urls.hasMoreElements()) {
            URL url = urls.nextElement();
            try (InputStream stream = url.openStream();
                Reader rdr = new InputStreamReader(stream);
                BufferedReader buf = new BufferedReader(rdr)) {
                String line = buf.readLine();
                while (line != null) {
                    int idx = line.lastIndexOf('.');
                    if (idx >= 0) {
                        String name = line.substring(idx + 1);
                        String pkg = line.substring(0, idx);
                        mapping.put(name, pkg);
                    }
                    line = buf.readLine();
                }
            }
        }
    } catch (IOException e) {
        throw new RuntimeException("Error loading class lists", e);
    }
    return new ClassDirectory(mapping.build());
}