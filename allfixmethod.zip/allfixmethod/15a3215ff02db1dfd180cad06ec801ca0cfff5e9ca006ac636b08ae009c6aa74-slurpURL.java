{
    return slurpURL(new URL(path));
}