{
    LOG.tracev("Closing result set [{0}]", resultSet);
    if (resultSet instanceof InvalidatableWrapper) {
        final InvalidatableWrapper<ResultSet> wrapper = (InvalidatableWrapper<ResultSet>) resultSet;
        close(wrapper.getWrappedObject());
        wrapper.invalidate();
        return;
    }
    try {
        resultSet.close();
    } catch (SQLException e) {
        LOG.debugf("Unable to release JDBC result set [%s]", e.getMessage());
    } catch (Exception e) {
        // try to handle general errors more elegantly
        LOG.debugf("Unable to release JDBC result set [%s]", e.getMessage());
    }
}