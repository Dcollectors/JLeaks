{
    byte[] rowBeingRead = null;
    byte[] previousRow = null;
    byte[] previousCol = null;
    NavigableMap<byte[], byte[]> map = Maps.newTreeMap(Bytes.BYTES_COMPARATOR);
    while (iterator.hasNext()) {
        Map.Entry<byte[], byte[]> entry = iterator.peekNext();
        // if we have reached past the endKey, nothing was found, return null
        if (endKey != null && KeyValue.KEY_COMPARATOR.compare(entry.getKey(), endKey) >= 0) {
            break;
        }
        // if this is part of a multi-row scan and we reach the next row, stop without advancing iterator
        KeyValue kv = KeyValue.fromKey(entry.getKey());
        if (multiRow) {
            byte[] rowKey = kv.getRow();
            if (rowBeingRead != null) {
                if (Bytes.compareTo(rowKey, rowBeingRead) > 0) {
                    break;
                }
            }
        }
        // it is safe to consume this entry, advance the iterator
        iterator.next();
        // Determine if this KV is visible
        if (tx != null && !tx.isVisible(kv.getTimestamp())) {
            continue;
        }
        // have we seen this row & column before?
        byte[] row = kv.getRow();
        byte[] column = kv.getQualifier();
        boolean seenThisColumn = previousRow != null && Bytes.equals(previousRow, row) && previousCol != null && Bytes.equals(previousCol, column);
        if (seenThisColumn) {
            continue;
        }
        // remember that this is the last column we have seen
        previousRow = row;
        previousCol = column;
        // is it a column we want?
        if (columns == null || Arrays.binarySearch(columns, column, Bytes.BYTES_COMPARATOR) >= 0) {
            byte[] value = entry.getValue();
            // only add to map if it is not a delete
            if (tx == null || !Bytes.equals(value, DELETE_MARKER)) {
                map.put(column, value);
                // first time we add a column. must remember the row key to know when to stop
                if (multiRow && rowBeingRead == null) {
                    rowBeingRead = kv.getRow();
                }
                if (limit > 0 && map.size() >= limit) {
                    break;
                }
            }
        }
    }
    // note this will return null for the row being read if multiRow is false (because the caller knows the row)
    return new ImmutablePair<byte[], NavigableMap<byte[], byte[]>>(rowBeingRead, map);
}