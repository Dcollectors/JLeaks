{
    LenskitConfiguration dataConfig = input.getConfiguration();
    LenskitRecommenderEngineBuilder builder = LenskitRecommenderEngine.newBuilder();
    for (LenskitConfiguration config : environment.loadConfigurations(getConfigFiles())) {
        builder.addConfiguration(config);
    }
    builder.addConfiguration(dataConfig, ModelDisposition.EXCLUDED);
    Stopwatch timer = Stopwatch.createStarted();
    LenskitRecommenderEngine engine = builder.build();
    timer.stop();
    logger.info("built model in {}", timer);
    File output = getOutputFile();
    CompressionMode comp = CompressionMode.autodetect(output);
    logger.info("writing model to {}", output);
    try (OutputStream raw = new FileOutputStream(output);
        OutputStream stream = comp.wrapOutput(raw)) {
        engine.write(stream);
    }
}