{
    String cluster = args[0];
    String role = args[1];
    String environ = args[2];
    String heronHome = args[3];
    String configPath = args[4];
    String configOverrideEncoded = args[5];
    String topologyName = args[6];
    String sCommand = args[7];
    // Optional argument in the case of restart - TO DO convert into CLI
    String containerId = Integer.toString(-1);
    if (args.length == 9) {
        containerId = args[8];
    }
    IRuntimeManager.Command command = IRuntimeManager.Command.makeCommand(sCommand);
    // first load the defaults, then the config from files to override it
    Config.Builder defaultsConfig = Config.newBuilder().putAll(ClusterDefaults.getDefaults()).putAll(ClusterConfig.loadConfig(heronHome, configPath));
    // add config parameters from the command line
    Config.Builder commandLineConfig = Config.newBuilder().put(Keys.cluster(), cluster).put(Keys.role(), role).put(Keys.environ(), environ).put(Keys.topologyContainerIdentifier(), containerId);
    Config.Builder topologyConfig = Config.newBuilder().put(Keys.topologyName(), topologyName);
    // TODO (Karthik) override any parameters from the command line
    // build the final config by expanding all the variables
    Config config = Config.expand(Config.newBuilder().putAll(defaultsConfig.build()).putAll(commandLineConfig.build()).putAll(topologyConfig.build()).build());
    LOG.info("Static config loaded successfully ");
    LOG.info(config.toString());
    // 1. Do prepare work
    // create an instance of state manager
    String statemgrClass = Context.stateManagerClass(config);
    IStateManager statemgr = (IStateManager) Class.forName(statemgrClass).newInstance();
    // initialize the statemgr
    statemgr.initialize(config);
    // create an instance of runtime manager
    String runtimeManagerClass = Context.runtimeManagerClass(config);
    IRuntimeManager runtimeManager = (IRuntimeManager) Class.forName(runtimeManagerClass).newInstance();
    boolean isSuccessful = false;
    // Put it in a try block so that we can always clean resources
    try {
        boolean isValid = validateRuntimeManage(statemgr, topologyName);
        // 2. Try to manage topology if valid
        if (isValid) {
            // invoke the appropriate command to manage the topology
            LOG.info("Topology: " + topologyName + " to be " + command + "ed");
            isSuccessful = manageTopology(config, command, statemgr, runtimeManager);
        }
    } finally {
        // 3. Do generic cleaning
        // close the state manager
        statemgr.close();
        // close the runtime manager
        runtimeManager.close();
        // 4. Do post work basing on the result
        if (!isSuccessful) {
            LOG.severe("Failed to " + command + " topology " + topologyName);
            Runtime.getRuntime().exit(1);
        } else {
            LOG.info("Topology " + topologyName + " " + command + " successfully");
            Runtime.getRuntime().exit(0);
        }
    }
}