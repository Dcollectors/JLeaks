{
    Objects.requireNonNull(stream);
    Objects.requireNonNull(fileType);
    Objects.requireNonNull(out);
    // throws IllegalArgumentException if not supported
    AuFileFormat auFileFormat = (AuFileFormat) getAudioFileFormat(fileType, stream);
    // first write the file without worrying about length fields
    final int bytesWritten;
    try (final FileOutputStream fos = new FileOutputStream(out);
        final BufferedOutputStream bos = new BufferedOutputStream(fos)) {
        bytesWritten = writeAuFile(stream, auFileFormat, bos);
    }
    // now, if length fields were not specified, calculate them,
    // open as a random access file, write the appropriate fields,
    // close again....
    if (auFileFormat.getByteLength() == AudioSystem.NOT_SPECIFIED) {
        // $$kk: 10.22.99: jan: please either implement this or throw an exception!
        // $$fb: 2001-07-13: done. Fixes Bug 4479981
        try (final RandomAccessFile raf = new RandomAccessFile(out, "rw")) {
            if (raf.length() <= 0x7FFFFFFFl) {
                // skip AU magic and data offset field
                raf.skipBytes(8);
                raf.writeInt(bytesWritten - AuFileFormat.AU_HEADERSIZE);
                // that's all
            }
        }
    }
    return bytesWritten;
}