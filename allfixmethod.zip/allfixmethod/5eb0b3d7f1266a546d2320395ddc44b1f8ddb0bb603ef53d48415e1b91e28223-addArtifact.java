{
    if (parentArtifacts == null || parentArtifacts.isEmpty()) {
        return addArtifact(artifactId, artifactFile);
    }
    try (CloseableClassLoader parentClassLoader = createParentClassLoader(artifactId, parentArtifacts)) {
        ArtifactClasses artifactClasses = artifactInspector.inspectArtifact(artifactId, artifactFile, parentClassLoader);
        ArtifactMeta meta = new ArtifactMeta(artifactClasses, parentArtifacts);
        return artifactStore.write(artifactId, meta, Files.newInputStreamSupplier(artifactFile));
    }
}