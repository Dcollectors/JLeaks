{
    final TenantContext context = _tenantContextFactory.getContext(tenant);
    final RepositoryFolder rootFolder = context.getTenantRootFolder();
    logger.info("Uploading ZIP file for tenant repository: {}", tenant);
    try (final InputStream inputStream = file.getInputStream()) {
        ZipInputStream zipInputStream = new ZipInputStream(inputStream);
        decompress(zipInputStream, rootFolder);
    }
    final Map<String, String> result = new HashMap<String, String>();
    result.put("status", "Success");
    result.put("repository_path", rootFolder.getQualifiedPath());
    return result;
}