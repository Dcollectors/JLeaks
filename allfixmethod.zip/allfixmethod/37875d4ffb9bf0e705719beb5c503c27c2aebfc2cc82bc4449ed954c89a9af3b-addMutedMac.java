{
    if (isMacMuted(mac)) {
        removeMutedMac(mac);
    }
    Timestamp muteTillTs = null;
    if (muteTill != null) {
        muteTillTs = new Timestamp(muteTill.toEpochMilli());
    }
    logger.fine("Muting mac:" + mac);
    final Connection con = Database.getDerbyConnection();
    try {
        try (final PreparedStatement ps = con.prepareStatement("insert into muted_macs (mac, mute_till) values (?, ?)")) {
            ps.setString(1, mac);
            ps.setTimestamp(2, muteTillTs);
            ps.execute();
        }
        con.commit();
    } catch (final SQLException sqle) {
        if (sqle.getErrorCode() == 30000) {
            // this is ok
            // the mac is muted as expected
            logger.info("Tried to create duplicate muted mac:" + mac + " error:" + sqle.getMessage());
            return;
        }
        throw new IllegalStateException("Error inserting muted mac:" + mac, sqle);
    } finally {
        DbUtil.closeConnection(con);
    }
}