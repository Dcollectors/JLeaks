{
    byte[] byteArray = createGraphAsByteArray(command, workDir);
    return new ByteArrayInputStream(byteArray);
}