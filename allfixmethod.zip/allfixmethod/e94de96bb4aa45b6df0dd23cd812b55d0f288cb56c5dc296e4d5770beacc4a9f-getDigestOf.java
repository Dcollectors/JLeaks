{
    // Note: getDigestOf() closes the input stream.
    return getDigestOf(Files.newInputStream(fileToPath(file)));
}