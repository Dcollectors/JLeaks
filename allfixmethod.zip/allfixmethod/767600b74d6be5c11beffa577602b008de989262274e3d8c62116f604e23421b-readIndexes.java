{
    String indexName = null;
    ArrayList<Column> list = Utils.newSmallArrayList();
    IndexType indexType = null;
    while (rs.next()) {
        if (rs.getShort("TYPE") == DatabaseMetaData.tableIndexStatistic) {
            // ignore index statistics
            continue;
        }
        String newIndex = rs.getString("INDEX_NAME");
        if (pkName != null && pkName.equals(newIndex)) {
            continue;
        }
        if (indexName != null && !indexName.equals(newIndex)) {
            addIndex(list, indexType);
            indexName = null;
        }
        if (indexName == null) {
            indexName = newIndex;
            list.clear();
        }
        boolean unique = !rs.getBoolean("NON_UNIQUE");
        indexType = unique ? IndexType.createUnique(false, false) : IndexType.createNonUnique(false);
        String col = rs.getString("COLUMN_NAME");
        col = convertColumnName(col);
        Column column = columnMap.get(col);
        list.add(column);
    }
    if (indexName != null) {
        addIndex(list, indexType);
    }
}