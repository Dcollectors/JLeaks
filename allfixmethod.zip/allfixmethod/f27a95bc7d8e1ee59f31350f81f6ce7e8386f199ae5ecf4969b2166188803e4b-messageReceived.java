{
    if (e.getMessage() instanceof HttpRequest) {
        HttpRequest request = (HttpRequest) e.getMessage();
        if (request.getMethod() == HttpMethod.POST) {
            ChannelBuffer result;
            ChannelBufferInputStream in = new ChannelBufferInputStream(request.getContent());
            try {
                result = ChannelBuffers.copiedBuffer(new XmlRpcWorker(xmlRpcContext.getHandlerMapping()).execute(in, xmlRpcContext));
            } catch (Throwable ex) {
                context.getChannel().close();
                LOG.error(ex);
                return;
            } finally {
                in.close();
            }
            HttpResponse response = Responses.create("text/xml");
            response.setContent(result);
            Responses.send(response, request, context);
            return;
        }
    }
    context.sendUpstream(e);
}