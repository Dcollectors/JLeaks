{
    try (MessageProtocolHandler protocolHandler = this.protocolHandler) {
        connection.close();
    }
}