{
    try {
        Supplier<Path> workDir = () -> Paths.get(System.getProperty("user.dir"));
        // 
        // Parser & Terminal
        // 
        DefaultParser parser = new DefaultParser();
        parser.setEofOnUnclosedBracket(Bracket.CURLY, Bracket.ROUND, Bracket.SQUARE);
        parser.setEofOnUnclosedQuote(true);
        parser.setEscapeChars(null);
        // change default regex to support shell commands
        parser.setRegexCommand("[:]{0,1}[a-zA-Z!]{1,}\\S*");
        Terminal terminal = TerminalBuilder.builder().build();
        if (terminal.getWidth() == 0 || terminal.getHeight() == 0) {
            // hard coded terminal size when redirecting
            terminal.setSize(new Size(120, 40));
        }
        Thread executeThread = Thread.currentThread();
        terminal.handle(Signal.INT, signal -> executeThread.interrupt());
        // 
        // Create jnanorc config file for demo
        // 
        File file = new File(Repl.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
        // forward slashes works better also in windows!
        String root = file.getCanonicalPath().replace("classes", "").replaceAll("\\\\", "/");
        File jnanorcFile = Paths.get(root, "jnanorc").toFile();
        if (!jnanorcFile.exists()) {
            try (FileWriter fw = new FileWriter(jnanorcFile)) {
                fw.write("include " + root + "nanorc/*.nanorc\n");
            }
        }
        // 
        // ScriptEngine and command registries
        // 
        GroovyEngine scriptEngine = new GroovyEngine();
        scriptEngine.put("ROOT", root);
        ConfigurationPath configPath = new ConfigurationPath(Paths.get(root), Paths.get(root));
        Printer printer = new DefaultPrinter(scriptEngine, configPath);
        ConsoleEngineImpl consoleEngine = new ConsoleEngineImpl(scriptEngine, printer, workDir, configPath);
        Builtins builtins = new Builtins(workDir, configPath, (String fun) -> new ConsoleEngine.WidgetCreator(consoleEngine, fun));
        MyCommands myCommands = new MyCommands(workDir);
        ReplSystemRegistry systemRegistry = new ReplSystemRegistry(parser, terminal, workDir, configPath);
        systemRegistry.register("groovy", new GroovyCommand(scriptEngine, printer));
        systemRegistry.setCommandRegistries(consoleEngine, builtins, myCommands);
        systemRegistry.addCompleter(scriptEngine.getScriptCompleter());
        systemRegistry.setScriptDescription(scriptEngine::scriptDescription);
        // 
        // LineReader
        // 
        Path jnanorc = configPath.getConfig("jnanorc");
        SyntaxHighlighter commandHighlighter = SyntaxHighlighter.build(jnanorc, "COMMAND");
        SyntaxHighlighter argsHighlighter = SyntaxHighlighter.build(jnanorc, "ARGS");
        SyntaxHighlighter groovyHighlighter = SyntaxHighlighter.build(jnanorc, "Groovy");
        SystemHighlighter highlighter = new SystemHighlighter(commandHighlighter, argsHighlighter, groovyHighlighter);
        highlighter.addFileHighlight("nano", "less", "slurp");
        highlighter.addFileHighlight("groovy", "classloader", Arrays.asList("-a", "--add"));
        LineReader reader = LineReaderBuilder.builder().terminal(terminal).completer(systemRegistry.completer()).parser(parser).highlighter(highlighter).variable(LineReader.SECONDARY_PROMPT_PATTERN, "%M%P > ").variable(LineReader.INDENTATION, 2).variable(LineReader.LIST_MAX, 100).variable(LineReader.HISTORY_FILE, Paths.get(root, "history")).option(Option.INSERT_BRACKET, true).option(Option.EMPTY_WORD_OPTIONS, false).option(Option.USE_FORWARD_SLASH, // use forward slash in directory separator
        true).option(Option.DISABLE_EVENT_EXPANSION, true).build();
        if (OSUtils.IS_WINDOWS) {
            // if enabled cursor remains in begin parenthesis (gitbash)
            reader.setVariable(LineReader.BLINK_MATCHING_PAREN, 0);
        }
        // 
        // complete command registries
        // 
        consoleEngine.setLineReader(reader);
        builtins.setLineReader(reader);
        myCommands.setLineReader(reader);
        // 
        // widgets and console initialization
        // 
        new TailTipWidgets(reader, systemRegistry::commandDescription, 5, TipType.COMPLETER);
        KeyMap<Binding> keyMap = reader.getKeyMaps().get("main");
        keyMap.bind(new Reference(Widgets.TAILTIP_TOGGLE), KeyMap.alt("s"));
        systemRegistry.initialize(Paths.get(root, "init.jline").toFile());
        // 
        // REPL-loop
        // 
        System.out.println(terminal.getName() + ": " + terminal.getType());
        while (true) {
            try {
                // delete temporary variables and reset output streams
                systemRegistry.cleanUp();
                String line = reader.readLine("groovy-repl> ");
                line = parser.getCommand(line).startsWith("!") ? line.replaceFirst("!", "! ") : line;
                Object result = systemRegistry.execute(line);
                consoleEngine.println(result);
            } catch (UserInterruptException e) {
                // Ignore
            } catch (EndOfFileException e) {
                String pl = e.getPartialLine();
                if (pl != null) {
                    // execute last line from redirected file (required for Windows)
                    try {
                        consoleEngine.println(systemRegistry.execute(pl));
                    } catch (Exception e2) {
                        systemRegistry.trace(e2);
                    }
                }
                break;
            } catch (Exception | Error e) {
                // print exception and save it to console variable
                systemRegistry.trace(e);
            }
        }
        // persist pipeline completer names etc
        systemRegistry.close();
        Set<Thread> threadSet = Thread.getAllStackTraces().keySet();
        // check Groovy GUI apps
        boolean groovyRunning = false;
        for (Thread t : threadSet) {
            if (t.getName().startsWith("AWT-Shut")) {
                groovyRunning = true;
                break;
            }
        }
        if (groovyRunning) {
            consoleEngine.println("Please, close Groovy Consoles/Object Browsers!");
        }
    } catch (Throwable t) {
        t.printStackTrace();
    }
}