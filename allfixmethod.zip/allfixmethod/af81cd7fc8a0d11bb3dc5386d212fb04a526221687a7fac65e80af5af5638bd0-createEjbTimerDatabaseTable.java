{
    checkDerbyDriver();
    final String url = getDatabaseUrl(dbDir);
    final Connection conn = DriverManager.getConnection(url);
    deleteTable(conn);
    final Statement cs = conn.createStatement();
    try {
        cs.executeUpdate(createStatement);
    } finally {
        cs.close();
    }
}