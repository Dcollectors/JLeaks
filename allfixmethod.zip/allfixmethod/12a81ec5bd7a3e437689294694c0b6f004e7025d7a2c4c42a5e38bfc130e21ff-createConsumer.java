{
    return new ReactorReceiver(amqpConnection, entityPath, receiver, receiveLinkHandler, tokenManager, reactorProvider.getReactorDispatcher(), retryOptions);
}