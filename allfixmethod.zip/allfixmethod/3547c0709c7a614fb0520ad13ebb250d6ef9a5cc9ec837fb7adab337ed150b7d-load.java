{
    return parseInputStream(in, charsetName, baseUri, parser);
}