{
    List<KeyValueScanner> memStoreScanners = null;
    if (includeMemstoreScanner) {
        this.lock.readLock().lock();
        try {
            memStoreScanners = this.memstore.getScanners(readPt);
        } finally {
            this.lock.readLock().unlock();
        }
    }
    try {
        List<StoreFileScanner> sfScanners = StoreFileScanner.getScannersForStoreFiles(files, cacheBlocks, usePread, isCompaction, false, matcher, readPt);
        List<KeyValueScanner> scanners = new ArrayList<>(sfScanners.size() + 1);
        scanners.addAll(sfScanners);
        // Then the memstore scanners
        if (memStoreScanners != null) {
            scanners.addAll(memStoreScanners);
        }
        return scanners;
    } catch (Throwable t) {
        clearAndClose(memStoreScanners);
        throw t instanceof IOException ? (IOException) t : new IOException(t);
    }
}