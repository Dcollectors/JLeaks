{
    // Store data to a file.
    String filename = makeFilename(o);
    File file = new File(directory, filename);
    if (file.createNewFile()) {
        boolean deleteOnExit = JRPropertiesUtil.getInstance(jasperReportsContext).getBooleanProperty(PROPERTY_TEMP_FILES_SET_DELETE_ON_EXIT);
        if (deleteOnExit) {
            file.deleteOnExit();
        }
        try (BufferedOutputStream bufferedOut = new BufferedOutputStream(new FileOutputStream(file))) {
            writeData(o, bufferedOut);
        } catch (FileNotFoundException e) {
            log.error("Error virtualizing object", e);
            throw new JRRuntimeException(e);
        }
    } else {
        if (!isReadOnly(o)) {
            throw new IllegalStateException("Cannot virtualize data because the file \"" + filename + "\" already exists.");
        }
    }
}