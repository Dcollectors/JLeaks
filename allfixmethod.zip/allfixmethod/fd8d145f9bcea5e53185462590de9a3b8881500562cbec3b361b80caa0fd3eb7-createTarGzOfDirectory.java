{
    String tarGzPath = directoryPath.substring(0);
    while (tarGzPath.endsWith("/")) {
        tarGzPath = tarGzPath.substring(0, tarGzPath.length() - 1);
    }
    tarGzPath = tarGzPath + TAR_GZ_FILE_EXTENTION;
    return createTarGzOfDirectory(directoryPath, tarGzPath);
}