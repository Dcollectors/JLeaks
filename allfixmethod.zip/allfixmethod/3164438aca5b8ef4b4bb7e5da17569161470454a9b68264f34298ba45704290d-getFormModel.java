{
    final Map<String, Object> map = new HashMap<String, Object>();
    map.put("promptText", getPromptText());
    map.put("selectedTableName", _selectedTableName);
    try (final DatastoreConnection con = _datastore.openConnection()) {
        final Schema[] schemas = con.getSchemaNavigator().getSchemas();
        final List<Schema> schemaList = CollectionUtils.filter(schemas, new Predicate<Schema>() {

            @Override
            public Boolean eval(Schema schema) {
                final boolean isInformationSchema = SchemaComparator.isInformationSchema(schema);
                return !isInformationSchema;
            }
        });
        for (Schema schema : schemaList) {
            // make sure all table names are cached.
            schema.getTableNames();
        }
        map.put("schemas", schemaList);
        return map;
    }
}