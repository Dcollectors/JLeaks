{
    httpExchange.getResponseHeaders().add("Content-Type", "application/json");
    httpExchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
    try (OutputStream out = httpExchange.getResponseBody()) {
        String queryString = httpExchange.getRequestURI().getQuery();
        if (queryString == null || queryString.equals("")) {
            httpExchange.sendResponseHeaders(401, 0);
            out.close();
            return;
        }
        Map<String, String> queryMap = queryToMap(queryString);
        String topicName = queryMap.get("topicName");
        int offset = Integer.parseInt(queryMap.get("offset"));
        int length = Integer.parseInt(queryMap.get("length"));
        List<CloudEvent> eventList = admin.getEvent(topicName, offset, length);
        List<String> eventJsonList = new ArrayList<>();
        for (CloudEvent event : eventList) {
            byte[] serializedEvent = Objects.requireNonNull(EventFormatProvider.getInstance().resolveFormat(JsonFormat.CONTENT_TYPE)).serialize(event);
            eventJsonList.add(new String(serializedEvent, StandardCharsets.UTF_8));
        }
        String result = JsonUtils.toJSONString(eventJsonList);
        httpExchange.sendResponseHeaders(200, Objects.requireNonNull(result).getBytes().length);
        out.write(result.getBytes());
    } catch (Exception e) {
        try (OutputStream out = httpExchange.getResponseBody()) {
            StringWriter writer = new StringWriter();
            PrintWriter printWriter = new PrintWriter(writer);
            e.printStackTrace(printWriter);
            printWriter.flush();
            String stackTrace = writer.toString();
            Error error = new Error(e.toString(), stackTrace);
            String result = JsonUtils.toJSONString(error);
            httpExchange.sendResponseHeaders(500, Objects.requireNonNull(result).getBytes().length);
            out.write(result.getBytes());
        } catch (IOException ioe) {
            logger.warn("out close failed...", ioe);
        }
    }
}