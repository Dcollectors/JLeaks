{
    trimOldLogFiles();
}