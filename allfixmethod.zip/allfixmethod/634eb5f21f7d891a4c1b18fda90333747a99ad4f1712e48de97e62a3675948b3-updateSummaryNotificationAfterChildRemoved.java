{
    Cursor cursor = null;
    try {
        cursor = internalUpdateSummaryNotificationAfterChildRemoved(context, writableDb, group, dismissed);
    } catch (Throwable t) {
        OneSignal.Log(OneSignal.LOG_LEVEL.ERROR, "Error running updateSummaryNotificationAfterChildRemoved!", t);
    } finally {
        if (cursor != null && !cursor.isClosed())
            cursor.close();
    }
}