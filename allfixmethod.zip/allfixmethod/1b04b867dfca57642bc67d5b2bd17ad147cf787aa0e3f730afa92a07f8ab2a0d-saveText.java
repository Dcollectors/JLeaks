{
    OutputStream outputStream = virtualFile.getOutputStream(virtualFile);
    try {
        FileUtil.copy(new ByteArrayInputStream(text.getBytes(virtualFile.getCharset().name())), outputStream);
    } finally {
        outputStream.close();
    }
}