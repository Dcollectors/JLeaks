{
    // without absolutization, getParentFile below seems to fail
    dir = dir.getAbsoluteFile();
    try (ZipFile zip = new ZipFile(zipFile)) {
        Enumeration<ZipEntry> entries = zip.getEntries();
        while (entries.hasMoreElements()) {
            ZipEntry e = entries.nextElement();
            File f = new File(dir, e.getName());
            if (!f.getCanonicalFile().toPath().startsWith(dir.getCanonicalPath())) {
                throw new IOException("Zip " + zipFile.getPath() + " contains illegal file name that breaks out of the target directory: " + e.getName());
            }
            if (e.isDirectory()) {
                mkdirs(f);
            } else {
                File p = f.getParentFile();
                if (p != null) {
                    mkdirs(p);
                }
                try (InputStream input = zip.getInputStream(e)) {
                    IOUtils.copy(input, f);
                }
                try {
                    FilePath target = new FilePath(f);
                    int mode = e.getUnixMode();
                    if (// Ant returns 0 if the archive doesn't record the access mode
                    mode != 0)
                        target.chmod(mode);
                } catch (InterruptedException ex) {
                    LOGGER.log(Level.WARNING, "unable to set permissions", ex);
                }
                Files.setLastModifiedTime(Util.fileToPath(f), e.getLastModifiedTime());
            }
        }
    }
}