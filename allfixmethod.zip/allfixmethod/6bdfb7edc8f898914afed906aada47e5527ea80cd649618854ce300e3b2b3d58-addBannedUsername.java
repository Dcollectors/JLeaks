{
    if (isUsernameBanned(username).getFirst()) {
        removeBannedUsername(username);
    }
    Timestamp banTillTs = null;
    if (banTill != null) {
        banTillTs = new Timestamp(banTill.toEpochMilli());
    }
    logger.fine("Banning username:" + username);
    final Connection con = Database.getDerbyConnection();
    try {
        try (final PreparedStatement ps = con.prepareStatement("insert into banned_usernames (username, ban_till) values (?, ?)")) {
            ps.setString(1, username);
            ps.setTimestamp(2, banTillTs);
            ps.execute();
        }
        con.commit();
    } catch (final SQLException sqle) {
        if (sqle.getErrorCode() == 30000) {
            // this is ok
            // the username is banned as expected
            logger.info("Tried to create duplicate banned username:" + username + " error:" + sqle.getMessage());
            return;
        }
        throw new IllegalStateException("Error inserting banned username:" + username, sqle);
    } finally {
        DbUtil.closeConnection(con);
    }
}