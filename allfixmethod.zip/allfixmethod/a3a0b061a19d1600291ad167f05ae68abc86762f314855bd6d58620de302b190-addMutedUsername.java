{
    if (isUsernameMuted(username)) {
        removeMutedUsername(username);
    }
    Timestamp muteTillTs = null;
    if (muteTill != null) {
        muteTillTs = new Timestamp(muteTill.toEpochMilli());
    }
    logger.fine("Muting username:" + username);
    final Connection con = Database.getDerbyConnection();
    try {
        try (final PreparedStatement ps = con.prepareStatement("insert into muted_usernames (username, mute_till) values (?, ?)")) {
            ps.setString(1, username);
            ps.setTimestamp(2, muteTillTs);
            ps.execute();
        }
        con.commit();
    } catch (final SQLException sqle) {
        if (sqle.getErrorCode() == 30000) {
            // this is ok
            // the username is muted as expected
            logger.info("Tried to create duplicate muted username:" + username + " error:" + sqle.getMessage());
            return;
        }
        throw new IllegalStateException("Error inserting muted username:" + username, sqle);
    } finally {
        DbUtil.closeConnection(con);
    }
}