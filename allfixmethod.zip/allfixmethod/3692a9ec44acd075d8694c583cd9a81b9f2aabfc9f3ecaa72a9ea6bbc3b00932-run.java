{
    try {
        try {
            Util.copyStream(in, out);
        } finally {
            in.close();
        }
    } catch (IOException e) {
        // TODO: what to do?
    }
}