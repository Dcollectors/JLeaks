{
    try {
        if (channel != null) {
            channel.close();
        }
    } catch (IOException e) {
    } finally {
        channel = null;
    }
}