{
    try (RIFFWriter writer = new RIFFWriter(out, "sfbk")) {
        writeSoundbank(writer);
    }
}