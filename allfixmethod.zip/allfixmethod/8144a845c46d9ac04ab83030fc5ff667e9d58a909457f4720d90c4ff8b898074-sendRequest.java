{
    conn.setRequestMethod("GET");
    conn.setRequestProperty("User-Agent", "R-Grid-Remote-Client");
    conn.setDoOutput(true);
    byte[] osBuf = request.params;
    if (log.isLoggable(Level.FINER)) {
        log.finer(RemoteDeviceDataExchange.bytesToString("Data to server:", osBuf, osBuf.length));
    }
    try (OutputStream os = conn.getOutputStream()) {
        os.write(osBuf);
    }
    int responseCode = conn.getResponseCode();
    if (responseCode == 200) {
        // Status OK
        byte[] isBuf = null;
        int off = 0;
        int len;
        try (InputStream is = conn.getInputStream()) {
            isBuf = new byte[is.available() + 1];
            while ((len = is.read(isBuf, off, isBuf.length - off)) != -1) {
                off += len;
                if (off == isBuf.length) {
                    byte[] newBuf = new byte[isBuf.length + Math.max(isBuf.length, is.available() + 1)];
                    System.arraycopy(isBuf, 0, newBuf, 0, off);
                    isBuf = newBuf;
                }
            }
        }
        if (log.isLoggable(Level.FINER)) {
            log.finer(RemoteDeviceDataExchange.bytesToString("Response from server:", isBuf, off));
        }
        byte[] result;
        if (off != isBuf.length) {
            result = new byte[off];
            System.arraycopy(isBuf, 0, result, 0, off);
        } else {
            result = isBuf;
        }
        request.finish(result, null);
    }
}