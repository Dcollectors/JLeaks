{
    if (m_open.compareAndSet(true, /*expect*/
    false)) {
        deactivateTx();
    }
}