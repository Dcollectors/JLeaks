{
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    encode(object, bos);
    byte[] bytes = bos.toByteArray();
    bos.close();
    return bytes;
}