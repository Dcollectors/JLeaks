{
    List<Object> results;
    try (CloseableIterator<ObjectFilter.FilterResult> iterator = getIterator()) {
        if (!iterator.hasNext()) {
            results = Collections.emptyList();
        } else {
            Comparator<Comparable[]> comparator = getComparator();
            if (comparator == null) {
                // collect unsorted results and get the requested page if any was specified
                results = new ArrayList<>(INITIAL_CAPACITY);
                while (iterator.hasNext()) {
                    ObjectFilter.FilterResult entry = iterator.next();
                    resultSize++;
                    if (resultSize > startOffset && (maxResults == -1 || results.size() < maxResults)) {
                        results.add(projection != null ? entry.getProjection() : entry.getInstance());
                    }
                }
            } else {
                // collect and sort results, in reverse order for now
                PriorityQueue<ObjectFilter.FilterResult> filterResults = new PriorityQueue<>(INITIAL_CAPACITY, new ReverseFilterResultComparator(comparator));
                while (iterator.hasNext()) {
                    ObjectFilter.FilterResult entry = iterator.next();
                    resultSize++;
                    filterResults.add(entry);
                    if (maxResults != -1 && filterResults.size() > startOffset + maxResults) {
                        // remove the head, which is actually the highest result
                        filterResults.remove();
                    }
                }
                // collect and reverse
                if (filterResults.size() > startOffset) {
                    Object[] res = new Object[filterResults.size() - startOffset];
                    int i = filterResults.size();
                    while (i-- > startOffset) {
                        ObjectFilter.FilterResult r = filterResults.remove();
                        res[i - startOffset] = projection != null ? r.getProjection() : r.getInstance();
                    }
                    results = Arrays.asList(res);
                } else {
                    results = Collections.emptyList();
                }
            }
        }
    }
    return results;
}