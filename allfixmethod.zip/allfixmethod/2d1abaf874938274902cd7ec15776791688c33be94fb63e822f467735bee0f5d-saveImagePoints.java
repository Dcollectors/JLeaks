{
    currentPoints = new HashMap<>();
    for (final Entry<String, Tuple<Image, List<Point>>> entry : currentImagePoints.entrySet()) {
        // remove duplicates
        final LinkedHashSet<Point> pointSet = new LinkedHashSet<>();
        pointSet.addAll(entry.getValue().getSecond());
        entry.getValue().getSecond().clear();
        entry.getValue().getSecond().addAll(pointSet);
        currentPoints.put(entry.getKey(), entry.getValue().getSecond());
    }
    try {
        final String fileName = new FileSave("Where To Save Image Points Text File?", JFileChooser.FILES_ONLY, currentImagePointsTextFile, mapFolderLocation).getPathString();
        if (fileName == null) {
            return;
        }
        try (final FileOutputStream out = new FileOutputStream(fileName)) {
            PointFileReaderWriter.writeOneToMany(out, new HashMap<>(currentPoints));
        }
        System.out.println("Data written to :" + new File(fileName).getCanonicalPath());
    } catch (final Exception ex) {
        ClientLogger.logQuietly(ex);
    }
    System.out.println("");
}