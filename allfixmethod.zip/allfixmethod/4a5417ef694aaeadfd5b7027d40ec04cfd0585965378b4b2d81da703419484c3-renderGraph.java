{
    logger.debug("graph has {} nodes", graph.getReachableNodes().size());
    logger.debug("simulating instantiation");
    RecommenderInstantiator instantiator = RecommenderInstantiator.create(graph);
    DAGNode<Component, Dependency> unshared = instantiator.simulate();
    logger.debug("unshared graph has {} nodes", unshared.getReachableNodes().size());
    try (Writer writer = new FileWriter(graphvizFile);
        GraphWriter gw = new GraphWriter(writer)) {
        GraphDumper dumper = new GraphDumper(graph, unshared.getReachableNodes(), gw);
        logger.debug("writing root node");
        String rid = dumper.setRoot(graph);
        // process each other node & add an edge
        for (DAGEdge<Component, Dependency> e : graph.getOutgoingEdges()) {
            DAGNode<Component, Dependency> target = e.getTail();
            Component csat = target.getLabel();
            if (!satIsNull(csat.getSatisfaction())) {
                logger.debug("processing node {}", csat.getSatisfaction());
                String id = dumper.process(target);
                gw.putEdge(EdgeBuilder.create(rid, id).set("arrowhead", "vee").build());
            }
        }
        // and we're done
        dumper.finish();
    }
}