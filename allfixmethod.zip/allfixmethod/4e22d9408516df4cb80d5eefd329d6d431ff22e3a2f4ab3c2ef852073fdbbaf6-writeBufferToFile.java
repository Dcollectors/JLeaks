{
    FileOutputStream os = new FileOutputStream(path);
    try {
        os.write(buffer);
    } finally {
        os.close();
    }
}