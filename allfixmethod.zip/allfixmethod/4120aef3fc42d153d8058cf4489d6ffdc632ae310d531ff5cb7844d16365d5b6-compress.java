{
    File gzippedFile = new File(oldFile.getPath() + ".gz");
    try (GZIPOutputStream compressor = new GZIPOutputStream(new FileOutputStream(gzippedFile), 0x100000);
        FileInputStream inputStream = new FileInputStream(oldFile)) {
        long mtime = oldFile.lastModified();
        byte[] buffer = new byte[0x100000];
        for (int read = inputStream.read(buffer); read > 0; read = inputStream.read(buffer)) {
            compressor.write(buffer, 0, read);
        }
        compressor.finish();
        compressor.flush();
        oldFile.delete();
        gzippedFile.setLastModified(mtime);
        log.info("Compressed: " + gzippedFile);
    } catch (IOException e) {
        log.warning("Got '" + e + "' while compressing '" + oldFile.getPath() + "'.");
    }
}