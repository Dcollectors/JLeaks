{
    assert (optDumpBands);
    try (OutputStream ds = getDumpStream(this, ".bnd")) {
        if (bytesForDump != null)
            bytesForDump.writeTo(ds);
        else
            bytes.writeTo(ds);
    }
}