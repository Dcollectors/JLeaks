{
    if (replication != 1) {
        throw new IOException("UnderFileSystemSingleLocal does not provide more than one" + " replication factor");
    }
    return create(path);
}