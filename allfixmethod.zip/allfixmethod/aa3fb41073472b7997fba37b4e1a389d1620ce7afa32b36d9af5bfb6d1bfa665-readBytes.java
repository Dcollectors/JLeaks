{
    byte[] bytes = new byte[(int) file.length()];
    try (FileInputStream fileInputStream = new FileInputStream(file)) {
        fileInputStream.read(bytes);
    }
    return bytes;
}