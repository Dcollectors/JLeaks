{
    try (InputStream is = url.openStream()) {
        putFile(path, is);
    }
}