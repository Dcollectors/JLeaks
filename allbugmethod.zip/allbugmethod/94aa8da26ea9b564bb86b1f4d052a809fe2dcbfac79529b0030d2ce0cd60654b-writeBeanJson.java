{
    JsonGenerator generator = jsonFactory.createGenerator(writer);
    writeBeanChange(generator, bean, changeSet, position);
    generator.flush();
    generator.close();
}