{
    InputStream inStream = new FileInputStream(file);
    properties.load(inStream);
}