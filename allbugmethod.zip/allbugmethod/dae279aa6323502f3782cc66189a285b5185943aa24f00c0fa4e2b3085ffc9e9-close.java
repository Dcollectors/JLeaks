{
    if (!myClosed) {
        myClosed = true;
        flush();
        myStorage.close();
    }
}