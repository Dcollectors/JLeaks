{
    ObjectOutputStream oos = null;
    try {
        oos = new ObjectOutputStream(os);
        oos.writeObject(obj);
        oos.flush();
    } catch (IOException e) {
        throw new JRException(EXCEPTION_MESSAGE_KEY_OUTPUT_STREAM_SAVE_ERROR, null, e);
    }
}