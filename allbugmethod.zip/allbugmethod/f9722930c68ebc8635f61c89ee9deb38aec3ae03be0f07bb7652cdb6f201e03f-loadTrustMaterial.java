{
    // $NON-NLS-1$
    Args.notNull(file, "Truststore file");
    final KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
    final FileInputStream instream = new FileInputStream(file);
    try {
        trustStore.load(instream, tsp);
    } finally {
        instream.close();
    }
    return builder.loadTrustMaterial(trustStore, trustStrategy);
}