{
    if (fontFormat != Font.TRUETYPE_FONT && fontFormat != Font.TYPE1_FONT) {
        throw new IllegalArgumentException("font format not recognized");
    }
    SecurityManager sm = System.getSecurityManager();
    if (sm != null) {
        FilePermission filePermission = new FilePermission(fontFile.getPath(), "read");
        sm.checkPermission(filePermission);
    }
    if (!fontFile.canRead()) {
        throw new IOException("Can't read " + fontFile);
    }
    return new Font(fontFile, fontFormat, false);
}