{
    try {
        // Use SecuritySupport class to provide priveleged access to property file
        InputStream is = SecuritySupport.getResourceAsStream(ObjectFactory.findClassLoader(), file);
        // get a buffered version
        BufferedInputStream bis = new BufferedInputStream(is);
        // and load up the property bag from this
        target.load(bis);
        // close out after reading
        bis.close();
    } catch (Exception ex) {
        // ex.printStackTrace();
        throw new com.sun.org.apache.xml.internal.utils.WrappedRuntimeException(ex);
    }
}