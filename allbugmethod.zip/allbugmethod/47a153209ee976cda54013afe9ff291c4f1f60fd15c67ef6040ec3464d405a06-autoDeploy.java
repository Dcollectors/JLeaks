{
    AutoDeployer cloneAutoDeployer = _autoDeployer.cloneAutoDeployer();
    return cloneAutoDeployer.autoDeploy(autoDeploymentContext);
}