{
    final long version = rotation.rotationVersion();
    ProgressiveState<Key> next = rotation.rotate(force, rotationStrategy, rotationTimerFactory, value -> updateHeaders(value, version));
    try (LockWrapper ignored = writeLock(updateLock)) {
        state = next;
    } finally {
        rotation.close();
    }
    return version;
}