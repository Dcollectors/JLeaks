{
    text[0] = DocumentUtilities.getText(doc).toString();
}