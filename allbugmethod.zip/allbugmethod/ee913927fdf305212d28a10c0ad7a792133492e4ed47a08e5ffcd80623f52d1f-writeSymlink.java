{
    StringWriter w = new StringWriter();
    StreamTaskListener listener = new StreamTaskListener(w);
    File tmp = new File(cache.getPath() + ".tmp");
    try {
        Util.createSymlink(tmp.getParentFile(), target, tmp.getName(), listener);
        // Avoid calling resolveSymlink on a nonexistent file as it will probably throw an IOException:
        if (!exists(tmp) || Util.resolveSymlink(tmp) == null) {
            // symlink not supported. use a regular file
            AtomicFileWriter cw = new AtomicFileWriter(cache);
            try {
                cw.write(target);
                cw.commit();
            } finally {
                cw.abort();
            }
        } else {
            cache.delete();
            tmp.renameTo(cache);
        }
    } finally {
        tmp.delete();
    }
}