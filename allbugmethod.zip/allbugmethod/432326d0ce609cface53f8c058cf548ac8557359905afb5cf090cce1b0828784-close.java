{
    // it's okay if we over close - same as solrcore
    if (isClosed)
        return;
    isClosed = true;
    keeper.close();
    numCloses.incrementAndGet();
}