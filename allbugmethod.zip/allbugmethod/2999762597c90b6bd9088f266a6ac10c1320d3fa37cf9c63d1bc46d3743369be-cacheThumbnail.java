{
    resizeImage(context, media, THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT, forNetwork ? Bitmap.CompressFormat.JPEG : Bitmap.CompressFormat.PNG, forNetwork ? THUMBNAIL_MIME_COMPRESSION : 0, fout);
}