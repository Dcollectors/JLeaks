{
    return rsm.decode(buffer, output);
}