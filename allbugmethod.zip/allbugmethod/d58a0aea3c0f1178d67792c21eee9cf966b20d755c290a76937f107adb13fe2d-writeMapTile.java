{
    Path file = getFilePath(mapId, tileType, tile);
    OutputStream os = AtomicFileHelper.createFilepartOutputStream(file);
    os = new BufferedOutputStream(os);
    os = compression.compress(os);
    return os;
}