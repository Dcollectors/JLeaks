{
    if (transformInfoName == null) {
        // we need to return all transforms
        try {
            return wrapList(repository.getAllTransforms(), TransformInfo.class);
        } catch (Exception exception) {
            throw new RestException("Error reading transforms info from repository.", HttpStatus.INTERNAL_SERVER_ERROR, exception);
        }
    }
    return wrapObject(getTransformInfo(transformInfoName), TransformInfo.class);
}