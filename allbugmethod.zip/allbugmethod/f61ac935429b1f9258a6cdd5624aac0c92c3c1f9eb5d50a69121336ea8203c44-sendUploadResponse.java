{
    response.setContentType("text/html");
    final OutputStream out = response.getOutputStream();
    final PrintWriter outWriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(out, "UTF-8")));
    outWriter.print("<html><body>download handled</body></html>");
    outWriter.flush();
    out.close();
}