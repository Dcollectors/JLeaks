{
    LenskitConfiguration dataConfig = input.getConfiguration();
    LenskitRecommenderEngineBuilder builder = LenskitRecommenderEngine.newBuilder();
    for (LenskitConfiguration config : environment.loadConfigurations(getConfigFiles())) {
        builder.addConfiguration(config);
    }
    builder.addConfiguration(dataConfig, ModelDisposition.EXCLUDED);
    Stopwatch timer = Stopwatch.createStarted();
    LenskitRecommenderEngine engine = builder.build();
    timer.stop();
    logger.info("built model in {}", timer);
    File output = getOutputFile();
    CompressionMode comp = CompressionMode.autodetect(output);
    logger.info("writing model to {}", output);
    Closer closer = Closer.create();
    try {
        OutputStream stream = closer.register(new FileOutputStream(output));
        stream = closer.register(comp.wrapOutput(stream));
        engine.write(stream);
    } catch (Throwable th) {
        // NOSONAR using a closer
        throw closer.rethrow(th);
    } finally {
        closer.close();
    }
}