{
    writeSerializationMappings(stateFile, serializer.getSerializationMappings());
}