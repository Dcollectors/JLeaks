public Parser(boolean dedup, Analyzer analyzer) {
    super(dedup);
    this.analyzer = analyzer;
}
