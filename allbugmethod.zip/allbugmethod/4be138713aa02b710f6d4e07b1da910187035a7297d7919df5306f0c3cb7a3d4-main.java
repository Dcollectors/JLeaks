{
    TFsShell shell = new TFsShell();
    System.exit(shell.run(argv));
}