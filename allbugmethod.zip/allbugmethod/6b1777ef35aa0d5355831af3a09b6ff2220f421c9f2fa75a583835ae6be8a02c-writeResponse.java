{
    response.setContentType(contentType);
    final OutputStream out = response.getOutputStream();
    // Set the response type
    final PrintWriter outWriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(out, "UTF-8")));
    outWriter.print(output);
    outWriter.flush();
    outWriter.close();
}