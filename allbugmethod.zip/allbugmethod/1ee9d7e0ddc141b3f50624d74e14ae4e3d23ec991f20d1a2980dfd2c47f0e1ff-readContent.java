{
    StringBuilder sb = new StringBuilder();
    try {
        InputStreamReader is = new InputStreamReader(new FileInputStream(file), Charset.forName("UTF-8"));
        BufferedReader reader = new BufferedReader(is);
        String line = null;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
            if (lineEnding != null) {
                sb.append(lineEnding);
            }
        }
        reader.close();
    } catch (Throwable t) {
        System.err.println("Failed to read content of " + file.getAbsolutePath());
        t.printStackTrace();
    }
    return sb.toString();
}