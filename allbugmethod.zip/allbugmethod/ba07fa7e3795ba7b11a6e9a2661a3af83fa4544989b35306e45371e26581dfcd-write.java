{
    _adoptee.write(b);
}