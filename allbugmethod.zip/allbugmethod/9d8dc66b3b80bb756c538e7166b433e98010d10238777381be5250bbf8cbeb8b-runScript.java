{
    try {
        DatabaseUtil.executeScript(FileUtils.readFileToString(scriptFile), false);
    } catch (Exception e) {
        e.printStackTrace();
    }
}