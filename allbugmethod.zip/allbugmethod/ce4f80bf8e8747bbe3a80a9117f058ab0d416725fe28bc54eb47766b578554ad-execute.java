{
    try {
        network.beginResponse(sessionId, 0, false);
        Object obj = null;
        final byte request = network.readByte();
        switch(request) {
            case OChannelBinaryProtocol.REQUEST_PUSH_DISTRIB_CONFIG:
            case OChannelBinaryProtocol.REQUEST_PUSH_LIVE_QUERY:
                obj = network.readBytes();
                break;
        }
        if (remoteServerEventListener != null)
            remoteServerEventListener.onRequest(request, obj);
    } catch (IOException ioe) {
        // EXCEPTION RECEIVED (THE SOCKET HAS BEEN CLOSED?) ASSURE TO UNLOCK THE READ AND EXIT THIS THREAD
        sendShutdown();
        if (network != null) {
            final OChannelBinaryAsynchClient n = network;
            network = null;
            n.close();
        }
    } finally {
        if (network != null)
            network.endResponse();
    }
}