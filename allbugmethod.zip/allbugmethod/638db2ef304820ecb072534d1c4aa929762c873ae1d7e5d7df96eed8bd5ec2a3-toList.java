{
    return new ListIterator<>(Query.DEFAULT_CAPACITY, iterator);
}