{
    return readAll(new InputStreamReader(stream, charset));
}