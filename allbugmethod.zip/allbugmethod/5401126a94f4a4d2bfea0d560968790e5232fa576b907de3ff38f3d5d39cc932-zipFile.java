{
    checkArgument(fileToCompress.isFile(), "File should be a file: " + fileToCompress);
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    ZipOutputStream zos = new ZipOutputStream(bos);
    try {
        addToZip(baseDir.getAbsolutePath(), zos, fileToCompress);
        return Base64.getEncoder().encodeToString(bos.toByteArray());
    } finally {
        zos.close();
        bos.close();
    }
}