{
    if (result != null) {
        result.close();
    }
    if (query != null) {
        query.clone();
    }
    if (connection != null) {
        connection.close();
    }
}