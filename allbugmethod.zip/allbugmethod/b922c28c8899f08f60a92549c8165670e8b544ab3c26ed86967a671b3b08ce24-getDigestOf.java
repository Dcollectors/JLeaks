{
    try (InputStream is = Files.newInputStream(file.toPath())) {
        return getDigestOf(new BufferedInputStream(is));
    } catch (InvalidPathException e) {
        throw new IOException(e);
    }
}