{
    ClassProperties cp = new ClassProperties(properties);
    cp.load(cls, inherit);
    return cp;
}