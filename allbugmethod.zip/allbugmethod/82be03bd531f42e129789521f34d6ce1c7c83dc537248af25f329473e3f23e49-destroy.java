{
    if (dataSourceRequiresShutdown()) {
        this.dataSource.getConnection().createStatement().execute("SHUTDOWN");
    }
}