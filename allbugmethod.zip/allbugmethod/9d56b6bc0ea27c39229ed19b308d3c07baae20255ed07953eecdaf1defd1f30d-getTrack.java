{
    if (trackId < 0) {
        return null;
    }
    try (Cursor cursor = getTrackCursor(null, TracksColumns._ID + "=?", new String[] { Long.toString(trackId) }, TracksColumns._ID)) {
        if (cursor != null && cursor.moveToNext()) {
            return createTrack(cursor);
        }
    }
    return null;
}