{
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    ObjectOutput out = null;
    try {
        out = new ObjectOutputStream(bos);
        out.writeObject(resultValue);
        out.flush();
        return bos.toByteArray();
    } catch (Exception ex) {
        log.info("Exception during serialization", ex);
    } finally {
        try {
            bos.close();
        } catch (IOException ex) {
            // ignore close exception
        }
    }
    return null;
}