{
    RecordScannable<?> recordScannable = instantiate(conf);
    Type type = recordScannable.getRecordType();
    recordScannable.close();
    return type;
}