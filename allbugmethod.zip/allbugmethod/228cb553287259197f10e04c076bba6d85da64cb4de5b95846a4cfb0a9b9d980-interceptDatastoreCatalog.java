{
    final DatastoreCatalogType newDatastoreCatalog = new DatastoreCatalogType();
    final Set<Entry<String, MutableSchema>> datastoreUsageEntries = datastoreUsage.entrySet();
    for (final Entry<String, MutableSchema> entry : datastoreUsageEntries) {
        final String name = entry.getKey();
        Schema schema = entry.getValue();
        final Datastore datastore = datastoreCatalog.getDatastore(name);
        if (datastore != null) {
            // a comparator that takes the column number into account.
            final Comparator<Column> columnComparator = new Comparator<Column>() {

                @Override
                public int compare(Column o1, Column o2) {
                    if (o1.getTable() == o2.getTable()) {
                        int diff = o1.getColumnNumber() - o2.getColumnNumber();
                        if (diff != 0) {
                            return diff;
                        }
                    }
                    return o1.compareTo(o2);
                }
            };
            final DatastoreConnection connection = datastore.openConnection();
            try {
                final DataContext dataContext = connection.getDataContext();
                final JaxbPojoDatastoreAdaptor adaptor = new JaxbPojoDatastoreAdaptor();
                final Collection<PojoTableType> pojoTables = new ArrayList<PojoTableType>();
                Table[] usageTables = schema.getTables();
                if (usageTables == null || usageTables.length == 0) {
                    // an unspecified schema entry will be interpreted as an
                    // open-ended inclusion of schema information only
                    schema = dataContext.getDefaultSchema();
                    usageTables = dataContext.getDefaultSchema().getTables();
                }
                final String schemaName = schema.getName();
                for (final Table usageTable : usageTables) {
                    Column[] usageColumns = usageTable.getColumns();
                    if (usageColumns == null || usageColumns.length == 0) {
                        // an unspecified table entry will be interpreted by
                        // including all columns of that table
                        final String tableName = usageTable.getName();
                        final Schema schemaByName = dataContext.getSchemaByName(schemaName);
                        if (schemaByName == null) {
                            logger.error("Could not find schema by name: {}, skipping table: {}", schemaName, usageTable);
                            usageColumns = new Column[0];
                        } else {
                            final Table table = schemaByName.getTableByName(tableName);
                            usageColumns = table.getColumns();
                        }
                    }
                    if (usageColumns != null && usageColumns.length > 0) {
                        Arrays.sort(usageColumns, columnComparator);
                        final int maxRows = REMARK_INCLUDE_IN_QUERY.equals(usageTable.getRemarks()) ? MAX_POJO_ROWS : 0;
                        final Table sourceTable = usageColumns[0].getTable();
                        try {
                            final PojoTableType pojoTable = adaptor.createPojoTable(dataContext, sourceTable, usageColumns, maxRows);
                            pojoTables.add(pojoTable);
                        } catch (Exception e) {
                            // allow omitting errornous tables here.
                            logger.error("Failed to serialize table '" + sourceTable + "' of datastore '" + name + "' to POJO format: " + e.getMessage(), e);
                        }
                    }
                }
                final AbstractDatastoreType pojoDatastoreType = adaptor.createPojoDatastore(datastore.getName(), schemaName, pojoTables);
                pojoDatastoreType.setDescription(datastore.getDescription());
                newDatastoreCatalog.getJdbcDatastoreOrAccessDatastoreOrCsvDatastore().add(pojoDatastoreType);
            } catch (Exception e) {
                // allow omitting errornous datastores here.
                logger.error("Failed to serialize datastore '" + name + "' to POJO format: " + e.getMessage(), e);
            } finally {
                connection.close();
            }
        }
    }
    return newDatastoreCatalog;
}