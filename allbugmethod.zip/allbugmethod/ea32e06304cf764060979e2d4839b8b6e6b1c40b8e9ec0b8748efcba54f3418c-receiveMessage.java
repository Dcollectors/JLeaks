{
    // handle incoming message, then ack/nack the received message
    final ByteString data = message.getData();
    final String messageId = message.getMessageId();
    log.debug("Received ID:{} with content: {}", messageId, data.toStringUtf8());
    final byte[] bytes = data.toByteArray();
    Span span = tracer.spanBuilder("PubSub.receiveMessage").startSpan();
    span.putAttribute("id", stringAttributeValue(messageId));
    final FutureReporter.Context consumptionContext = reporter.reportConsumption();
    // process the data
    try (Scope ws = tracer.withSpan(span)) {
        consumer.consume(bytes).onDone(consumptionContext).onFinished(() -> {
            reporter.reportMessageSize(bytes.length);
            replyConsumer.ack();
            span.end();
        });
    } catch (ConsumerSchemaValidationException e) {
        reporter.reportConsumerSchemaError();
        log.error("ID:{} - {}", messageId, e.getMessage(), e);
        // The message will never be processable, ack it to make it go away
        replyConsumer.ack();
        span.end();
    } catch (Exception e) {
        errors.incrementAndGet();
        log.error("ID:{} - Failed to consume", messageId, e);
        span.setStatus(Status.INTERNAL.withDescription(e.toString()));
        reporter.reportMessageError();
        replyConsumer.nack();
        span.end();
    } finally {
        consumed.increment();
    }
}