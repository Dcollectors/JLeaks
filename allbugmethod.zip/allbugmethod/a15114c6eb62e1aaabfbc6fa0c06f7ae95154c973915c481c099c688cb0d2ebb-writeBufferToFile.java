{
    FileOutputStream os = new FileOutputStream(path);
    os.write(buffer);
    os.close();
}