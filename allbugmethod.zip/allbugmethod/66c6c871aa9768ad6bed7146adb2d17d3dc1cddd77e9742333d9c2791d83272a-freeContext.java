{
    SearchContext removed = activeContexts.remove(context.id());
    if (removed != null) {
        removed.indexShard().searchService().onFreeContext(removed);
    }
    context.close();
}