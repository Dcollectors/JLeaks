{
    return getInstance(configuration).createReader(fs, path, reporter);
}