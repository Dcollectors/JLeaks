{
    Response r = rsGet(bucket, String.format("/stat/%s", encodedEntry(bucket, fileKey)));
    return r.jsonToObject(FileInfo.class);
}