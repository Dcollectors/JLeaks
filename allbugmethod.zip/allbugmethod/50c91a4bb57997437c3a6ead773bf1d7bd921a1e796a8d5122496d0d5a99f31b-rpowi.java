{
    return manager.create(n).toType(array.getDataType(), false).powi(array);
}