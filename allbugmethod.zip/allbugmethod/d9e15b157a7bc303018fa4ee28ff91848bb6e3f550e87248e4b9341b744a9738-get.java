{
    Long2DoubleMap itemMeans = new Long2DoubleOpenHashMap();
    Cursor<Rating> ratings = dao.getEvents(Rating.class);
    double globalMean = computeItemAverages(ratings.fast().iterator(), damping, itemMeans);
    ratings.close();
    return new ItemMeanPredictor(itemMeans, globalMean, damping);
}