{
    try {
        if (rs != null && !rs.isClosed()) {
            rs.close();
        }
    } catch (SQLException ex) {
        throw new Sql2oException("Error attempting to close ResultSet.", ex);
    } finally {
        rs = null;
        closeConnectionIfNecessary();
    }
}