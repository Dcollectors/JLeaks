{
    InputStream fin = openClassfile(classname);
    byte[] b = readStream(fin);
    fin.close();
    return b;
}