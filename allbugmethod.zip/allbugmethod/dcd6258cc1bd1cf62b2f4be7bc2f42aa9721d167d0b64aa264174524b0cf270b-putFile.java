{
    InputStream is = url.openStream();
    putFile(path, is);
    IOUtils.closeQuietly(is);
}