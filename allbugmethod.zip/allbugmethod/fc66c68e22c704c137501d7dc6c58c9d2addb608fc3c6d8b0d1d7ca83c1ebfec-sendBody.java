{
    long BUFFER_SIZE = 16 * 1024;
    byte[] buff = new byte[(int) BUFFER_SIZE];
    boolean sendEverything = pending == -1;
    while (pending > 0 || sendEverything) {
        long bytesToRead = sendEverything ? BUFFER_SIZE : Math.min(pending, BUFFER_SIZE);
        int read = this.data.read(buff, 0, (int) bytesToRead);
        if (read <= 0) {
            break;
        }
        outputStream.write(buff, 0, read);
        if (!sendEverything) {
            pending -= read;
        }
    }
}