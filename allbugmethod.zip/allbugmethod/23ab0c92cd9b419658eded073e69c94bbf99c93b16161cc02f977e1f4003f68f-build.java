{
    final T build = build(new ServiceLocator(services.toArray(new Service[services.size()])));
    if (init) {
        build.init();
    }
    return build;
}