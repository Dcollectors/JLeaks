{
    if (!exist()) {
        return;
    }
    try {
        PropertiesConfiguration config = new PropertiesConfiguration();
        config.setIOFactory(new FilteringOutputWriterFactory());
        PropertiesConfigurationLayout layout = new PropertiesConfigurationLayout(config);
        layout.load(reader());
        layout.save(new FileWriter(this.configFile));
        loadProperties();
    } catch (ConfigurationException | IOException e) {
        LOG.warn("[Agent Auto Registration] Unable to scrub registration key.", e);
    }
}