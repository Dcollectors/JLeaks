{
    final XStream outer = new XStream();
    final ObjectOutputStream oos = outer.createObjectOutputStream(out);
    try {
        oos.writeObject(xstream);
        oos.flush();
        xstream.toXML(obj, out);
    } finally {
        oos.close();
    }
}