{
    KeyStore keystore = KeyStore.getInstance(PKCS12_ALG);
    try {
        keystore.load(new FileInputStream(certPath), keyPassword.toCharArray());
    } catch (FileNotFoundException e) {
        throw new SQLServerException(SQLServerException.getErrString("R_clientCertError"), null, 0, null);
    }
    KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(SUN_X_509);
    keyManagerFactory.init(keystore, keyPassword.toCharArray());
    return keyManagerFactory.getKeyManagers();
}