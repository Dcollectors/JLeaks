{
    GZIPOutputStream zipper = new GZIPOutputStream(out);
    content.writeTo(zipper);
    zipper.finish();
}